Le programme "gestion d'un restaurant" comporte plusieurs fichiers un prototype (resto.h) un deuxieme fichier resto.cpp et un dernier qui est le main.cpp.
Le programme permet de g�rer les clients, permet de commander, de calculer automatiquement la commande le client.
Dans le fichier resto.h, nous avons d�clar� toutes les classes n�cessaires aufonctionnement de notre programme.
Dans le fichier resto.cpp, nous avons fait des fonctions relatives � ces classes.
Dans le main.cpp, nous avons fait le programme principal qui permet de g�rer les classes et leurs fonctions.