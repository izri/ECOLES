#include "Plat_du_jour.h"

Plat_du_jour::Plat_du_jour (string nom, unsigned int prix) : Plat::Plat(nom, prix) {

}
