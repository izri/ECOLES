#include "Plat.h"

/// class Boisson -
class Boisson : public Plat {

    // Operations
public:
    Boisson (string nom, unsigned int prix);
    void  aff ();
};
