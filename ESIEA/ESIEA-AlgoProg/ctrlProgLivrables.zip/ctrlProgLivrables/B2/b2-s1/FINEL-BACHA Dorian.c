#include <stdio.h>
#include <stdlib.h>
//1

typedef struct liste;
{
    int val;
    struct element *ava
        struct element *nxt;
};
typedef llist

//2
void show_Liste(llist list)
{
    if (liste == )
    {
        exit(EXIT_FAILURE);
    }
    printf("Votre liste actuelle est :\n");
    while(element != )
    {
        printf("%d ",element->val);
        element=element->nxt;
    }
    printf("\n");
}

//3
int sum_diviseurs(liste a)
{    
    int i;
    int j;
    int k;
    j = 0;
    k = 0;
    i = 1;
    while (a > i)
    {
        if (a%i == 0)
        {
            j = i + k;
            k = j;
            i++;
        }    
    }
    retur j;
}
void perfect_liste(liste element)
{
    if(element == element->next  )
        return;
    else
    {
        while(element =! element->next )
        {
            if(sum-diviseurs(element->val) == element->val)
                element =  element ->next;
            else
                supprimer maillon
        }

    }
}