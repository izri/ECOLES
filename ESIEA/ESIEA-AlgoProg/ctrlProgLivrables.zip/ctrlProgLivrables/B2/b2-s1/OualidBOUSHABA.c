#include<stdio.h>
#include<stdlib.h>

typedef struct element ELEMENT;
{
    int valeur;
    
    entier*suivant;
}


int main 
{

int i;
int N;

for(i>=2,i<N,i++)
{
affiche_liste(element);
}

}



void affiche_liste(element)
{
if(element=NULL);
printf("listeVide");
while("element!=0")
{
return element;
valeur->element=suivant;
}

}






