#include <stdlib.h>
#include <stdio.h>

typedef struct elem elem ;{
struct elem;

}
int nb;

struct elem* list;

int main(){

return 0;
}
