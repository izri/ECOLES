#include <stdio.h>
#include <stdlib.h>

 
typedef struct element element;
struct element

{	int val (val>=2;val<=N);
	struct element *next;
};
 
typedef element* llist;
 
int main(int argc, char **argv)
{
	llist ma_liste1 = NULL;
	return 0;
}
}

/*afficher la liste*/

void afficherLaListe(llist liste)
{
	element *tmp = liste;

	while(tmp != NULL)
    {
        /* afficher */
        printf("%d ", tmp->val);
        /* On va à la case suivante */
        tmp = tmp->next;
    }
}

/*element qui parcour la liste */

void parcourirListe(lliste liste)
{
	if(val=)
 
};

/*afficher que les nombres parfaits <= 800*/

void afficherNombresParfaits

{
	if nbrParfais->val<=800
	{
	printf("%d",nbreParfais)
	}
}


