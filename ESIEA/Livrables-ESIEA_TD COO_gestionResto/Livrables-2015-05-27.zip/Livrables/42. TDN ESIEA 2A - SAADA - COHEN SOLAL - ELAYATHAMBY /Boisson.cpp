#include "Boisson.h"

Boisson::Boisson (string nom, unsigned int prix) : Plat::Plat(nom, prix) {

}
