TD de gestion de la relation client d'un restaurant
Nous avons r�alis� un programme en C++ � l'aide de Code::Blocks. Notre programme est compos� de plusieurs classes.
Notre programme permet � l'utilisateur de rentrer une fiche client. Cette fiche client sera stock�e et pourra �tre r�utilis�e.
Il est possible de r�aliser une commande � partir d'un menu o� chaque cat�gorie de produits est associ�e � un prix. 
Bien s�r il est possible de choisir des produits de diff�rentes cat�gories et en diff�rentes quantit�s.
Lorsque l'utilisateur a fini sa commande un r�capitulatif contenant les produits command�s, le prix total et l'heure sont affich�s.
Nous utilisons la bibliot�que time.h pour l'heure ainsi que iostream, stdio et string.
Nous avons modifi� notre CDC et notre diagramme de classes en mettant � jour les attributs, constructeurs et m�thodes. 
Mais aussi les classes puisque nous n'avons pas eu le temps de faire tout ce que nous avions esp�r�.
Nous n'avons pas r�alis� nous m�me la fonction heure car c'est une fonction basique de la librairie.
(http://openclassrooms.com/courses/time-h-et-ses-fonctions)