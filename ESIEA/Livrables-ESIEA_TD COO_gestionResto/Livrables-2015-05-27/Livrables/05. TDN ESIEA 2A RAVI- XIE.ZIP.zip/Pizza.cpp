#include "Pizza.h"
#include <string>


using namespace std;

Pizza::Pizza() : m_nomPizza("")
{

}

Pizza::Pizza(string nom) : m_nomPizza(nom)
{

}










