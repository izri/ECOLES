#include "MajStock.h"
#include <string>
#include <iostream>

using namespace std;

MajStock::MajStock() : m_stockRestant()
{

}

MajStock::MajStock(string c, int nb) : m_stockRestant()
{

}





