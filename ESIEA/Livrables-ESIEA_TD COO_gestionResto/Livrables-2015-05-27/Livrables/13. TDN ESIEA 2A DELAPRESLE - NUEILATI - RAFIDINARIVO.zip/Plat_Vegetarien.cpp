#include "Plat_Vegetarien.h"
using namespace std;
Plat_Vegetarien::Plat_Vegetarien (string nom, int prix):Plat::Plat(nom, prix) {
}
