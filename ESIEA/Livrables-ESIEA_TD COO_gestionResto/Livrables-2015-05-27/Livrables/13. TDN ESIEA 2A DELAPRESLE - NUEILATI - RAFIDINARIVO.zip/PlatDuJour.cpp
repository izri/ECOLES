#include "PlatDuJour.h"
using namespace std;
PlatDuJour::PlatDuJour (string nom, int prix):Plat::Plat(nom, prix) {
}
