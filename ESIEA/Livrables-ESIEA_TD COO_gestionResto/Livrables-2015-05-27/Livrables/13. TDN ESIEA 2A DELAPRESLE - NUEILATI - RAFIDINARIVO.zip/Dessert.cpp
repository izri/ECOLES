#include "Dessert.h"
using namespace std; 
Dessert::Dessert (string nom, int prix):Plat::Plat(nom, prix) {
 
}
