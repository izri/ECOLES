#include "Boisson.h"
using namespace std;
Boisson::Boisson (string nom, int prix):Plat::Plat(nom, prix) {
}
