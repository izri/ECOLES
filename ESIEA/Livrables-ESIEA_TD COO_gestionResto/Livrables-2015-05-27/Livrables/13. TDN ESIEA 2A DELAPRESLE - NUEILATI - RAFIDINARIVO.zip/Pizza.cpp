#include "Pizza.h"
using namespace std;
Pizza::Pizza (string nom, int prix):Plat::Plat(nom, prix) {
}
