Etat : Le programme r�pond � toutes les demandes de fonctionnalit�s demand�es avec une interface graphique de type console.

Fonctionnement : Le fichier main est : resto.cpp . Il est constitu� d'une fonction main g�rant les appels des diff�rentes fonction et permettre � l'utilisateur d'enregistrer dans un premier temps:
		 -un choix de plats grace � la gestion de menu
		 -un r�glage de la date. 
Une fois l'initialisation termin�e, l'utilisateur peut enregistrer des commandes, retourner sur le menu de gestion des plats
		


