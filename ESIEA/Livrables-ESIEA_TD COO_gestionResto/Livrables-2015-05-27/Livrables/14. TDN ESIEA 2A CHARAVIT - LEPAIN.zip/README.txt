Bonjour,
nous somme parvenue a faire tout ce que nous avions prévue.
Les données des utilisateurs sont gardé dans un fichier .txt, ainsi le gérant du magasin
peut gérer toute les entrées et surtout faire ces statistiques.
La programmation orienté objet est respecté, le programme est en C++ et fonctionne avec 
des "objets".

