#ifndef PLAT_H_INCLUDED
#define PLAT_H_INCLUDED

class Plat
{
    private:

    public:
        Plat();
};

#endif // PLAT_H_INCLUDED
