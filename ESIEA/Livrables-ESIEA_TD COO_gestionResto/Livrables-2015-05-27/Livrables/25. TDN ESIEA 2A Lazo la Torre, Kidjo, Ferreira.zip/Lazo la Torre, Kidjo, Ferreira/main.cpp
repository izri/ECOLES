#include <iostream>
#include <Client.h>
#include <string>

using namespace std;

int main()
{
    cout << "Prendre une command :"<< endl;
}
