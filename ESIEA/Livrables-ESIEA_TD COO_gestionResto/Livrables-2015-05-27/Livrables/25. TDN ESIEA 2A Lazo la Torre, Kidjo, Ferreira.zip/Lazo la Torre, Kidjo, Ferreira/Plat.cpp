#include "Plat.h"

Plat::Plat()
{
    //ctor
}
