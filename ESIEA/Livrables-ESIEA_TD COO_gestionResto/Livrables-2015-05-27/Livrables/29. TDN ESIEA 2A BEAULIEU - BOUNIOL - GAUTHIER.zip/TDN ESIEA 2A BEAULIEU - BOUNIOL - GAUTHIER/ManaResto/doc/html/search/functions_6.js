var searchData=
[
  ['newcustomerwindow',['NewCustomerWindow',['../class_new_customer_window.html#a018d9a8e01e78a931c4c92a35d7be194',1,'NewCustomerWindow::NewCustomerWindow(QWidget *parent=0)'],['../class_new_customer_window.html#ad8033cde951c70473307077b470da200',1,'NewCustomerWindow::NewCustomerWindow(QString name, QString surname)'],['../class_new_customer_window.html#a9266b2386f3f80b1c913c69abdc219d0',1,'NewCustomerWindow::NewCustomerWindow(QString error1, QString error2, QString name, QString surname)']]],
  ['neworderwindow',['NewOrderWindow',['../class_new_order_window.html#af8b226a53164e912d050343d26edcb41',1,'NewOrderWindow::NewOrderWindow(QWidget *parent=0)'],['../class_new_order_window.html#ae5388312b8d8c796fd6c604ec8fad25d',1,'NewOrderWindow::NewOrderWindow(QString error)']]],
  ['newvisit',['newVisit',['../class_customer.html#a38b08f24c6a9c7462e45bc0926ac71ff',1,'Customer']]],
  ['ntaxprice',['ntaxPrice',['../class_order.html#a8afadd0e6ab77ecc56f61f6a5a5db04c',1,'Order']]]
];
