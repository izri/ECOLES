var class_good_bye_window =
[
    [ "GoodByeWindow", "class_good_bye_window.html#a2bb01c8a0c084ab063e444656daae018", null ],
    [ "~GoodByeWindow", "class_good_bye_window.html#a8c7ca3a37d0c5dec938fb4119bf1ca8e", null ],
    [ "on_pushButton_clicked", "class_good_bye_window.html#a1f75a8eedbce766e25e32ee15f7ae336", null ],
    [ "ui", "class_good_bye_window.html#a7329f773cbdff71204ad69769e4c76f3", null ]
];