var class_beverage =
[
    [ "Beverage", "class_beverage.html#af77333057395e0bfafc2633d3999f318", null ],
    [ "Beverage", "class_beverage.html#a2a6e250ac12515b5fc3d26e77e6abb47", null ],
    [ "alcoTest", "class_beverage.html#affff61c5043efae415fa2d4ebc556b12", null ],
    [ "getVolume", "class_beverage.html#aa5bb1b36ec8ca71a5d01f2f7cf89259c", null ],
    [ "saveBeverage", "class_beverage.html#a594a6d83cf5317559b49d091ff3f0633", null ],
    [ "updateBeverage", "class_beverage.html#acc31e3662504d246752aeaf2bbf61a93", null ],
    [ "m_isAlcohol", "class_beverage.html#a412d884adcfed8e171fd50d349c50ccc", null ],
    [ "m_volume", "class_beverage.html#a6bd5fdb647a8ab7beadf55038b51c7ff", null ]
];