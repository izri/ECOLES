var indexSectionsWithContent =
{
  0: "abcdfgmnostu~",
  1: "abcdfgnos",
  2: "u",
  3: "abcdfgnostu~",
  4: "mu",
  5: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

