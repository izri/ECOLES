var searchData=
[
  ['management_20of_20a_20restaurant_20made_20easy_2e',['Management of a restaurant made easy.',['../index.html',1,'']]],
  ['m_5fage',['m_age',['../class_customer.html#a6d311ab6848e14397b24eb3831d0072c',1,'Customer']]],
  ['m_5fcusto',['m_custo',['../class_command_check_window.html#aca025bb32e0bc1aff7848367ee97a3e9',1,'CommandCheckWindow::m_custo()'],['../class_dish_selection_window.html#a2b7ccc9938885573b0bc25b1bb244157',1,'DishSelectionWindow::m_custo()']]],
  ['m_5fcustord',['m_custOrd',['../class_command_check_window.html#ad50bd672f462de8920189a164a06e869',1,'CommandCheckWindow']]],
  ['m_5fdessert',['m_dessert',['../class_order.html#abb07243a758fb5103a167a0ff6af9af7',1,'Order']]],
  ['m_5fdrink',['m_drink',['../class_order.html#a63bdeb49e0d3e8a47a2f24580788a393',1,'Order']]],
  ['m_5fgender',['m_gender',['../class_customer.html#a77bb50b736b789c38f15ed6d44637f61',1,'Customer']]],
  ['m_5fid',['m_id',['../class_customer.html#ab01ef5fd44759a641dd3310b5831a96c',1,'Customer']]],
  ['m_5fidorder',['m_idOrder',['../class_order.html#a29d12d747d0669e95c42073106896fb7',1,'Order']]],
  ['m_5fisalcohol',['m_isAlcohol',['../class_beverage.html#a412d884adcfed8e171fd50d349c50ccc',1,'Beverage']]],
  ['m_5fmain',['m_main',['../class_order.html#a3a3395871d71ecd32e4cf98f87be32f9',1,'Order']]],
  ['m_5fname',['m_name',['../class_customer.html#a057b496cea465ca4c527f71be2ac979f',1,'Customer::m_name()'],['../class_food.html#a5daec18293e68de2faf859a80f2d43b7',1,'Food::m_name()']]],
  ['m_5fprice',['m_price',['../class_food.html#a5316e6cd4165f39120e873ea2ec6c256',1,'Food']]],
  ['m_5fstarter',['m_starter',['../class_order.html#a66fb2c5ed01b1a8603e2d99887bccfda',1,'Order']]],
  ['m_5ftotalexpense',['m_totalExpense',['../class_customer.html#a15c86983248c90038b56f41f3ddf956c',1,'Customer']]],
  ['m_5ftotalordered',['m_totalOrdered',['../class_food.html#a6f736bdc134162ea6acef85608f7a2e6',1,'Food']]],
  ['m_5ftotalprice',['m_totalPrice',['../class_order.html#ae01870129cac2a755d739412e8231577',1,'Order']]],
  ['m_5ftotalvisit',['m_totalVisit',['../class_customer.html#a6e2bbdc0e4f8d1d571217f7ca14b1fa0',1,'Customer']]],
  ['m_5ftype',['m_type',['../class_dish.html#a408610d247d15568fe86cdfbde9b1c5e',1,'Dish']]],
  ['m_5fvolume',['m_volume',['../class_beverage.html#a6bd5fdb647a8ab7beadf55038b51c7ff',1,'Beverage']]]
];
