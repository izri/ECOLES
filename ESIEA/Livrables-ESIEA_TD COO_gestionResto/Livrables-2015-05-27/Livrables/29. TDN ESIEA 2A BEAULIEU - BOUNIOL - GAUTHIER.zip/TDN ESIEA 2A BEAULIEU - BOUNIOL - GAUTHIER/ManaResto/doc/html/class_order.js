var class_order =
[
    [ "Order", "class_order.html#a7b6a660b03708ed5b4e1c4a6dc2a664a", null ],
    [ "Order", "class_order.html#aef0fd305d72224ed71ccdb740b6f4db9", null ],
    [ "getNameBeverage", "class_order.html#a2d4177e6b00df49cb7c5698d51654e35", null ],
    [ "getNameDesert", "class_order.html#ab0610eebc8d069824bc868371c3a7319", null ],
    [ "getNameMain", "class_order.html#a396f0d27e2db4d9f6edf87dbee0be8a7", null ],
    [ "getNameStarter", "class_order.html#a5e98ca659357d1d3c6d0f35218083287", null ],
    [ "getPrice", "class_order.html#a56fe0fbdd832c503af9d0b068d73bd60", null ],
    [ "ntaxPrice", "class_order.html#a8afadd0e6ab77ecc56f61f6a5a5db04c", null ],
    [ "saveOrder", "class_order.html#aa6c863d686ddb08102dc660d2c367da1", null ],
    [ "totalPrice", "class_order.html#a8956525f6df22abb2a4906574518352d", null ],
    [ "updateOrder", "class_order.html#ace3652761fd82d12f43503d4e5d3f8c9", null ],
    [ "m_dessert", "class_order.html#abb07243a758fb5103a167a0ff6af9af7", null ],
    [ "m_drink", "class_order.html#a63bdeb49e0d3e8a47a2f24580788a393", null ],
    [ "m_idOrder", "class_order.html#a29d12d747d0669e95c42073106896fb7", null ],
    [ "m_main", "class_order.html#a3a3395871d71ecd32e4cf98f87be32f9", null ],
    [ "m_starter", "class_order.html#a66fb2c5ed01b1a8603e2d99887bccfda", null ],
    [ "m_totalPrice", "class_order.html#ae01870129cac2a755d739412e8231577", null ]
];