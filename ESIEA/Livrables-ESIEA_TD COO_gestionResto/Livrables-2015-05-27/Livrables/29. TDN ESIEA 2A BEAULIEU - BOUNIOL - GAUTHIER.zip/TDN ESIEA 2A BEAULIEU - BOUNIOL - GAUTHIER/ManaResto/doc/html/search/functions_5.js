var searchData=
[
  ['getage',['getAge',['../class_customer.html#afc5c90661966b5df9017c3f034bf341a',1,'Customer']]],
  ['getcustomername',['getCustomerName',['../class_customer.html#a00bec6bbfd8c819e7385d94fc68d97b8',1,'Customer']]],
  ['getname',['getName',['../class_food.html#a7236ca8224db54c61f52e8fb7f6ea8b4',1,'Food']]],
  ['getnamebeverage',['getNameBeverage',['../class_order.html#a2d4177e6b00df49cb7c5698d51654e35',1,'Order']]],
  ['getnamedesert',['getNameDesert',['../class_order.html#ab0610eebc8d069824bc868371c3a7319',1,'Order']]],
  ['getnamemain',['getNameMain',['../class_order.html#a396f0d27e2db4d9f6edf87dbee0be8a7',1,'Order']]],
  ['getnamestarter',['getNameStarter',['../class_order.html#a5e98ca659357d1d3c6d0f35218083287',1,'Order']]],
  ['getprice',['getPrice',['../class_food.html#a544af474da59a53bde55e8af905fb522',1,'Food::getPrice()'],['../class_order.html#a56fe0fbdd832c503af9d0b068d73bd60',1,'Order::getPrice()']]],
  ['gettotalordered',['getTotalOrdered',['../class_food.html#adec00c0686551ea6662e9f8c48aaf989',1,'Food']]],
  ['gettype',['getType',['../class_dish.html#a0acb5c42b3305b42a051b0bf5fb5f79f',1,'Dish']]],
  ['getvolume',['getVolume',['../class_beverage.html#aa5bb1b36ec8ca71a5d01f2f7cf89259c',1,'Beverage']]],
  ['goodbyewindow',['GoodByeWindow',['../class_good_bye_window.html#a2bb01c8a0c084ab063e444656daae018',1,'GoodByeWindow']]]
];
