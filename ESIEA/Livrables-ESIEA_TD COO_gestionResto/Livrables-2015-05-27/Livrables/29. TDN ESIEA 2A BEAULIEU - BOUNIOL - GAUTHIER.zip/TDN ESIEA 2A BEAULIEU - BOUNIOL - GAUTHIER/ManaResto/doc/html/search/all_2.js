var searchData=
[
  ['commandcheckwindow',['CommandCheckWindow',['../class_command_check_window.html',1,'CommandCheckWindow'],['../class_command_check_window.html#a492fba031725848133f015a312a7e68d',1,'CommandCheckWindow::CommandCheckWindow(QWidget *parent=0)'],['../class_command_check_window.html#adbce476b2988e285bea2335a19079c88',1,'CommandCheckWindow::CommandCheckWindow(Customer custo, Order custOrd)']]],
  ['customer',['Customer',['../class_customer.html',1,'Customer'],['../class_customer.html#abcc8fae9701e5ba9d7d6fe44498b34e3',1,'Customer::Customer()'],['../class_customer.html#ae5caa88a62129f3251ae455555ed2402',1,'Customer::Customer(std::string path)'],['../class_customer.html#a1a7377e5f35151b5c24bbb7932e59ee3',1,'Customer::Customer(std::string name, std::string surname, unsigned int age, bool gender)'],['../class_customer.html#afe945d0adabf6ac1d98d9919f1f12d58',1,'Customer::Customer(const Customer &amp;custo)']]]
];
