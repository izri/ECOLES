var class_dish =
[
    [ "Dish", "class_dish.html#ad5e0a97dc1bf5ec1967ca92d63f3f5f9", null ],
    [ "Dish", "class_dish.html#a5ccb0cba975b5dba9036a405a3c2032a", null ],
    [ "getType", "class_dish.html#a0acb5c42b3305b42a051b0bf5fb5f79f", null ],
    [ "saveDish", "class_dish.html#a83d6ad12495c1e1993aeddae0f863a33", null ],
    [ "updateDish", "class_dish.html#ac834d6c97db04260114c1d9122e9ed92", null ],
    [ "m_type", "class_dish.html#a408610d247d15568fe86cdfbde9b1c5e", null ]
];