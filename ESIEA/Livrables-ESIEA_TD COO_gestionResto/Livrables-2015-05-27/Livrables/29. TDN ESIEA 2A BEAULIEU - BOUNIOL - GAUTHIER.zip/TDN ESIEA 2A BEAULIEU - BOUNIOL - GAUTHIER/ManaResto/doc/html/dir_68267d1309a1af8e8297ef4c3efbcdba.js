var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "beverage.h", "beverage_8h_source.html", null ],
    [ "customer.h", "customer_8h_source.html", null ],
    [ "dish.h", "dish_8h_source.html", null ],
    [ "food.h", "food_8h_source.html", null ],
    [ "order.h", "order_8h_source.html", null ],
    [ "processCustomer.h", "process_customer_8h_source.html", null ],
    [ "tools.h", "tools_8h_source.html", null ]
];