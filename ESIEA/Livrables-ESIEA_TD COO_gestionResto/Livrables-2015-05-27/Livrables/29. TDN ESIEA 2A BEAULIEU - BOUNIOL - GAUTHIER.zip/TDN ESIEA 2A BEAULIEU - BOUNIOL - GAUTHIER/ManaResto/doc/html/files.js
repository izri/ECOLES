var files =
[
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "adminpanel.h", "adminpanel_8h_source.html", null ],
    [ "commandcheckwindow.h", "commandcheckwindow_8h_source.html", null ],
    [ "dishselectionwindow.h", "dishselectionwindow_8h_source.html", null ],
    [ "goodbyewindow.h", "goodbyewindow_8h_source.html", null ],
    [ "newcustomerwindow.h", "newcustomerwindow_8h_source.html", null ],
    [ "neworderwindow.h", "neworderwindow_8h_source.html", null ],
    [ "startwindow.h", "startwindow_8h_source.html", null ]
];