var searchData=
[
  ['beverage',['Beverage',['../class_beverage.html',1,'Beverage'],['../class_beverage.html#af77333057395e0bfafc2633d3999f318',1,'Beverage::Beverage()'],['../class_beverage.html#a2a6e250ac12515b5fc3d26e77e6abb47',1,'Beverage::Beverage(std::string name)']]]
];
