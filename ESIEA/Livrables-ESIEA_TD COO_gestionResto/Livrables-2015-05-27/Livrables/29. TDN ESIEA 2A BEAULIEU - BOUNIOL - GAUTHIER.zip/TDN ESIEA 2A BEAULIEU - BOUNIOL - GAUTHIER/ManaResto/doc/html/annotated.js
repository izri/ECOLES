var annotated =
[
    [ "AdminPanel", "class_admin_panel.html", "class_admin_panel" ],
    [ "Beverage", "class_beverage.html", "class_beverage" ],
    [ "CommandCheckWindow", "class_command_check_window.html", "class_command_check_window" ],
    [ "Customer", "class_customer.html", "class_customer" ],
    [ "Dish", "class_dish.html", "class_dish" ],
    [ "DishSelectionWindow", "class_dish_selection_window.html", "class_dish_selection_window" ],
    [ "Food", "class_food.html", "class_food" ],
    [ "GoodByeWindow", "class_good_bye_window.html", "class_good_bye_window" ],
    [ "NewCustomerWindow", "class_new_customer_window.html", "class_new_customer_window" ],
    [ "NewOrderWindow", "class_new_order_window.html", "class_new_order_window" ],
    [ "Order", "class_order.html", "class_order" ],
    [ "StartWindow", "class_start_window.html", "class_start_window" ]
];