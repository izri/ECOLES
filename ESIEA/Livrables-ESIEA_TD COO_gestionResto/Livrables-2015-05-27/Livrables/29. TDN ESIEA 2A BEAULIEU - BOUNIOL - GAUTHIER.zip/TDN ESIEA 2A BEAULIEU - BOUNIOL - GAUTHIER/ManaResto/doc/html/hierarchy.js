var hierarchy =
[
    [ "Customer", "class_customer.html", null ],
    [ "Food", "class_food.html", [
      [ "Beverage", "class_beverage.html", null ],
      [ "Dish", "class_dish.html", null ]
    ] ],
    [ "Order", "class_order.html", null ],
    [ "QDialog", null, [
      [ "AdminPanel", "class_admin_panel.html", null ],
      [ "CommandCheckWindow", "class_command_check_window.html", null ],
      [ "DishSelectionWindow", "class_dish_selection_window.html", null ],
      [ "GoodByeWindow", "class_good_bye_window.html", null ],
      [ "NewCustomerWindow", "class_new_customer_window.html", null ],
      [ "NewOrderWindow", "class_new_order_window.html", null ],
      [ "StartWindow", "class_start_window.html", null ]
    ] ]
];