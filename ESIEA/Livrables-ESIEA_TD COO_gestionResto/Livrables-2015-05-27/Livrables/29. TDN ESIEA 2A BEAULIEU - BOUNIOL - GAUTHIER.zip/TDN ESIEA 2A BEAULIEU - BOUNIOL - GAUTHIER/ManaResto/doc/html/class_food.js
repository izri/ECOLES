var class_food =
[
    [ "Food", "class_food.html#a75d4d7f76fd495cc8133302ca9fdc485", null ],
    [ "Food", "class_food.html#af580c0559edd99ded1ed59081a2b77f1", null ],
    [ "addOrdered", "class_food.html#a74586d80d89e290f1fbd713f839a96e4", null ],
    [ "getName", "class_food.html#a7236ca8224db54c61f52e8fb7f6ea8b4", null ],
    [ "getPrice", "class_food.html#a544af474da59a53bde55e8af905fb522", null ],
    [ "getTotalOrdered", "class_food.html#adec00c0686551ea6662e9f8c48aaf989", null ],
    [ "m_name", "class_food.html#a5daec18293e68de2faf859a80f2d43b7", null ],
    [ "m_price", "class_food.html#a5316e6cd4165f39120e873ea2ec6c256", null ],
    [ "m_totalOrdered", "class_food.html#a6f736bdc134162ea6acef85608f7a2e6", null ]
];