var searchData=
[
  ['addexpense',['addExpense',['../class_customer.html#abfea771a9b1b46727ab33396dbd6c37d',1,'Customer']]],
  ['addordered',['addOrdered',['../class_food.html#a74586d80d89e290f1fbd713f839a96e4',1,'Food']]],
  ['adminpanel',['AdminPanel',['../class_admin_panel.html#a6d9e0c15f45b2b1e63d086272a50ee83',1,'AdminPanel']]],
  ['alcotest',['alcoTest',['../class_beverage.html#affff61c5043efae415fa2d4ebc556b12',1,'Beverage']]]
];
