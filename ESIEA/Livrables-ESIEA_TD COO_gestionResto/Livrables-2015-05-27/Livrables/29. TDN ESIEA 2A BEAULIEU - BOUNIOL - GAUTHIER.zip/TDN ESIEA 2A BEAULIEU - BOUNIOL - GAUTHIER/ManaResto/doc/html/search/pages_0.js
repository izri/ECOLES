var searchData=
[
  ['management_20of_20a_20restaurant_20made_20easy_2e',['Management of a restaurant made easy.',['../index.html',1,'']]]
];
