var class_new_customer_window =
[
    [ "NewCustomerWindow", "class_new_customer_window.html#a018d9a8e01e78a931c4c92a35d7be194", null ],
    [ "NewCustomerWindow", "class_new_customer_window.html#ad8033cde951c70473307077b470da200", null ],
    [ "NewCustomerWindow", "class_new_customer_window.html#a9266b2386f3f80b1c913c69abdc219d0", null ],
    [ "~NewCustomerWindow", "class_new_customer_window.html#aac29933b012d560752a9522647bab549", null ],
    [ "on_Abort_clicked", "class_new_customer_window.html#ab6b30d965ca1fe0dc094ebf455e52570", null ],
    [ "on_Subscribe_clicked", "class_new_customer_window.html#a53fa77912be7281eca681149539486d3", null ],
    [ "m_name", "class_new_customer_window.html#ad50eed1b504b306696916da10c341df8", null ],
    [ "m_surname", "class_new_customer_window.html#ab135322a433d2495ab7fbd89a981a702", null ],
    [ "ui", "class_new_customer_window.html#ae168a63785629daba809fa1158151734", null ]
];