var class_admin_panel =
[
    [ "AdminPanel", "class_admin_panel.html#a6d9e0c15f45b2b1e63d086272a50ee83", null ],
    [ "~AdminPanel", "class_admin_panel.html#ae23b3016841f9f61b90f1148ec42b0a7", null ],
    [ "on_pushButton_clicked", "class_admin_panel.html#a6c662e81ccd728dbd1979a6caf7d4eb1", null ],
    [ "ui", "class_admin_panel.html#a1a93dd01c6ee511614d7218cd448f85b", null ]
];