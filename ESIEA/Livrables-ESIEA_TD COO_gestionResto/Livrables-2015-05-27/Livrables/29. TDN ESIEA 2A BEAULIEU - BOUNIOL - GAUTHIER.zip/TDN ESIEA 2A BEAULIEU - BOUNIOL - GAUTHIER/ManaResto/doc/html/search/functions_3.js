var searchData=
[
  ['dish',['Dish',['../class_dish.html#ad5e0a97dc1bf5ec1967ca92d63f3f5f9',1,'Dish::Dish()'],['../class_dish.html#a5ccb0cba975b5dba9036a405a3c2032a',1,'Dish::Dish(std::string name)']]],
  ['dishselectionwindow',['DishSelectionWindow',['../class_dish_selection_window.html#a3fb4827e765779e56b97f46d6d50ec7e',1,'DishSelectionWindow::DishSelectionWindow(QWidget *parent=0)'],['../class_dish_selection_window.html#adf98cb6184789965023ab89dec1216af',1,'DishSelectionWindow::DishSelectionWindow(Customer custo)'],['../class_dish_selection_window.html#adaba03b8f26b51b71ba058343f415943',1,'DishSelectionWindow::DishSelectionWindow(Customer custo, QString error)']]]
];
