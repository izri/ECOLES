var class_dish_selection_window =
[
    [ "DishSelectionWindow", "class_dish_selection_window.html#a3fb4827e765779e56b97f46d6d50ec7e", null ],
    [ "DishSelectionWindow", "class_dish_selection_window.html#adf98cb6184789965023ab89dec1216af", null ],
    [ "DishSelectionWindow", "class_dish_selection_window.html#adaba03b8f26b51b71ba058343f415943", null ],
    [ "~DishSelectionWindow", "class_dish_selection_window.html#abc1257ba3298858f22e4302fd93f6e16", null ],
    [ "on_Abort_clicked", "class_dish_selection_window.html#a69de1024de90f3c62f776a14d6e3e7bb", null ],
    [ "on_Order_clicked", "class_dish_selection_window.html#a444942769184927d2899af3d8b92f19a", null ],
    [ "m_custo", "class_dish_selection_window.html#a2b7ccc9938885573b0bc25b1bb244157", null ],
    [ "ui", "class_dish_selection_window.html#a717d5789a0e6f75d9ca9821c21f85682", null ]
];