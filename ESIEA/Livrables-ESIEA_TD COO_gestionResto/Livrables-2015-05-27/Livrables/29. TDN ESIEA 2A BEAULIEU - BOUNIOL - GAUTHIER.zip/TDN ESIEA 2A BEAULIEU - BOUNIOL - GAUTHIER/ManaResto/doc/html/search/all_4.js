var searchData=
[
  ['food',['Food',['../class_food.html',1,'Food'],['../class_food.html#a75d4d7f76fd495cc8133302ca9fdc485',1,'Food::Food()'],['../class_food.html#af580c0559edd99ded1ed59081a2b77f1',1,'Food::Food(std::string nameF)']]]
];
