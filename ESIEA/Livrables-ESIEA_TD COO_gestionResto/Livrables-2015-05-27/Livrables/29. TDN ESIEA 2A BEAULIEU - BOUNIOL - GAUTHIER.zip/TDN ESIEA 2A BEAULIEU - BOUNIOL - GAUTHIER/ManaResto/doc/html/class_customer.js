var class_customer =
[
    [ "Customer", "class_customer.html#abcc8fae9701e5ba9d7d6fe44498b34e3", null ],
    [ "Customer", "class_customer.html#ae5caa88a62129f3251ae455555ed2402", null ],
    [ "Customer", "class_customer.html#a1a7377e5f35151b5c24bbb7932e59ee3", null ],
    [ "Customer", "class_customer.html#afe945d0adabf6ac1d98d9919f1f12d58", null ],
    [ "addExpense", "class_customer.html#abfea771a9b1b46727ab33396dbd6c37d", null ],
    [ "getAge", "class_customer.html#afc5c90661966b5df9017c3f034bf341a", null ],
    [ "getCustomerName", "class_customer.html#a00bec6bbfd8c819e7385d94fc68d97b8", null ],
    [ "newVisit", "class_customer.html#a38b08f24c6a9c7462e45bc0926ac71ff", null ],
    [ "saveCustomer", "class_customer.html#ae28839cc72495677a742e016b4605990", null ],
    [ "saveLastID", "class_customer.html#ac1b2d04a2517ad31c3cef605a285f235", null ],
    [ "updateCustomer", "class_customer.html#a80f38d9f2e1a1f4f330f63dbdda0e7b1", null ],
    [ "m_age", "class_customer.html#a6d311ab6848e14397b24eb3831d0072c", null ],
    [ "m_gender", "class_customer.html#a77bb50b736b789c38f15ed6d44637f61", null ],
    [ "m_id", "class_customer.html#ab01ef5fd44759a641dd3310b5831a96c", null ],
    [ "m_name", "class_customer.html#a057b496cea465ca4c527f71be2ac979f", null ],
    [ "m_totalExpense", "class_customer.html#a15c86983248c90038b56f41f3ddf956c", null ],
    [ "m_totalVisit", "class_customer.html#a6e2bbdc0e4f8d1d571217f7ca14b1fa0", null ]
];