var class_new_order_window =
[
    [ "NewOrderWindow", "class_new_order_window.html#af8b226a53164e912d050343d26edcb41", null ],
    [ "NewOrderWindow", "class_new_order_window.html#ae5388312b8d8c796fd6c604ec8fad25d", null ],
    [ "~NewOrderWindow", "class_new_order_window.html#ac276dd3196bebb3f07ba28d62584854f", null ],
    [ "on_Abort_clicked", "class_new_order_window.html#a74334f8a580cc8ca3104620424fa19d9", null ],
    [ "on_Proceed_clicked", "class_new_order_window.html#a4e0311277f065aa1ebd9436508eb848d", null ],
    [ "ui", "class_new_order_window.html#ac646f2b93b410d6cc659f1ceaaa1f899", null ]
];