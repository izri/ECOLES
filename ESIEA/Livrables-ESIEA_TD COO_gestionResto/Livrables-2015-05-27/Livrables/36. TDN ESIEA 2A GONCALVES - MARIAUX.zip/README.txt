Le progrmme que nous avons r�alis� demande a l'utilisateur de rentrer la carte du restaurant, les menus propos�s, etc. 
Puis propose d'enregistrer un client et de passser une commande.

Nous avons �t� un peu pris de court par la date de rendu, donc nous n'avons pas pu remplir les objectifs que nous nous �tions fix�s et nous sommes concentr�s sur la r�alisation d'un progamme fonctionnel, m�me si il ne correspond pas du tout a ce que nous voulions faire a l'origine.