Ce projet était le bienvenue dans notre apprentissage car nous, les étudiants,  étant assez formatés sur les projets en langage C, avions besoin d'un exemple concret sur cette évolution appelé C++. 
Une première étape de réflexion sur le cahier des charges ainsi qu'un diagramme pour illustrer le travail à effectuer. 
Ainsi nous avons pu mettre en place les différentes fonctions d'analyse répertoriant les meilleurs clients et les produits les plus vendus.
Une interface graphique pourrait être insérée pour une utilisation plus intuitive.
Une fonction main est créée pour tester et circuler dans l'ensemble du programme.
