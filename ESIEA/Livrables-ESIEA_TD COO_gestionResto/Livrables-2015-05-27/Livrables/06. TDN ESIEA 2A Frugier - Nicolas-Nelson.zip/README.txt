Nous avons effectu� toutes les fonctions du diagramme de classe, mais avons fait un main tr�s
simpliste afin de les tester.

Nous avons choisit de ne pas faire d'historique car ceci fait un doublon avec la commande, il 
aurait �t� utile d'en faire en utilisant une base de donn�es, mais dans le cadre d'un programme en
C++ pur ceci aurait �t� inutile.