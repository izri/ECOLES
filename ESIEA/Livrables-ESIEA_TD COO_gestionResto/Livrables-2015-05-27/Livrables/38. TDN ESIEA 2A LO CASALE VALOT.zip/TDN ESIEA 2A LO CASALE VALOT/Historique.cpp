#include <iostream>
#include "Historique.hpp"
#include <string>
#include <cstring>

using namespace std;

Historique::Historique(int n){
    id_commande = NULL;
    id=1;
}
