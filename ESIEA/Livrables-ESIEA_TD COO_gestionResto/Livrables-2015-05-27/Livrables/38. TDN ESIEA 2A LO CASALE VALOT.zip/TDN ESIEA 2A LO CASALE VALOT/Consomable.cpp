#include <iostream>
#include "Consomable.hpp"


using namespace std;

