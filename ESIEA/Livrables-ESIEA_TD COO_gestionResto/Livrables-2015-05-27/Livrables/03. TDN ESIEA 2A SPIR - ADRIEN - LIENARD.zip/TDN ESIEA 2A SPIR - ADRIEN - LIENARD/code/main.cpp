//
//  main.cpp
//  TP
//
//  Created by Taiki on 24/03/2015.
//  Copyright (c) 2015 Taiki. All rights reserved.
//

#include "main.hpp"

using namespace std;

int main()
{
	Resto().runResto();
	return 0;
}