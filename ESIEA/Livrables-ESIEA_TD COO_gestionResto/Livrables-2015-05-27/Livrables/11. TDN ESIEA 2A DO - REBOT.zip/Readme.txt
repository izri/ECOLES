Le principal obstacle dans ce td est le langage. En effet, le C++ est un langage qu'on a du apprendre seul avec le site 
openclassroom ou autre. Il fallait aussi assimil� la notion de classe et d'objet orient� ce qui �tait assez difficile au 
d�part. Les premi�res semaines servaient surtout � l'assimilation des notions et des bases du langage. Au d�but, c'�tait assez difficile mais
une fois qu'on avait assimil� les bases, c'�tait plutot simple vu que c'�tait bas� aussi sur le C. 
En groupe, on a r�fl�chit opt� pour certaines fonctions pour le restaurant comme le syst�me d'�toile. Il fallait ensuite tout mettre en pratique.
Il y a un "menu" auquel on peut chercher un utilisateur, enregistr� un utilisateur, prendre une commande pour un client d�j� enregistr� ou quitter. 
Pour l'enregistrement qui nous sert de base de donn�e, j'utilise une liste chain�e comme dans le langage C. Une fonction auxiliaire permet de faire 
une recherche sur la liste et une classe me permet de d�finir ma "structure".
