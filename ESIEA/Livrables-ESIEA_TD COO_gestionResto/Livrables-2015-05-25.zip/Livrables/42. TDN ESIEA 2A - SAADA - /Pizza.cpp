#include "Pizza.h"

Pizza::Pizza (string nom, unsigned int prix) : Plat::Plat(nom, prix) {

}
