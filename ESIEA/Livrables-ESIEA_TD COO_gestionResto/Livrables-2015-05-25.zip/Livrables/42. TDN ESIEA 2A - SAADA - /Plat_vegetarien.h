#include "Plat.h"

/// class Plat_vegetarien -
class Plat_vegetarien : public Plat {

    // Operations
public:
    Plat_vegetarien (string nom, unsigned int prix);
    void  aff ();
};
