#include "Plat.h"

/// class Pizza -
class Pizza : public Plat {

    // Operations
public:
    Pizza (string nom, unsigned int prix);
    void  aff ();
};

