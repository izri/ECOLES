#include "Dessert.h"

Dessert::Dessert (string nom, unsigned int prix) : Plat::Plat(nom, prix) {

}
