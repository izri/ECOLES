#include "Plat.h"

/// class Plat_du_jour -
class Plat_du_jour : public Plat {

    // Operations
public:
    Plat_du_jour (string nom, unsigned int prix);
    void  aff ();
};
