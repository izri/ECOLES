#include "Plat_vegetarien.h"

Plat_vegetarien::Plat_vegetarien (string nom, unsigned int prix) : Plat::Plat(nom, prix) {

}
