#ifndef RESTAURANT_HH_
# define RESTAURANT_HH_

# include "Client.hh"
# include "Parser.hh"

# define UNUSED(a)	__attribute__((unused))a

#endif
