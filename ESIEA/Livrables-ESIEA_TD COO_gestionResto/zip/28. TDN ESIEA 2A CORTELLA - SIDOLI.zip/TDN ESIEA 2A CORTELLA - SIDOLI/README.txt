///// HONNETE AVANCEMENT + FONCTIONNEMENT /////

Ce projet est un outil de gestion de client développé en c++ qui permet de sauvegarder les profils des clients
pour leur proposer un service de qualité.

L'utilisation du logiciel "restaurant" est la suivante: Il se lance sans argument et propose une interface
utilisateur dans laquelle nous pouvons rentrer des commandes. En tapant "help" nous avons accès à la liste des commandes.

La première est "new client" qui permet l'ajout, via un formulaire, d'un nouveau client.
La seconde est "display clients" qui permet d'afficher l'historique de tous les clients déjà enregistrés.

Pour quitter il suffit d'appuyer sur ctrl + d.

//// CE QU'ON A PAS PU FAIRE ////

Nous n'avons pas implémenter toutes les classes nécessaires concernants les produits (desserts, pizzas, plats et boisson)
Nous avons bien compris le système d'héritage et nous regrettons d'avoir manqué de temps sur ce point.
