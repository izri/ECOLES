Ce programme a �t� r�alis� en se servant du mod�le donn� sur le Drive par les professeurs d'informatique. 
Il a fallu un long temps d'adaption au travail de la conception orient�e objet en C++.
C'est pourquoi, bien que la plupart des parties importantes du diagramme ont �t� r�alis�, tout n'a pas �t� finalis�.
Ce programme a repris la distribution en fichiers .hpp et .cpp mais il a �t� ajout� plusieurs fonctions et aussi crit�res.
Par exemple un client a en plus du nom et du genre, un �ge, un nombre de venues dans le restaurant, la valeur totale de ses d�penses ainsi qu'un identifiant pour pouvoir
le reconna�tre dans un historique des clients.
De plus, un produit a un nombre, car il peut �tre command� en plusieurs exemplaires, ainsi qu'une marge. Le prix et marge du produit changent en fonction
du nombre de produits vendus � la commande.
On a essay� par la suite de d�finir ce qu'�tait un "meilleur client" en se basant sur une valeur minimum de d�penses. 
Cette op�ration est effectu�e afin de r�duire l'historique des clients � un fichier meilleur client (dans le code sous forme de liste).

Le fichier principal est "resto.cpp".