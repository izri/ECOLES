#ifndef COMMAND_H
#define COMMAND_H


class command
{
    public:
        command();
        virtual ~command();
    protected:
    private:
};

#endif // COMMAND_H
