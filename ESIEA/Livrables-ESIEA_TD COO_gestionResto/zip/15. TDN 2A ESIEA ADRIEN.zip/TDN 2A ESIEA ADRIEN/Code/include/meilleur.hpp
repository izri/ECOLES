#ifndef MEILLEUR_H
#define MEILLEUR_H


class Meilleur
{
    public:
        Meilleur();
        virtual ~Meilleur();
    protected:
    private:
};

#endif // MEILLEUR_H
