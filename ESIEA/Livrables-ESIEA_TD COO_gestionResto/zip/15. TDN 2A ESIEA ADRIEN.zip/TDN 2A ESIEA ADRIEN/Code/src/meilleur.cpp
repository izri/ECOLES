#include "meilleur.hpp"

Meilleur::Meilleur()
{
    //ctor
}

Meilleur::~Meilleur()
{
    //dtor
}
