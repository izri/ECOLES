#include <iostream>
#include <string>

//Prototypes
class Client;
class Product;
class Command;