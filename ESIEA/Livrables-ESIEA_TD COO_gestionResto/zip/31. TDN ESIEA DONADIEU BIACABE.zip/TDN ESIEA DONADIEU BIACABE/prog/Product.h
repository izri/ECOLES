#ifndef DEF_PRODUCT
#define DEF_PRODUCT
#include <string>
#include <iostream>

class Product

{
public:

Product();
unsigned int Infoproduit();
unsigned int prix[5]={6, 8, 10 ,5 ,2}; //6 pizzas, 8 PJ, 10 PV, 5 dessert, 2 boisson;
unsigned int com;

};




#endif // PRODUCT_INCLUDED
