Pierre Balthazar Donadieu de Lavit Jeremy Biacabe

J'ai essay� de faire le maximum de ce que j'ai pu comprendre.
Cependant je reste bloqu� par des erreurs de types que je ne comprends pas, 
le syst�me d'heritage et de communication entre les classes reste pour moi obscur.
Je sais que d'un point de vue algorithmique le programme est 
simple mais il a �t� pour moi plus que difficile de le traduire 
en langage informatique.
N'ayant pas re�us de nouvelle de mon bin�me je part du principe 
que le cahier des charges n' a pas �volu� de m�me que le diagramme
 de classe et cela m�me si je n'ai pas pu les respecter.
Par ailleur s'il vous a �galement envoy� un mail je vous prierais
Madame de garder le projet le plus aboutis.