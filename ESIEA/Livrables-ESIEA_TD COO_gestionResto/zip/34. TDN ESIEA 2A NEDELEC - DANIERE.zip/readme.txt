//PARTIE CLIENT

Nous avons r�aliser un programme en C++ qui simule un logiciel de gestion applicable dans un restaurant.
On peut imaginer ce programme comme une "borne" de commande qui permet au client de choisir ce qu'il souhaite et qui
permet � l'administrateur en entrant son mots de passe d'acc�der � la page d'administration.
Le C++ est un language que nous d�couvrons, mais en 1 mois d'apprentissage nous avons quand m�me pu r�aliser un programme
int�ressant.

Concr�tement lorsque le programme se lance il propose au client 1)Entree 2)Plats 3)Desserts c'est lors de cette demande
qui r�apparaitra � chaque nouveau client que l'administrateur pourra acc�der � la page admin en tapant son mot de passe.

Ensuite en choisissant entree plat ou dessert le programme propose diff�rent choix, puis une fois que le client a fait son
choix le programme lui demande s'il souhaite commander autre chose. Sinon le programme lui propose de choisir un mode de paiement
, puis on passe au client suivant.

Le Client a aussi la possibilit� d'annuler son ticket, on de supprimer des articles choisis par hasard 1 par 1.

//PARTIE ADMINISTRATION

La partie administration est accessible en tapant le mot de passe.

Ensuite on peut consulter le nombre de client de la journ�e ou bien des statistiques.


Les statistiques permettent de savoir combien d'entr�e plat ou dessert de chaque types ont �t� pris, elle permettent aussi de savoir
quels ont �t� les moyens de paiements de la journ�es.
Enfin l'option sauvegarder, permet de sauvegarder l'historique de la journ�e avant de quitter le programme pour pouvoir �tudier les choix
de la client�le sur de longue p�riode.





