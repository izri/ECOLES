#include "Produit.h"

using namespace std;

int ClassementClientPrix(std::string NomClient,int PrixTotalClient,int tabClientPrix[])
{

}

int ClassementClientPrix(std::string NomClient,int PrixTotalClient,int tabClientPrix[])
{

}

int ClassementProduit(std::string NomProduit,int PopulariteProduit, int tabProduit[])
{

}
