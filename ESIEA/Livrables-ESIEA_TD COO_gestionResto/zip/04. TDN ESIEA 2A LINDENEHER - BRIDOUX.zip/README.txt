Rendu du TP2 (les classes) - Cl�ment Lindeneher / Clara Bridoux (2B2)

Utilisation du programme :

Le menu est intuitif et simple d'utilisation. Au d�marrage il faut cr�er un nouveau client. Une fois cr��, on peut ajouter des commandes (taper 5), ajouter des clients (taper 2), changer le client en cours de modification (taper 1) ou encore voir les statistiques du restaurant (taper 6).

Remplissage automatique :

Au d�marrage du programme, copier-coller directement la suite d'instructions suivante afin de cr�er un base pour tester le programme (les sauts de ligne sont importants)
--� coller--
1
Clement
Lindeneher
2
Clara
Bridoux
5
1
1
1
6
12
0
0
1
1
9
12
3
0
0
3
1
1.8
2
4
0
0
1
1
5
1
1
1
6
6
11
0
0
1
1
10
0
0
1
1
3
0
0
3
1
4.5
2
5
3
2
0
0

--fin � copier--
Ces instructions cr�ent 2 clients : Cl�ment avec 3 commandes, Clara en a 2.

Point d'avancement :

Par rapport � la premi�re version du CDC, nous n'avons pas r�alis� les fonctionnalit�s de statistiques pour un client particulier. En effet nous voulions ajouter ces fonctions afin d'utiliser un peu plus l'h�ritage. Or les changements effectu�s sur les classes AllClients et AllStats ne permettaient plus l'utilisation de l'h�ritage.