Ce programme cod� en C++ r�alise l'ensemble des fonctions attendu pour la gestion de commande d'un restaurant soit:

-Afficher la date
-Cr�er un client
-Lui ajouter une commande
-Ajouter un ou plusieurs produits � la commande
-Calculer le prix total de la commande
-Afficher les d�tails de la commande

Il est �galement possible de conna�tre la fr�quence du client ainsi que le d�tail exact de ses commandes gr�ce � l'historique.

L'utilisation est tr�s simple gr�ce � l'interface propos�e (sur terminal) dot�e d'une saisie s�curis�e.

Les classes client, produit et commande sont s�par�s dans des fichiers bien distincts avec leur header qui leur correspond.