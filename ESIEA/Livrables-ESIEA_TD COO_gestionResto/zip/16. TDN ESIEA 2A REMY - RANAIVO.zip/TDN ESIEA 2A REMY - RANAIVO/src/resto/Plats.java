package resto;

public class Plats {
	//Attributs
	int price;
	
	//M�thodes
	void menu(){
		
		System.out.println("******Menu******");
		System.out.println("1 - Boisson");
		System.out.println("2 - Pizza");
		System.out.println("3 - Plat du jour");
		System.out.println("4 - Plat v�g�tarien");	
		System.out.println("5 - Dessert");	
	}
}