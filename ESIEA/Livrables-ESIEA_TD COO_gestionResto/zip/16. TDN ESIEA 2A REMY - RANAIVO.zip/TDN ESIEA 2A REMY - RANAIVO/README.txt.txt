Etat d'avancement:
Le programme cr�e ou lit une fiche client, on peut afficher la liste de tous les clients. Il permet aussi de commander des plats, de donner un pourboire, d�afficher la somme totale � payer, le meilleur client selon le nombre de visite ou selon les d�penses.

Classes cr��es : 
-Client (nom, age, nombre de visite, mail, statut, somme totale, Affichage Fiche client, Cr�ation Fiche client, pourboire)
-Plats (prix+ affichage du menu)
-Commande (Affiche menu et choix des plats+Pourboire)
-XMLTools = Historique (sauvegarde des donn�es dans un fichier XML)
-Resto = Main (appel toute les autres fonctions + meilleur client)
-Boisson (coca, sprite, eau, jus de fruits + Affichage)
-Pizza (fromage, marguarita, sicilienne, paysanne + Affichage)
-PlatDuJour (blanquette + Affichage)
-V�g�tarien (lasagne, salade, tofu + Affichage)
-Dessert (tarte, glace, creme, fruits + Affichage)
