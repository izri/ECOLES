<?php 


//Exercice 2
class Vehicule 
{
	var $marque; 
	var $couleur; 
	var $kilometre; 
	var $qteCarburant; 
	var $marche; 
	
	function __Construct()
	{
	$num = func_num_args(); 
	$args = func_get_args();
	switch($num)
	{
		
		case 5 : 
		{$this -> Marque = $arg[0]; 
		$this -> couleur = $arg[1]; 
		$this -> kilometre = $arg[2];
		$this -> qteCarburant = $arg[3] ;
		$this -> marche = $arg[4] ;
		break ; }
		
		default : echo "erreur"; 
	}
	}
	function Affichage() 
	{
		echo "Le vehicule de marque " . $this -> marque . " a fait " . $this -> kilometre ", contient " . $this -> qteCarburant "</br>"
		if ($this -> marche == 1) 
			echo "est en marche"; 
	}
	
	function arret() 
	{
		if ($this -> marche == 1 ) 
			$this -> marche == 0 ;
			echo "Le vehicule est à l'arret </br>"; 
	}
	
	function roule()
	{
		$this -> marche = 1 ; 
		$this -> kilometre += 1 ; 
		$this -> qteCarburant-- ;
	}
}



//Exercice3

class Train extends Vehicule
{
	var $typedetrain
	var $nbwagons
	
		function __construct()
		{
			$num = func_num_args(); 
			$args = func_get_args();
			switch($num)
				{
					case 0 : 
					{
						$this -> TypeTrain = $args[0];
						$this -> NbWagon = $args[1] ;
						break ; 
					}
					default : echo "Erreur"; 
				}
		}
	function Affichage() 
	{
		echo "<hr><hr>";
		parent::affichage();
		echo "Le train est de catégorie  " . $this -> TypeTrain ", et a  " . $this -> NbWagon" wagons. <br><hr>"
	}
}



class Voiture extends Vehicule
{
	var $typedecarburant; 
	var $nbportesvoiture; 
	
	function __construct()
	{
		$num = func_num_args(); 
		$args = func_get_args();
		switch($num)
		{
			case 0 : 
			{
				$this->marque=$args[0];
			    $this->couleur=$args[1];
			    $this->kilometres=$args[2];
			    $this->qteCarburant=$args[3];
				$this -> marche = $arg[4] ;
				$this -> typedecarburant= $args[5] ;
				$this -> nbportesvoiture = $args[6];
				break ; 
			}
	
			default : 
				echo "Erreur";
				break;
		}	
	}
	function Affichage() 
	{
		echo "<br>";
		parent::affichage();
		echo "Le véhicule contient un carburant de type  " . $this -> TypeCarburant . " et a  " . $this -> NbPorte ." portes. </br>"
	}
}



//Exercice4

$myVehi=new Vehicule("Fiat", "Gris", 120000, 50,0);
$myVehi->Affichage();
$myVehi->roule();
$myVehi->arret();
$myVoit=new Voiture("Bentley", "Noir", 30000, 25,1, "Diesel",5);
$myVoit->Affichage();
$myVoit->roule();
$myVoit->arret();
$myTrain=new Train("Eurostar",10);
$myTrain->Affichage();
$myTab = array($myVehi, $myVoit, $myTrain);
	foreach ($myTab as $key => $value) 
	{
		$value->affichage();
	}


?>