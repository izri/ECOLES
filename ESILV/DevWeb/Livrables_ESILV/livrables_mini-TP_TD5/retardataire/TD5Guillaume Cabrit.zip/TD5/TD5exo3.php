<?php

class véhicule {	
var $marque;
	var $couleur;
	var $kilometre;
	var $qtcarburant;
	
	function __construct(){
		// Récupérer le nombre de paramètres en arguments
		$nb=func_num_args();
		// L'ensemble des arguments
		$arguments=func_get_args();
		
		switch ($nb)
		{
			case 0: //constructeur par défaut
				$this->marque="mercedes";
				$this->couleur="gris";
				$this->kilometre=0;
				$this->qtcarburant=0;break;
				
			 case 1	:
			 $this->marque=$arguments[0];
			 $this->couleur=$arguments[1];
			 $this->kolimetre=$arguments[2];
			 $this->qtcarburant=$arguments[4];break;	
			 
			 default :
			 echo "erreur"; break;
		}
		
		/*méthodes getter et setter */
		/* Respect du principe d'encapsulation */
		
		function getMarque(){
			return $this->marque;
		}
		function getCouleur(){
			return $this->couleur;
		}
		function getKilometre(){
			return $this->kilometre;
		}
		function getQteCarbu(){
			return $this->qtcarburant;
		}
		
		function setMarque($marq){
			$this->marque=$marq;
		}
		function setCouleur($col){
			$this->couleur=$col;
		}
		function setKilometre($kilo){
			$this->kilometre=$kilo;
		}
		function setQteCarbu($qte){
			$this->qtcarburant=$qte;
		}
		
		
		
		
		function affichage(){
			echo "Marque du véhivule : ".$this->getMarque."</br>";
			echo "Couleur : ".$this->getCouleur."</br>";
			echo "Kilomètres : ".$this->getKilometre."</br>";
			echo "Quantitée de carburant : ".$this->getQteCarbu."</br>";		
		}
		
		function arret(){
			if($this->etat == true) $this->etat=false;
			echo " le vehicule est a 1 arrêt </br>";
		}
		
		function roule(){
			if($this->etat==false){
				$this->etat=true;
				$this->kilometre++;
				$this->qtcarburant--;
			}
		}
	}
	
}

class voiture extends véhicule{
	var $carburant;
	var $nbportes;
	
	function __construct(){
		parent::construct();
		switch ($nb)
		{
			case 0: //constructeur par défaut
				$this->marque="mercedes";
				$this->couleur="gris";
				$this->kilometre=0;
				$this->qtcarburant=0;
				$this->carburant="diesel";
				$this->nbportes=3;break;
				
			 case 1	:
			 $this->marque=$arguments[0];
			 $this->couleur=$arguments[1];
			 $this->kolimetre=$arguments[2];
			 $this->qtcarburant=$arguments[4];
			 $this->carburant=$arguments[5];
			 $this->nbportes=$arguments[6];break;	
			 
			 default :
			 echo "erreur"; break;
		}
	}
	
	function getMarque(){}
	function getCouleur(){}
	function getKilometre(){}
	function getQteCarbu(){}
	function getCarbu(){
			return $this->carburant;
		}
	
	function getNbportes(){
			return $this->nbportes;
		}
		
	function setMarque($marq){}
	function setCouleur($col){}
	function setKilometre($kilo){}
	function setQteCarbu($qte){}
	function setCarbu($carbu){
			$this->carburant=$carbu;
		}
		
	function setNbportes($nbp){
			$this->nbportes=$nbp;
		}	
}


class train extends véhicule{
	var $type;
	var $nbwagons;
	
	function __construct(){
		parent::construct();
		switch ($nb)
		{
			case 0: //constructeur par défaut
				$this->marque="mercedes";
				$this->couleur="gris";
				$this->kilometre=0;
				$this->qtcarburant=0;
				$this->type="RER";
				$this->nbwagons=11;break;
				
			 case 1	:
			 $this->marque=$arguments[0];
			 $this->couleur=$arguments[1];
			 $this->kolimetre=$arguments[2];
			 $this->qtcarburant=$arguments[4];
			 $this->type=$arguments[5];
			 $this->nbwagons=$arguments[6];break;	
			 
			 default :
			 echo "erreur"; break;
		}
		
	}
	
	function getMarque(){}
	function getCouleur(){}
	function getKilometre(){}
	function getQteCarbu(){}
	function getType(){
			return $this->type;
		}
		
	function getNbwagons(){
			return $this->nbwagons;
		}
	 
	
	function setMarque($marq){}
	function setCouleur($col){}
	function setKilometre($kilo){}
	function setQteCarbu($qte){}
	function setType($ty){
			$this->type=$ty;
		}
		
	function setNbwagons($nbw){
			$this->nbwagons=$nbw;
		}	
}


$tab = (voiture, train);














?>