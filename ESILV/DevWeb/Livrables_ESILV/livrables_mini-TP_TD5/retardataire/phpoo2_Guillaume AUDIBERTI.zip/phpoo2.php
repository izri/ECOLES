<?php

class Vehicule {

	var $Marque;
	var $couleur;
	var $kilometres;
	var $qteCarb;
	var $marche;

	function __construct()
	{
		$num = func_num_args();
		$arg = func_get_args();

		switch($num)
		{
			case 0: 
			{
				$this -> Marque = "RENAULT";			
				$this -> couleur = "rouge";
				$this -> kilometres = 0;
				$this -> qteCarb = 10;
				$this -> marche = 0;
				break;
			}

			case 5: 
			{
				$this -> Marque = $arg[0];			
				$this -> couleur = $arg[1];
				$this -> kilometres = $arg[2];
				$this -> qteCarb = $arg[3];
				$this -> marche = $arg[4];
				break;
			}

			default : echo "erreur";
		} 
	}

	function affichage()
	{
		echo "Le vehicule de marque ".$this -> Marque." de couleur ".$this -> couleur. " contenant ".$this -> qteCarb." L de carburant 
		ayant parcouru ".$this -> kilometres." kilomètres";
		if ($this -> marche == 1)
			echo " est en marche.</br>";
		else
			echo " est à l'arrêt.</br>";
	}

	function arret() 
	{
		if ($this -> marche == 1)
			$this->marche=0;
		echo "Le vehicule s'ârrete.</br>";
	}

	function roule()
	{
		$this->marche=1;
		$this->kilometres+=1;
		$this->qteCarb--;
		echo "Le vehicule roule 1km pour 1L d'essence.</br>";
	}

}

class Voiture extends Vehicule {

	var $NbrPortes;
	var $typeCarb;

	function __construct()
	{
		parent::__construct();
		$num = func_num_args();
		$arg = func_get_args();

		switch($num)
		{
			case 0: 
			{
				$this -> typeCarb = "a";
				$this -> NbrPortes = 0;
				break;
			}

			case 2: 
			{
				$this -> typeCarb = $arg[0];			
				$this -> NbrPortes = $arg[1];
				break;
			}

			default : echo "erreur";
		} 
	}

	function affichage()
	{
		parent::affichage();
		echo "Ce vehicule possède ".$this -> NbrPortes." portes et tourne au ".$this -> typeCarb."</br>";
	}

}

class Train extends Vehicule {

	var $type;
	var $NbrWagons;

	function __construct()
	{
		parent::__construct();
		$num = func_num_args();
		$arg = func_get_args();

		switch($num)
		{
			case 0: 
			{
				$this -> type = "c";
				$this -> NbrWagons = 0;
				break;
			}

			case 2: 
			{
				$this -> type = $arg[0];			
				$this -> NbrWagons = $arg[1];
				break;
			}

			default : echo "erreur";
		} 
	}

	function affichage()
	{
		parent::affichage();
		echo "Ce vehicule est un ".$this -> type." et possède ".$this -> NbrWagons." wagons</br>";
	}

}

$tabVehichule = [];

$vehicule1 = new Vehicule("BMW","noir",110,40,0);
$tabVehichule[0]=$vehicule1;
$voiture1 = new Voiture("diesel",5);
$tabVehichule[1]=$voiture1;
$train1 = new Train("TGV",14);
$tabVehichule[2]=$train1;

$tabVehichule[0]->affichage();
$vehicule1->Roule();
$vehicule1->affichage();
$vehicule1->arret();
$vehicule1->affichage();
echo "****************************</br>";
$tabVehichule[1]->affichage();
$voiture1->roule();
$voiture1->affichage();
echo"*****************************</br>";
$tabVehichule[2]->affichage();
$train1->roule();
$train1->affichage();

?>