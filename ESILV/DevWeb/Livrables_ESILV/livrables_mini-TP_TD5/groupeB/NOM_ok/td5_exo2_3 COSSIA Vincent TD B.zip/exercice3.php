<?php
class Voiture{
	//attributs
	var $typeCarbu;
	var $nbPortes;

	//Constructeurs
	function __construct (){
		$nb=func_num_args();
		$arguments=func_get_args();

	switch($nb)
		{
			case 0: //constructeur par défaut
					$this->typeCarbu="diesel"; 
					$this->nbPortes=3; break;
			case 1: $this->typeCarbu=$arguments[0]; 
					$this->nbPortes=$arguments[1]; break;
			default: echo "erreur"; break;
		}
	}

	//méthodes getter & setter
	function getTypeCarbu(){
		return $this->typeCarbu;
	}

	function getNbPortes(){
		return $this->nbPortes;
	}

	function setTypeCarbu ($typc){
		$this->typeCarbu=$typc;
	}

	function setNbPortes ($nbp){
		$this->nbPortes=$nbp;
	}

	function affichage(){
		echo "La voiture consomme du " . $this->getTypeCarbu() .
		" et est équipée d'un nombre de portes égales à : " . $this->getNbPortes() . "</br>";
	}
}

class Train{
	var $type;
	var $nbwagons;

	function __construct (){
		$nb=func_num_args();
		$arguments=func_get_args();

	switch($nb)
		{
			case 0: //constructeur par défaut
					$this->type="TGV"; 
					$this->nbwagons=12; break;
			case 1: $this->type=$arguments[0]; 
					$this->nbwagons=$arguments[1]; break;
			default: echo "erreur"; break;
		}
	}

	//méthodes getter & setter
	function getType(){
		return $this->type;
	}

	function getNbwagons(){
		return $this->nbwagons;
	}

	function setType ($typ){
		$this->type=$typ;
	}

	function setNbwagons ($nbw){
		$this->nbwagons=$nbw;
	}

	function affichage(){
		echo "Le " . $this->getType() .
		" est équipé d'un nombre de wagons égale à : " . $this->getNbwagons() . "</br>";
	}
}

?>