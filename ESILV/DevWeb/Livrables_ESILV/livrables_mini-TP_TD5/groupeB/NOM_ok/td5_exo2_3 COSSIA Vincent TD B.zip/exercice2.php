<?php
class Vehicule{
	var $marque;
	var $couleur;
	var $kilometre;
	var $qteCarbu;
	var $etat=false;

	function __construct (){
		$nb=func_num_args();
		$arguments=func_get_args();

		switch($nb){
			case 0: //constructeur par défaut
					$this->marque="t";
					$this->couleur="b";
					$this->kilometre=0;
					$this->qteCarbu=0;
					break;
			case 4: //constructeur paramétré
					$this->marque=$arguments[0];
					$this->couleur=$arguments[1];
					$this->kilometre=$arguments[2];
					$this->qteCarbu=$arguments[3];
					break;
			default: echo "erreur"; break;
		}
	}

	//méthodes getter & setter
	function getMarque(){
		return $this->marque;
	}

	function getCouleur(){
		return $this->couleur;
	}

	function getKilometre(){
		return $this->kilometre;
	}

	function getQteCarbu(){
		return $this->qteCarbu;
	}

	function setMarque ($marq){
		$this->marque=$marq;
	}

	function setCouleur ($col){
		$this->couleur=$col;
	}

	function setKilometre ($km){
		$this->kilometre=$km;
	}

	function setQteCarbu ($qte){
		$this->qteCarbu=$qte;
	}

	//méthode
	function affichage(){
		echo "Le véhicule de marque " . $this->getMarque() .
		" de couleur " . $this->getCouleur() .
		"ayant un kilométrage de : " . $this->getKilometre() .
		"contient " . $this->getQteCarbu() . "</br>";
	}

	function arret(){
		if($this->etat ==true) $this->etat=false;
		echo "le véhicule est à l'arret </br>";
	}

	function roule(){
		if($this->etat == false){
			$this->etat = true;
			$this->kilometre++;
			$this->qteCarbu--;
		}
	}
}