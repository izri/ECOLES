﻿<HTML lang='fr'>
	<HEAD>
		<META charset="utf-8"/>
		<TITLE>TD 05 PHP orienté objet</TITLE>
	</HEAD>

	<BODY>
		<?PHP
		//Exercice 2
		class Véhicules {
			//Attributs
			var $_marque;
			var $_couleur;
			var $_nbreKm;
			var $_qtéCarburant;
			
			//Constructeur
			function Commande(){ //surcharge de méthodes
				//récupérer le nombre de paramétre en arguments
				$nombre=func_num_args();
				//récupérer l'ensemble des arguments
				$arguments=func_get_args();
				
				switch($nombre)
				{
					case 0: //Constructeur par défaut
							$this->_marque="";
							$this->_couleur="";
							$this->_nbreKm="";
							$this->_qtéCarburant="";
							break;
					case 5: //Constructeur paramétré
							$this->_marque= $arguments[0];
							$this->_couleur= $arguments[1];
							$this->_nbreKm= $arguments[2];
							$this->_qtéCarburant= $arguments[3];
							$this->_roule=$arguments[4];
							break;
					default:echo "Erreur";
							break;
				}
			}
			
			//Méthodes
			function Afficher(){ //permet d'afficher les informations du véhicule.
				echo"Marque du véhicule : ". $this->_marque ."</BR>";
				echo"Couleur du véhicule : ".$this->_couleur ."</BR>";
				echo"Kilométrage du véhicule : ".$this->_nbreKm ."<BR>";
				
				/*Si le carburant restant est >= 20 litres il affiche le volume restant. 
				Si le carburant restant est compris entre 0 et 20 litres il affiche un message d'alerte.
				Si le carburant restant est <= 0 litre il affiche un message indiquant qu'il n'y a plus de carburant*/
				if ($this->_qtéCarburant > 20) {
					echo "Quantité de carburant: ".$this->_qtéCarburant."</BR>";
				}
				elseif (($this->_qtéCarburant < 20) && ($this->_qtéCarburant > 0)) {
					echo "Quantité de carburant: Attention le véhicule n'a plus que ".$this->_qtéCarburant." litres de carburant!</BR>";
				}
				elseif ($this->_qtéCarburant <= 0) {
					echo "Quantité de carburant: Le véhicule n'a plus de carburant!</BR>";
				}
				else {
					echo"Quantité de carburant : Le véhicule n'a plus de carburant!</BR>";
				}
			}
			
			function Arret() { //permet d'indiquer que le véhicule est à l'arret.
				$this->_roule=0;
				echo " Le véhicule est à l'arrêt </BR>";
			}
			
			function Roule($_kmParcouru,$_qtéEssence){ //permet d'incrémenter le nombre de kilomètres et de réduire la quantité de carburant.
				$_carburantUtilise=$_kmParcouru*$_qtéEssence;
				$this->_roule=1; //le véhicule roule
				$this->_nbreKm=$this->_nbreKm+=$_kmParcouru; //on ajoute le nbre de km roulé au km de base de la voiture.
				$this->_nbreKm++; //on incrémente le nbre de km.
				$this->_qtéCarburant=$this->_qtéCarburant-=$_carburantUtilise; //permet de savoir la quantité de carburant restant.
			}
		}
		//Implémentation de l'exercice 2
		$voiture = new Véhicules("Toyota","gris metallique",20000,60,0);
		$voiture->Roule(20,1);
		$voiture->Arret();
		$voiture->Afficher();		
		
		//Exercice 3
		class Voitures extends Véhicules{
			
			//Attributs
			var $_typeCarburant;
			var $_nbPorte;
			
			//Constructeur
			function Commande(){ //surcharge de méthodes
				//récupérer le nombre de paramétre en arguments
				$nombre=func_num_args();
				//récupérer l'ensemble des arguments
				$arguments=func_get_args();
				
				switch ($num) {
					
					case 0: //Constructeur par défaut
					$this->_marque="";
					$this->_couleur="";
					$this->_nbreKm="";
					$this->_qtéCarburant="";
					$this->_typeCarburant="";
					$this->_nbPorte="";
					break;
					
					case 5: //Constructeur paramétré
					$this->_marque= $arguments[0];
					$this->_couleur= $arguments[1];
					$this->_nbreKm= $arguments[2];
					$this->_qtéCarburant= $arguments[3];
					$this->Roule= $arguments[4];
					break;
					
					case 7: //Constructeur paramétré
					$this->_marque=$arguments[0];
					$this->_couleur=$arguments[1];
					$this->_nbreKm=$arguments[2];
					$this->_qtéCarburant=$arguments[3];
					$this->Roule=$arguments[4];
					$this->_typeCarburant=$arguments[5];
					$this->_nbPorte=$arguments[6];
					break;
					
					default:echo "Erreur";
							break;
				}
			}
			
			// Méthode(s)
			function Afficher(){ //permet d'afficher le type du carburant et le nombre de porte.
				parent::Afficher();
				echo "Type de carburant : ".$this->_typeCarburant."</BR>";
				echo "Nombre de portes : ".$this->_nbPorte."</BR>";
			}
		}
		
		class Trains extends Véhicules{

			//Attributs
			var $_type;
			var $_nbWagon;

			//Constructeur
			function Commande(){//surcharge de méthodes
				//récupérer le nombre de paramétre en arguments
				$nombre=func_num_args();
				//récupérer l'ensemble des arguments
				$arguments=func_get_args();
				
				switch($nombre){
					case 0: //Constructeur par défaut
						$this->_marque="";
						$this->_couleur="";
						$this->_nbreKm="";
						$this->_qtéCarburant="";
						$this->_type="";
						$this->_nbWagon="";
						break;
						
					case 5://Constructeur paramétré
						$this->_marque=$arguments[0];
						$this->_couleur=$arguments[1];
						$this->_nbreKm=$arguments[2];
						$this->_qtéCarburant=$arguments[3];
						$this->Roule=$arguments[4];
						break;
					
					case 7: //Constructeur paramétré
						$this->_marque=$arguments[0];
						$this->_couleur=$arguments[1];
						$this->_nbreKm=$arguments[2];
						$this->_qtéCarburant=$arguments[3];
						$this->Roule=$arguments[4];
						$this->_type=$arguments[5];
						$this->_nbWagon=$arguments[6];
						break;

					default:echo " Erreur ";
							break;
				}
			}
			
			//Méthode(s)
			function Afficher(){
				parent::Afficher();
				echo "Type de train : ".$this->_type."</BR>";
				echo "Nombre de wagons : ".$this->_nbWagon."<b/BR>";
			}
		}
		// Implémentation de l'exercice 3
		echo "Voiture </BR>";
		$V1 = new Voitures("Peugeot 406","blanche",100000,70,0,"Essence",2);
		$V1->Roule(85,0.6);
		$V1->Afficher();
		
		echo "Train</BR>";
		$T1 = new Trains("TGV Lyria","Gris et Violet",50000,1500,0,"Essence",25);
		$T1->Roule(3000,0.4);
		$T1->Afficher();
		
		
		//Exercice 4
		/* Création de différentes instances de classes et sauvegarder dans un tableau de véhicules.
		Afin de manipuler les constructeurs de chaque classe à la création des objets. */
		
		// Nouveaux véhicules
		$V2 = new Voitures("Porsche Carrera","vert pomme",200000,120,0,"Diesel",2);
		$V2->Roule(115,1.8);

		$T2 = new Trains("TER Corail","Gris Orange",900000,70000,0,"Diesel",10);
		$T2->Roule(3000,0.4);
		
		// déclaration du tableau de véhicule
		$tableau= array(1=>$V2,2=>$T2);
		
		for ($i=1; $i < 2; $i++) { 
			echo"Voitures : ";
			echo $tableau[1]->Afficher();
			echo"</BR>";
			echo"Train : ";
			echo $tableau[2]->Afficher();
			echo"</BR>";
		}
		
		?>		
	</BODY>
</HTML>