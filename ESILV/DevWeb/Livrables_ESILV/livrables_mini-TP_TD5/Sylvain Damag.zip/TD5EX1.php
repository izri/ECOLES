﻿<?php

class Commande {
        
        var $nomclient;
	var $prix = array(8,14,13,5,2.5);
        var $liste_repas = array(0,0,0,0,0);
	

//Constructeurs
	function __construction(){
$arguments=func_get_args();		
$num=func_num_args();
		
		switch($num)
		{
			case 0: //constructeurs par défaut
					$this->nomclient="toto";
					break;
			case 1: 
					$this->nomclient=$arguments[0];
					break;
			default: echo "erreur </br"; break;

		}
	}

//Méthodes
	
	function ajouterPlatjour($var) {
		$this->liste_repas[1]+=$var;
	}
        function ajouterPizza($var) {
		$this->liste_repas[0]+=$var;
	}
	
	function ajouterDessert($var) {
		$this->liste_repas[3]+=$var;
	}
        
	function ajouterBoisson($var) {
		$this->liste_repas[4]+=$var;
	}
        function ajouterRepasVégétarien($var) {
		$this->liste_repas[2]+=$var;
	}
	function calculPrixTotal(){
		$PrixT=0; //Cumul le prix total
		for($i=0; $i<5; $i++){
			$PrixT+=$this->liste_repas[$i]*$this->prix[$i];
		}
		return $PrixT;
	}
	function affichage(){
                echo " Commande : </br>";
		echo " Client : ". $this->nomclient . "</br>";
		echo "Pizza(s) ". $this->liste_repas[0]. "</br>";
		echo "RepasVégétarien(s) ". $this->liste_repas[2]. "</br>";
		echo "PlatJour(s) ". $this->liste_repas[1]. "</br>";
		echo "Dessert(s) ". $this->liste_repas[3]. "</br>";
		echo "Boisson(s) ". $this->liste_repas[4]. "</br>";
		echo "Prix total de votre commande ". $this->calculPrixTotal(). "</br>";
	}
} //Fin de la classe
//Créer un objet
$client =new Commande("Paul");
$client->ajouterPizza(8);
$client->ajouterBoisson(2);
$client->ajouterDessert(1);
$client->ajouterBoisson(4);
$client->ajouterRepasVégétarien(1);

$client1->affichage();

?>