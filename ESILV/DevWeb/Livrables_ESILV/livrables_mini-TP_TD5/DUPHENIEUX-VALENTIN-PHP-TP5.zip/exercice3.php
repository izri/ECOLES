<?php

class Vehicule{

var $couleur;
var $marque;
var $kilometre;
var $qteCarbu;
var $etat= false;

function Vehicule(){ // surcharge de méthode
	$nb=func_num_args();
	$arguments=func_get_args();	
	switch($nb)
	{
		case 0 :
		$this->marque="t";
		$this->couleur="b";
		$this->kilometre=0;
		$this->qteCarbu=0;
		break;
		
		case 4 : 
		$this->marque=$arguments[0];
		$this->couleur=$arguments[1];
		$this->kilometre=$arguments[2];
		$this->qteCarbu=$arguments[3];
		break;
		default: echo "erreur "; break;
	}
}

function getMarque(){
	return $this->marque;
}
function getCouleur(){
	return $this->couleur;
}
function getKilometre(){
	return $this->kilometre;
}
function getQteCarbu(){
	return $this->qteCarbu;
}

function setMarque($marq){
	$this->marque=$marq;
}
function setCouleur($couleur){
	$this->couleur =$couleur;
}
function setKilometre($kilom){
	$this->kilometre=$kilom;
}
function setQteCarbu($qtecarb){
	$this->qteCarbu=$qtecarb;
}

function affichage(){
	echo "Le véhicule de marque ".$this->marque." de couleur " .$this->couleur." ayant un kilométrage de : " .$this->kilometre."km, contient " .$this->qteCarbu."L.</br>";
}

function arret(){
	if($this->etat=true)
	$this->etat=false;
	echo "le vehicule est à l'arret </br>";
}
function roule(){
	if($this->etat == false){
		$this->etat = true;
		$this->kilometre++;
		$this->qteCarbu--;
	}
}
}

class Voiture extends Vehicule{

var $typeCarb;
var $nbPorte;

function Voiture(){ // surcharge de méthode
	$nb=func_num_args();
	$arguments=func_get_args();	
	switch($nb)
	{
		case 0 :
		$this->typeCarb="typeinconnu";
		$this->nbPorte=0;
		break;
		
		case 2 : 
		$this->typeCarb=$arguments[0];
		$this->nbPorte=$arguments[1];
		break;
		default: echo "erreur "; break;
	}
}

function getTypecarb(){
	return $this->typeCarb;
}
function getNbPorte(){
	return $this->nbPorte;
}
function setTypecarb($typeCarb){
	$this->typeCarb=$typeCarb;
}
function setNbPorte($nbPorte){
	$this->nbPorte=$nbPorte;
}
function affichage(){
	echo "<br> La voiture est de type ".$this->typeCarb." et possède " .$this->nbPorte." portes.";
}
}

class Train extends Vehicule{

var $type;
var $nbWagon;

function Train(){ // surcharge de méthode
	$nb=func_num_args();
	$arguments=func_get_args();	
	switch($nb)
	{
		case 0 :
		$this->type="typeinconnu";
		$this->nbWagon=0;
		break;
		
		case 2 : 
		$this->type=$arguments[0];
		$this->nbWagon=$arguments[1];
		break;
		default: echo "erreur "; break;
	}
}

function getType(){
	return $this->type;
}
function getNbWagon(){
	return $this->nbWagon;
}
function setType($type){
	$this->type=$type;
}
function setNbWagon($nbWagon){
	$this->nbWagon=$nbWagon;
}

function affichage(){
	echo "<br> Le train de type ".$this->type." possède " .$this->nbWagon." wagons.";
}

}


$Vehicule1= new Vehicule("Citroen","Noir",50000,35);
$Vehicule1->affichage();

$Ferrari= new Voiture("Diesel",3);
$Ferrari->affichage();
$Nissan= new Voiture("Essence",5);
$Nissan->affichage();

$ParisLyon= new Train("TGV",12);
$ParisLyon->affichage();
$AmsterdamMarseilles=new Train("Convoi",56);
$AmsterdamMarseilles->affichage();

$Tab = array($Vehicule1,$Ferrari,$Nissan,$ParisLyon,$AmsterdamMarseilles);

?>