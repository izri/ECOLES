<?php
//EXERCICE2
class Vehicule
{
	var $marque;
	var $couleur;
	var $kilometre;
    var $qteCarburant;
    var $roule=0; //si==0 alors ne roule pas.
    var $etat;
    //var $TypeCarburant;
    //var $nbPorte;

	function __construct()
	{
		$num=func_num_args();
		$args=func_get_args();
		switch ($num) 
		{
			case 0:
				$this->marque="";
				$this->couleur="";
				$this->kilometre= 0;
				$this->qteCarburant= 0;
				$this->roule=0;
				break;
				
			case 1:
				$this->marque=$args[0];
				$this->couleur=$args[1];
				$this->kilometres=$args[2];
				$this->qteCarburant=$args[3];
				$this->roule=$args[4];
				
				break;
			
			default:
				echo "Error";
				break;
		}
	}

	function afficher()
	{
		echo "<hr><br>";
		echo "Marque: ".$this->marque."<br>";
		echo "Couleur: ".$this->couleur."<br>";
		echo "Kilométrage du Véhicule: ".$this->kilometres." Km <br>";
		echo "Quantité de carburant: ".$this->qteCarburant." Litres <br>";
		echo "État du véhicule: ".$this->etat."<br>";
	}

	function arret()
	{
		if( $this->roule==0)
		{
			echo "Ce véhicule est à l'arrêt.";
		}
		else
		{
			echo "Ce véhicule roule.";
		}
	}

	function roule($KiloParcourru,$LitreKilo )
	{
		$qteCarburant=$KiloParcourru*$LitreKilo;
		$roule==1; //La voiture est à l'etat actif
		$this->kilometre+=$this->KiloParcourru;
		$kilometre++;
		$qteCarburant--;
	}
}

class Voiture extends Vehicule
{
	var $TypeCarbu;
	var $nbPorte;

	function __construct()
	{
			$num=func_num_args();
			$args=func_get_args();
			switch ($num) 
			{
				case 0: //c'est le constructeur par default
				$this->marque="";
				$this->couleur="";
				$this->kilometre= 0;
				$this->qteCarburant= 0;
				$this->roule=0;
				$this->TypeCarbu="";
				$this->nbPorte=0;
				break;
				
				case 2:
				$this->marque=$args[0];
				$this->couleur=$args[1];
				$this->kilometres=$args[2];
				$this->qteCarburant=$args[3];
				$this->roule=$args[4];
				$this->TypeCarbu=$args[5];
				
				break;
				default:
					echo "Error";
					break;
			}
	}

	function afficher()
	{
		echo "<br>";
		parent::afficher();
		echo "Type de carburant: ".$this->TypeCarbu."<br>";
	    echo "Nombre de portes: ".$this->nbPorte."<br>";
    }
}

class Train extends Vehicule
{
	var $Type;
	var $nbWagons;

	function __construct()
	{
		$num=func_num_args();
		$args=func_get_args();
		
		switch ($num) 
		{
			case 0:
			    $this->marque="";
				$this->couleur="";
				$this->kilometre= 0;
				$this->qteCarburant= 0;
				$this->roule=0;
				$this->Type="";
				$this->nbWagons=0;
				break;
				
			case 3:
				$this->marque=$args[0];
				$this->couleur=$args[1];
				$this->kilometres=$args[2];
				$this->qteCarburant=$args[3];
				$this->roule=$args[4];
				$this->Type=$args[5];
				$this->nbWagons=$args[6];
				break;
				
			default:
			    echo "Error"; //si mauvais nombre d'arguments.
			    break;
		}
	}

	function afficher()
	{
		parent::afficher();
		echo "<hr><hr>";
		echo "Ce train est de type: ".$this->Type."<br>";
		echo "Ce train comporte ".$this->nbWagons." wagons". "<br><hr>";
	}
}


/*Exercice 4*/

echo "<h3> Voiture </h3>";
$myVoit=new Voiture("BMW", "Noir", 14000, 35, 0, "Hybride",5);
$myVoit->roule(30, 0.8);
$myVoit->afficher();

echo "<h3> Train </h3>";
$myTrain=new Train("Rer B","bleu",28000, 65, 0, "electrique", 9);
$myTrain->roule(2700, 0.5);
$myTrain->afficher();


for ($i=1; $i < 2; $i++) { 
echo"<h3>Voiture</h3>";
	echo $tableau[1]->afficher();
	echo"<br>";
	echo"<h3>Train</h3>";
	echo $tableau[2]->afficher();
	echo"<br>";
	}
?>









