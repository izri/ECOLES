<?php

//Exercice 2


class Vehicule
{
	//attributs
	var $marque;
	var $couleur;
	var $kilometres;
	var $qteCarburant;

	function Vehicule()
	{
		$num = func_num_args();
		$arguments = func_get_args();
		switch($num)
		{
			case 0: //constructeur par defaut
			        $this->marque="";
			        $this->couleur="";
			        $this->kilometres="";
			        $this->qteCarburant="";
			        break;

			case 4:
			        $this->marque=$arguments[0];
			        $this->couleur=$arguments[1];
			        $this->kilometres=$arguments[2];
			        $this->qteCarburant=$arguments[3];
			        break;

			default: echo "erreur";
			break;

		}

	}

	function affichage()
	{
		echo " Le vehicule de marque " . $this->marque .
		" et de couleur " . $this->couleur . " ayant roulé " .
		$this->kilometres . " kilometres contient " . $this->qteCarburant. " litres de carburant. </br>";

	}

	function arret()
	{
		echo "le vehicule est à l'arret </br>";
		$this->mouv=false;
	}

	function roule()
	{
		$this->kilometres++;
		$this->qteCarburant--;
		$this->mouv=true;
		echo "le vehicule est en marche </br>";
	}

}


//Exercice 3 

class Voiture extends Vehicule
{
	//attributs
	var $carburant;
	var $nbportes;

	function Voiture()
	{
		parent::Vehicule();
		$num = func_num_args();
		$arguments = func_get_args();
		switch($num)
		{
			case 0: 
			$this->marque="";
			$this->couleur="";
			$this->kilometres="";
			$this->qteCarburant="";
            $this->carburant = "";
		    $this ->nbportes = "";
			break;


			case 7 : 
			$this->marque=$arguments[0];
			$this->couleur=$arguments[1];
			$this->kilometres=$arguments[2];
			$this->qteCarburant=$arguments[3];
	        $this->roule=$arguments[4];
            $this->carburant = $arguments[5];
		    $this ->nbportes = $arguments[6];
			break;

			default : 
			echo" error ";
			break;
	    }

	}

	function affichage()
	{
		parent::affichage();
		echo"La voiture fonctionne avec le carburant suivant: " .$this->carburant
		. ". Elle possede " .$this->nbportes ." portes. </br>";


}
}

class Train extends Vehicule
{
	var $type;
	var $nbwagons;

  function Train()
 {
	parent::Vehicule();
		$num = func_num_args();
		$arguments = func_get_args();
		switch($num)
		{
           case 0: 
			$this->marque="";
			$this->couleur="";
			$this->kilometres="";
			$this->qteCarburant="";
            $this->type = "";
		    $this ->nbwagons = "";
			break;


			case 7 : 
			$this->marque=$arguments[0];
			$this->couleur=$arguments[1];
			$this->kilometres=$arguments[2];
			$this->qteCarburant=$arguments[3];
	        $this->roule=$arguments[4];
            $this->type = $arguments[5];
		    $this ->nbwagons = $arguments[6];
			break;

			default : 
			echo"error";
			break;
	    }

	}

	function affichage()
	{
		parent::affichage();
		echo"Il s'agit d'un " .$this->type
		. "et il possede " .$this->nbwagons ." wagons.</br>";
	}
}



//Exercice 4


$voit1= new Voiture("Peugeot","bleue",10000,60,0,"Diesel",5);
$voit1->affichage();

$Train1 = new Train("TGV","blanc",100000,800,0," TGV",20);
$Train1->affichage();





$voit2 = new Voiture("Renault","rouge",30000,65,0,"Essence",5);
$Train2 = new Train("TER","Gris",250000,500,0,"TER",15);







for ($i=1; $i < 2; $i++) 
{ 

	$tab= array(1=>$voit1,2=>$Train1,3=>$voit2,4=>$Train2);
    echo"<h3> Tableau Voitures </h3>";
	echo $tab[1]->affichage();
	echo $tab[3]->affichage();
	echo"<br>";
	echo"<h3> Tableau Trains </h3>";
	echo $tab[2]->affichage();
	echo $tab[4]->affichage();
	echo"<br>";
}



?>