En executant le logiciel, la console s'ouvre et nous affiche :
	- la grammaire
	- les premiers
	- les suivants
	- les �tats
	- la table d'analyse

Le logiciel nous demande ensuite d'entrer un mot du langage.
Malheureusement cette fonction n'est pas compl�te.
Elle marche seulement pour des mots du langage qui ne m�neront pas � un conflit du langage. En effet, la gestion du conflit n'a pas �t� trait� enti�rement.
De plus la fonction d�tecte les impasse mais n'est pas capable d'en conclure que le mot n'appartient pas � la grammaire lorsque c'est le cas.