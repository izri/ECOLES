#ifndef FIRST_H
#define FIRST_H


class First
{
    public:
        First();
        virtual ~First();
    protected:
    private:
};

#endif // FIRST_H
