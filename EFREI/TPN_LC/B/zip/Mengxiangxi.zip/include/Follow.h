#ifndef FOLLOW_H
#define FOLLOW_H


class Follow
{
    public:
        Follow();
        virtual ~Follow();
    protected:
    private:
};

#endif // FOLLOW_H
