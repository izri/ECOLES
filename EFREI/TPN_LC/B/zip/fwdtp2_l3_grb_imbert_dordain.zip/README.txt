Projet Langage et compilation Imbert-Dordain

/!\ Ce projet ne compile qu'en for�ant le compilateur � utiliser C++ dans sa version 11 /!\
Ce choix permet d'utilsier les nouvelles forme de boucles courtes de c++ qui all�gent la syntaxe d�ja lourde de notre programme.
En cas d'impossibilit� de compilation, une trace d'execution est fournie dans le fichier Imbert_Dordain_trace.txt.

Malgres de nobmreuses heures pass�es sur ce projet, nous n'avons pas �t� en mesure de le r�aliser entierement.
Nous pouvons :
		*Lire les fichiers .txt de grammaire
		*Trouver les Terminaux et Non Terminaux de la grammaire
		*Calculer les premiers ainsi que les suivants
		*Cr�er l'automate SLR
		*Cr�er la table d'analyse

Nous n'avons pas �t� en mesure de r�aliser la pile d'�xuction et donc la v�rifcation d'un mot donn�.
L'int�gralit� du code rendu est de notre cr�ation les algorithmes impl�ment�s sont ceux pr�sent dans notre poly de cours ou ont �t� fournis par l'enseignant pendant la s�ance d�di�e � ce projet.