Bonsoir,

Vous trouverez notre programme qui ne r�ussit que la lecture de fichier et le stockage de la grammaire. Nous avons essay� de faire les firsts et follows mais ceci s'est r�v�l� plus complexe que pr�vu et nous n'avons pas pu avancer comme nous le voulions.
Vous trouverez �galement dans un .docx associ� tous les algos que nous avions trouv� pour faire ce projet.

Cordialement,

Loris et Guillaume