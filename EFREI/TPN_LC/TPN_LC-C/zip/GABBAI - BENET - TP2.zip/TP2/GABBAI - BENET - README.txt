Notre projet compile, s'ex�cute et effectue les actions suivantes :
Lecture depuis le fichier texte
Chargement en m�moire dans une structure de donn�es
Calcul des Items
Calcul des First et des Follow
La construction de la table de l'analyseur SLR n'est pas faite :
nous n'arrivons pas � r�cup�rer correctement les successeurs d'un Item,
pourtant calcul�s dans une fonction