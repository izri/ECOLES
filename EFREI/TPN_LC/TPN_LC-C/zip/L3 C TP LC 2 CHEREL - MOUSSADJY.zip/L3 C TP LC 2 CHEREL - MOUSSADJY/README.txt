Etat d'avancement honete:
- automate: ok
- first: ok
- follow: ok
- table d'analyse: ok
- table d'execution: ok
