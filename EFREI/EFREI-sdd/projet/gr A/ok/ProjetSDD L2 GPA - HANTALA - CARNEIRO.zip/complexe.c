#include "Structures.h"


void AfficherComplexe(complexe sortie) // assemblage des r�els et des imaginaires
{
    if(sortie.re != 0 && sortie.im != 0)
    {
        printf("(%f",sortie.re);
    }
    if (sortie.im > 0)
    {
        printf("+%fi)",sortie.im);
    }
    if (sortie.im < 0)
    {
        printf("%fi)",sortie.im);
    }
    if (sortie.re != 0 && sortie.im == 0)
    {
        printf("%f",sortie.re);
    }
    if(sortie.re == 0 && sortie.im == 0)
    {
        printf("0");
    }
}

complexe saisie() //fonction de saisie des complexes
{
    complexe entrer;
    printf("Partie reelle: ");
    scanf("%f",&entrer.re);
    printf("Partie imaginaire: ");
    scanf("%f",&entrer.im);
    return entrer;
}

complexe addition(complexe a,complexe b) // fonction addition des complexes
{
    complexe resultat;
    resultat.re = a.re + b.re;
    resultat.im = a.im + b.im;
    return resultat;
}

complexe multiplication(complexe a, complexe b) // multiplication des complexes entre eux
{
    complexe resultat;
    resultat.re = (a.re*b.re) - (a.im*b.im);
    resultat.im = (a.re*b.im) + (a.im*b.re);
    return resultat;
}

float sqtr(float a) // fonction calcul de la racine carr� grace � la m�thode de newton
{
    float u,precision,un;
    u=a;
    do
    {
        un=u/2.0+a/(2.0*u);
        precision=u-un;
        if (precision<0)
        {
            precision=precision*(-1) ;
        }
        u=un;
    }
    while (precision>10E-8);
    return un;
}

float module(complexe a) //calcule le module d'un complexe
{
    float resultat;
    resultat = sqtr((a.re*a.re)+(a.im*a.im));
    return resultat;
}

complexe division(complexe a, complexe b) //division d'un complexe
{
    complexe res;
    res.re = ((a.re*b.re) + (a.im*b.im))/((a.im*a.im)+(b.im*b.im));
    res.im = ((b.re*a.im)-(a.re*b.re))/((a.im*a.im)+(b.im*b.im));
    return res;
}

int EstNull (complexe a) //v�rifie si un complexe est nul ou pas
{
    if ((a.re==0)&&(a.im==0)) return 1;
    else return 0;
}

complexe puissance_c(complexe z, long k)
{
    if(k == 0)
    {
        complexe puissancenul = {1,0};
        return puissancenul;
    }
    else
    {
        return multiplication(z,puissance_c(z, k-1));
    }
}
complexe oppose(complexe z) // fais l'oppos� du complexe
{
    complexe zr;
    zr.re = -z.re;
    zr.im = -z.im;
    return zr;
}

complexe reel(complexe c) // ne garde que la partie reelle du complexe
{
    complexe resultat;
    resultat.re = c.re;
    resultat.im = 0;
    return resultat;
}


complexe imagine(complexe c) //ne garde que la partie imaginaire du complexe
{
    complexe resultat;
    resultat.re = 0;
    resultat.im = c.im;
    return resultat;
}
