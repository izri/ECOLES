#include "Structures.h"
//Programme Polynomes par Eric Hantala et Alexandre Carneiro, Promotion 2018, Efrei

int main()
{
    int choix = 0, choix2 =0,choix3 = 0;
    //initialisation des listes (pour les polynomes)
    list p1 = NULL, p2 = NULL, p3 = NULL,sp1 = NULL,sp2 = NULL;

    do
    {
        affichage();
        choix = 0, choix2 =0,choix3 = 0;
        p1 = NULL, p2 = NULL, p3 = NULL,sp1 = NULL,sp2 = NULL;
        p1 = initialisation_liste(); // premier polynome
        p2 = initialisation_liste(); // deuxi�me polynome
        p3 = initialisation_liste(); //liste chain�e qui servira au r�sultat

        //D�but du programme
        //Cr�ation des deux polynomes
        printf("\tCreation du premier polynome:\n");
        Creation_Polynome_utilisateur_dev(p1);
        printf("\n\tCreation du deuxieme polynome:\n");
        Creation_Polynome_utilisateur_dev(p2);

        //demande � l'utilisateur ce qu'il veut faire
        affichage();
        printf("Polynome 1: ");
        Afficher_Polynome_dev(p1);
        printf("Polynome 2: ");
        Afficher_Polynome_dev(p2);
        do
        {
            printf("\n Que souhaitez-vous faire ?\n----------------------------\n1.Addition\n2.Soustraction\n3.Multiplication\n4.Partie reelle\n5.Partie imaginaire\n6.Evaluation en un point\n7.Derivation\n8.Integration\n----------------------------\n");
            scanf("%d",&choix);
        }
        while(choix < 1 || choix > 8);
        switch(choix)
        {
        case 1: //addition
            affichage();
            printf("\n\t\t\tADDITION\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            add_dev(p1,p2,p3);
            Arrangement_Monomes(p3);
            printf("Resultat :\n");
            Afficher_Polynome_dev(p3);
            system("PAUSE");
            break;
        case 2: //soustraction
            affichage();
            printf("\n\t\t\tSOUSTRACTION\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            sou_dev(p1,p2,p3);
            Arrangement_Monomes(p3);
            printf("Resultat :\n");
            Afficher_Polynome_dev(p3);
            system("PAUSE");
            break;
        case 3: //Multiplication
            affichage();
            printf("\n\t\t\tMULTIPLICATION\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            multip_dev(p1,p2,p3);
            Arrangement_Monomes(p3);
            printf("Resultat :\n");
            Afficher_Polynome_dev(p3);
            system("PAUSE");
            break;
        case 4: //Partie reelle
            affichage();
            printf("\n\t\t\tPARTIE REELLE\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            printf("Partie reel sur 1.Polynome 1 ou 2.Polynome 2 ?");
            scanf("%d",&choix2);
            if(choix2 == 1)
            {
                partiereel(p1,p3);
                Arrangement_Monomes(p3);
                printf("Resultat :\n");
                Afficher_Polynome_dev(p3);
            }
            else
            {
                partiereel(p2,p3);
                Arrangement_Monomes(p3);
                printf("Resultat :\n");
                Afficher_Polynome_dev(p3);
            }
            system("PAUSE");
            break;
        case 5:
            affichage(); //partie imaginaire
            printf("\n\t\t\tPARTIE IMAGINAIRE\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            printf("Partie imaginaire sur 1.Polynome 1 ou 2.Polynome 2 ?");
            scanf("%d",&choix2);
            if(choix2 == 1)
            {
                partieimaginaire(p1,p3);
                Arrangement_Monomes(p3);
                printf("Resultat :\n");
                Afficher_Polynome_dev(p3);
            }
            else
            {
                partieimaginaire(p2,p3);
                Arrangement_Monomes(p3);
                printf("Resultat :\n");
                Afficher_Polynome_dev(p3);
            }
            system("PAUSE");
            break;
        case 6:
            affichage(); //evaluation en un point
            printf("\n\t\t\tEVALUATION\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            printf("Evaluation sur 1.Polynome 1 ou 2.Polynome 2 ?");
            scanf("%d",&choix2);
            if(choix2 == 1)
            {
                evaluation(p1);
            }
            else
            {
                evaluation(p2);
            }
            system("PAUSE");
            break;
        case 7:
            affichage(); //d�rivation
            printf("\n\t\t\tDERIVATION\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            printf("Derivation sur 1.Polynome 1 ou 2.Polynome 2 ?");
            scanf("%d",&choix2);
            if(choix2 == 1)
            {
                sp1 = initialisation_liste();
                copieliste(p1,sp1);
                derivation(p1);
                Afficher_Polynome_dev(p1);
            }
            else
            {
                sp2 = initialisation_liste();
                copieliste(p2,sp2);
                derivation(p2);
                Afficher_Polynome_dev(p2);
            }
            system("PAUSE");
            break;
        case 8: //int�gration
            affichage();
            printf("\n\t\t\tINTEGRATION\n");
            printf("Polynome 1: ");
            Afficher_Polynome_dev(p1);
            printf("Polynome 2: ");
            Afficher_Polynome_dev(p2);
            printf("Integration sur 1.Polynome 1 ou 2.Polynome 2 ?");
            scanf("%d",&choix2);
            if(choix2 == 1)
            {
                sp1 = initialisation_liste();
                copieliste(p1,sp1);
                integration(p1);
                Afficher_Polynome_dev(p1);
            }
            else
            {
                sp2 = initialisation_liste();
                copieliste(p2,sp2);
                integration(p2);
                Afficher_Polynome_dev(p2);
            }
            system("PAUSE");
            break;
        default :
            printf("Erreur");
        }
        //destruction des liste chain�e
        detruireliste(p1);
        detruireliste(p2);
        detruireliste(p3);
        if(sp1 != NULL)
        {
            detruireliste(sp1);
        }
        if(sp2 != NULL)
        {
            detruireliste(sp2);
        }
        //on demande a l'utilisateur si il veut recommancer depuis le d�but.
        affichage();
        printf("Voulez-vous recommencer ? (1-OUI   2-Non)\n");
        scanf("%d",&choix3);
    }
    while(choix3 != 2);

    return 0;
    //Fin du programme
}
