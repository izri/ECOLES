#include "Structures.h"
void affichage() //pour un affichage jolie
{
    system("cls");
    printf("\t\t\t---------------------\n\t\t\t Programme Polynomes\n\t\t\t---------------------\n\t\t\t\t Par\n\t\t\t    %cEric Hantala%c\n\t\t\t %cAlexandre Carneiro%c\n\t\t\t---------------------\n\n",176,176,176,176);
}

//fonctions pour les listes
list initialisation_liste() //cr�er le premier maillon vide.
{
    list l = malloc(sizeof(monome));
    l->content = NULL;
    l->succ = NULL;
    return l;
}

void insertionfin(developpe* content,list p) //insertion d'un element en fin de liste
{
    //cr�ation maillon
    list l = p;
    monome* data = malloc(sizeof(monome));
    data->content = content;
    data->succ = NULL;

    //le premier �l�ment est nul
    if(l->content == NULL)
    {
        l->content = content;
        return;
    }
    //sinon on parcours pour arriver au dernier element
    while(l->succ != NULL)
    {
        l = l->succ;
    }
    l->succ = data; // on insere en fin de liste
    return;
}
void copieliste(list l,list result) // copie une liste dans une autre
{
    list p = l;
    developpe* temp;
    while(p!=NULL) //copie de la liste dans r�sultat
    {
        temp = malloc(sizeof(developpe));
        temp->coeff.re = p->content->coeff.re;
        temp->coeff.im = p->content->coeff.im;
        temp->degre = p->content->degre;
        insertionfin(temp,result);
        p = p->succ;
    }
}
void afficher(list p) //fonction de test qui sert juste a voir si la liste est correctement utilis� (inutile hors des tests)
{
    list l = p;
    if(l == NULL)
    {
        printf("Liste vide");
        return;
    }
    while(l != NULL)
    {
        printf("%f %f %d \n",l->content->coeff.re,l->content->coeff.im,l->content->degre);
        l = l->succ;
    }
}
void detruireliste(list l) //lib�re la m�moire des listes
{
    list p = l;
    list tempo = p->succ;
    if(p->succ == NULL)
    {
        free(p);
    }
    else
    {
        while(p->succ != NULL)
        {
            tempo = p->succ;
            free(p);
            p = tempo;
        }
    }
}


//fonctions de calcul des polynomes
void derivation (list dev) //fonction calcul de la d�riv�e
{
    list l = dev;
    complexe C;
    C.im = 0;
    while(l!=NULL)
    {
        if(l->content->degre != 0)
        {
            C.re = l->content->degre;
            l->content->coeff = multiplication(l->content->coeff,C);
            l->content->degre--;
        }
        l = l->succ;
    }
}

void integration (list dev) // fonction calcul de la primitive
{
    list l = dev;
    complexe C;
    C.im = 0;
    while(l!=NULL)
    {
        if(l->content->degre != 0)
        {
            C.re = l->content->degre;
            l->content->coeff = division(l->content->coeff,C);
            l->content->degre++;
        }
        l = l->succ;
    }
}

void add_dev (list polya, list polyb,list resultat) //fonction addition de deux polynomes
{
    list p1 = polya;
    list p2 = polyb;
    developpe* temp = NULL;
    while(p1 != NULL || p2 != NULL)
    {
        if(p1 == NULL)
        {
            temp = malloc(sizeof(developpe));
            temp->coeff = p2->content->coeff;
            temp->degre = p2->content->degre;
            insertionfin(temp,resultat);
            p2 = p2->succ;
        }
        else if(p2 == NULL)
        {
            temp = malloc(sizeof(developpe));
            temp->coeff = p1->content->coeff;
            temp->degre = p1->content->degre;
            insertionfin(temp,resultat);
            p1 = p1->succ;
        }
        else
        {
            if(p1->content->degre == p2->content->degre)
            {
                temp = malloc(sizeof(developpe));
                temp->coeff = addition(p1->content->coeff,p2->content->coeff);
                temp->degre = p1->content->degre;

                if(!EstNull(temp->coeff))
                {
                    insertionfin(temp,resultat);
                }
                p1 = p1->succ;
                p2 = p2->succ;
            }
            else if(p1->content->degre > p2->content->degre)
            {
                temp = malloc(sizeof(developpe));
                temp->coeff = p1->content->coeff;
                temp->degre = p1->content->degre;
                insertionfin(temp,resultat);
                p1 = p1->succ;
            }
            else
            {
                temp = malloc(sizeof(developpe));
                temp->coeff = p2->content->coeff;
                temp->degre = p2->content->degre;
                insertionfin(temp,resultat);
                p2 = p2->succ;
            }
        }
    }
}

void sou_dev (list polya, list polyb,list resultat) //fonction soustraction de deux polynomes
{
    list p1 = polya;
    list p2 = polyb;
    developpe* temp = NULL;
    while(p1 != NULL || p2 != NULL)
    {
        if(p1 == NULL)
        {
            temp = malloc(sizeof(developpe));
            temp->coeff = oppose(p2->content->coeff);
            temp->degre = p2->content->degre;
            insertionfin(temp,resultat);
            p2 = p2->succ;
        }
        else if(p2 == NULL)
        {
            temp = malloc(sizeof(developpe));
            temp->coeff = oppose(p1->content->coeff);
            temp->degre = p1->content->degre;
            insertionfin(temp,resultat);
            p1 = p1->succ;
        }
        else
        {
            if(p1->content->degre == p2->content->degre)
            {
                temp = malloc(sizeof(developpe));
                temp->coeff = addition(p1->content->coeff,oppose(p2->content->coeff));
                temp->degre = p1->content->degre;

                insertionfin(temp,resultat);
                p1 = p1->succ;
                p2 = p2->succ;
            }
            else if(p1->content->degre > p2->content->degre)
            {
                temp = malloc(sizeof(developpe));
                temp->coeff = oppose(p1->content->coeff);
                temp->degre = p1->content->degre;
                insertionfin(temp,resultat);
                p1 = p1->succ;
            }
            else
            {
                temp = malloc(sizeof(developpe));
                temp->coeff = oppose(p2->content->coeff);
                temp->degre = p2->content->degre;
                insertionfin(temp,resultat);
                p2 = p2->succ;
            }
        }
    }
}

/*complexe multi_dev(list polya, list polyb, list polyres) /// multiplication deux polynomes avec la m�thode de Karatsuba (ne fonctionne pas, pas r�ussi � trouver l'erreur)
{
    complexe z2;
    complexe z0;
    developpe* temp = malloc(sizeof(developpe));

    ///----------Z2------------------
    temp->degre = (polya->content->degre)*2;
    temp->coeff = multiplication((polya->content->coeff),(polyb->content->coeff));
    insertionfin(temp,polyres);
    z2 = temp->coeff;
    ///-------------------------------------

    temp->degre = (polya->content->degre);
    if(polya->succ != NULL)
    {
        if (polya->succ->content==NULL)
        {
           // temp->coeff = addition(oppose(z2),multiplication(polya->content->coeff,polyb->content->coeff));
            //insertionfin(temp,polyres);
            z0.im=0;
            z0.re=0;
          return z0;
        }
        else
        {
            z0=multi_dev(polya->succ,polyb->succ,polyres);
            temp -> coeff = addition(multiplication(addition(polya->content->coeff,polya->succ->content->coeff),addition(polyb->content->coeff,polyb->succ->content->coeff)),addition(oppose(z2),oppose(z0)));
            insertionfin(temp,polyres);
            return addition(z0,(temp->coeff));
        }
    }
}*/

void multip_dev(list p1,list p2,list resultat) //multiplication de deux polyn�mes
{
    list l = p1, m = p2;
    developpe* temp = NULL;
    while(l!=NULL)
    {
        m = p2;
        while(m!=NULL)
        {
            temp = malloc(sizeof(developpe));
            temp->coeff = multiplication(l->content->coeff,m->content->coeff);
            temp->degre = (l->content->degre)+(m->content->degre);
            insertionfin(temp,resultat);
            m = m->succ;
        }
        l = l->succ;
    }
}

void Arrangement_Monomes(list head)    // fonction qui rangent la liste d'un polynome de la forme d�velopp�e dans l'ordre d�croissant
{
    list l = head;
    int degre1,degre2;
    developpe temp;
    monome *tempo = NULL;

    //compter le nom d'�l�ments
    int cpt = 0,cpt2 = 0;

    while(l != NULL)
    {
        cpt++;
        l = l->succ;
    }

    do
    {
        l = head;
        while(l != NULL)
        {
            cpt2++;
            if(l->succ != NULL)
            {

                degre1 = l->content->degre;
                degre2 = l->succ->content->degre;

                if (degre1 < degre2)
                {
                    temp.coeff = l->content->coeff;
                    temp.degre = l->content->degre;

                    l->content->coeff =  l->succ->content->coeff;
                    l->content->degre =  l->succ->content->degre;

                    l->succ->content->coeff = temp.coeff;
                    l->succ->content->degre = temp.degre;
                }

                if(degre1 == degre2)
                {
                    list p = l;
                    tempo = malloc(sizeof(monome));
                    p->content->coeff = addition(p->content->coeff,p->succ->content->coeff);
                    tempo = p->succ;
                    p->succ = p->succ->succ;
                    free(tempo);
                }
            }
            l = l->succ;
        }
    }
    while(cpt2 < (cpt*cpt)); //pour �tre sur d'avoir trier toute la liste
    return;
}

void Creation_Polynome_utilisateur_dev(list p) // fonction qui ajoute le polynomes cr�er par l'utilisateur dans une liste
{
    developpe* temp = NULL;
    list l = p;
    int continu = 1;
    do
    {
        l = p;
        temp = malloc(sizeof(developpe));
        printf("Entrer le degre: ");
        scanf("%d",&temp->degre);
        printf("Entrer la partie reelle: ");
        scanf("%f",&temp->coeff.re);
        printf("Entrer la partie imaginaire: ");
        scanf("%f",&temp->coeff.im);
        insertionfin(temp,l);

        printf("Continuer? (1.Oui - 2.Non)");
        scanf("%d",&continu); // a s�cure

    }
    while(continu == 1);

    Arrangement_Monomes(p);
    printf("Polynome rentre: ");
    Afficher_Polynome_dev(p);

    return ;
}

void Afficher_Polynome_dev(list p)   // affiche le polyn�me p
{
    list l = p;    /// pointeur qui parcourt la liste
    if(p == NULL)   /// liste vide
    {
        printf("0 \n") ;
        return;
    }
    else if (l->succ == NULL)    /// le polynome est compos� d'un mon�me unique ...
    {
        if((l->content->coeff.re == 0) && (l->content->coeff.im == 0))  /// nul
        {
            printf("0 \n");
            return;
        }
        else if(l->content->degre == 1)  /// de degre 1
        {
            AfficherComplexe(l->content->coeff);
            printf("X \n");
            return;
        }
        else if(l->content->degre > 1)   /// de degre sup�rieur � 1
        {
            AfficherComplexe(l->content->coeff);
            printf("X^%d \n",l->content->degre);
            return;
        }
        else
        {
            AfficherComplexe(l->content->coeff);
            printf("\n");
            return;
        }

    }
    else    /// le polyn�me est compos� de plusieurs mon�mes
    {
        while(l->succ != NULL)   /// l par printf la liste et affiche les mon�mes
        {
            if((l->content->coeff.re == -1) && (l->content->coeff.im == 0))    /// affiche -X (coeff = -1)
            {
                printf("-");
            }
            else if(l->content->coeff.re != 1)    /// affiche yiX ou xX
            {
                AfficherComplexe(l->content->coeff);
            }
            else if(l->content->degre == 0)      /// le degre du polynome est nul
            {
                AfficherComplexe(l->content->coeff);
            }
            else if(l->content->coeff.im != 0)
            {
                AfficherComplexe(l->content->coeff);  /// affiche (x+iy) X^n avec n>0
            }
            /* sinon  affiche X(coeff = 1) */
            if(l->content->degre == 1)
            {
                printf("X ");
                if(((l->content->coeff.re < 0) && (l->content->coeff.im == 0)) || ((l->content->coeff.re == 0) && (l->content->coeff.im < 0)))    /// adapte l'affichage des op�ratuers en fonction du mononme succ
                {
                    printf(" ");
                }
                else
                {
                    printf(" + ");
                }
            }
            else if(l->content->degre > 1)
            {
                printf("X^%d",l->content->degre);
                if(((l->content->coeff.re < 0) && (l->content->coeff.im == 0)) || ((l->content->coeff.re == 0) && (l->content->coeff.im < 0)))    /// adapte l'affichage des op�ratuers en fonction du mononme succ
                {
                    printf(" ");
                }
                else
                {
                    printf(" + ");
                }
            }
            l = l->succ;
        }
        // on affiche le dernier mon�me
        if((l->content->coeff.re == -1) && (l->content->coeff.im == 0))    /// affiche -X (coeff = -1)
        {
            printf("-");
        }
        else if(l->content->coeff.re != 1)    /// affiche yiX ou xX
        {
            AfficherComplexe(l->content->coeff);
        }
        else if(l->content->degre == 0)      /// le degre du polynome est nul
        {
            AfficherComplexe(l->content->coeff);
        }
        else if(l->content->coeff.im != 0)
        {
            AfficherComplexe(l->content->coeff);  /// affiche (x+iy) X^n avec n>0
        }
        // sinon  affiche X(coeff = 1)
        if(l->content->degre == 1)
        {
            printf("X ");
            if(((l->content->coeff.re < 0) && (l->content->coeff.im == 0)) || ((l->content->coeff.re == 0) && (l->content->coeff.im < 0)))    /// adapte l'affichage des op�ratuers en fonction du mononme succ
            {
                printf(" ");
            }
        }
        else if(l->content->degre > 1)
        {
            printf("X^%d",l->content->degre);
        }
        //fin dernier monome
        printf("\n");
    }

    return;
}

void evaluation(list p)   //Fonction �valuation en un point du polynome
{
    complexe z;
    complexe resultat = {0,0};

    // Saisie de z (evaluation en z)
    printf("Evaluation en :\n Saisir Re(z) :\n");
    scanf("%f",&z.re);
    printf("Saisir Im(z) :\n");
    scanf("%f",&z.im);
    printf("Evaluation en ");
    AfficherComplexe(z);
    printf("\n");
    printf("f(x) = ");
    Afficher_Polynome_dev(p);
    printf("\n");

    // Evaluation
    if(p == NULL)
    {
        resultat.re = 0;
        resultat.im = 0;
        printf("f(");
        AfficherComplexe(z);
        printf(") = ");
        AfficherComplexe(resultat);
        return;
    }
    else if(p->succ == NULL)
    {
        resultat = multiplication(p->content->coeff, puissance_c(z,p->content->degre));
        printf("f(");
        AfficherComplexe(z);
        printf(") = ");
        AfficherComplexe(resultat);
        return;
    }
    else
    {
        printf("f(");
        AfficherComplexe(z);
        printf(") = ");
        AfficherComplexe(resultat_horner(p,z));
        return;
    }
}

complexe resultat_horner(list l, complexe z)    // fonction qui calcule le resultat de l'�valuation
{
    if(l->succ == NULL)
    {
        return multiplication(l->content->coeff,puissance_c(z,l->content->degre));
    }
    else
    {
        return addition(addition(multiplication(l->content->coeff,puissance_c(z,l->content->degre)),l->succ->content->coeff),resultat_horner(l->succ, z));
    }
}

void partiereel(list p,list resultat) //fonction qui ne garde que la partie reel d'un polynome
{
    list l = p;
    developpe* temp = malloc(sizeof(developpe));
    while(l != NULL)
    {
        temp->coeff = reel(l->content->coeff);
        temp->degre = l->content->degre;
        insertionfin(temp,resultat);
        l = l->succ;
    }
}
void partieimaginaire(list p,list resultat) //fonction qui ne garde que la partie imaginaire d'un polynome
{
    list l = p;
    developpe* temp = malloc(sizeof(developpe));
    while(l != NULL)
    {
        temp->coeff = imagine(l->content->coeff);
        temp->degre = l->content->degre;
        insertionfin(temp,resultat);
        l = l->succ;
    }
}
