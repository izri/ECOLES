Fonctions disponibles: 
	-addition
	-soustraction
	-multiplication
	-d�rivation
	-int�gration
	-�valuation en un point
	-partie reelle ou imaginaire uniquement

Le programme est aussi �quip� avec la creation d'une liste simplement chain�e, l'ajout en queud et la destruction d'une liste.

Le programme est en console, et a une interface jolie et sobre mais efficace. Le programme utilise des fonctions comme system("cls") ou system("PAUSE").