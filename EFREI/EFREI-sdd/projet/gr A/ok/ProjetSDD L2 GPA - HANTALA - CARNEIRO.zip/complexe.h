#ifndef COMPLEXE_H_INCLUDED
#define COMPLEXE_H_INCLUDED

typedef struct s_complexe
{
    float re, im;
} complexe;

void AfficherComplexe(complexe sortie);
complexe multiplication(complexe a, complexe b);
complexe addition(complexe a,complexe b);
complexe saisie();
float sqtr(float a);
float module(complexe a);
complexe division(complexe a, complexe b);
int EstNull (complexe a);
complexe puissance_c(complexe z, long k);
complexe oppose(complexe z);
complexe reel(complexe c);
complexe imagine(complexe c);

#endif // COMPLEXE_H_INCLUDED
