#ifndef STRUCTURES_H_INCLUDED
#define STRUCTURES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "complexe.h"

//D�finition des structures utile pour le programme
typedef struct Factorise_s
{
    complexe racine;
} factorise;

typedef struct Developpe_s
{
    complexe coeff;
    int degre;

} developpe;

//pour les listes
typedef struct monome
{
    developpe* content; // normalement �a aurait du �tre void* mais pas r�ussi � l'utilis� correctement
    struct monome *succ;
} monome;

typedef monome* list;

//fonctions pour les listes
void affichage();
list initialisation_liste();
void insertionfin(developpe* content,list p);
void afficher(list p);
void copieliste(list l,list result);
void detruireliste(list l);

//fonctions pour les polynomes
void integration (list dev);
void derivation (list dev);
void add_dev (list polya, list polyb,list resultat);
void sou_dev (list polya, list polyb,list resultat);
//complexe multi_dev (list polya, list polyb, list polyres); //karatsuba non fonctionnel
void Arrangement_Monomes(list head);
void Creation_Polynome_utilisateur_dev(list p);
void Afficher_Polynome_dev(list p);
void evaluation(list p);
complexe resultat_horner(list l, complexe z);
void partiereel(list p,list resultat);
void partieimaginaire(list p,list resultat);
void multip_dev(list p1,list p2,list resultat);

#endif // STRUCTURES_H_INCLUDED
