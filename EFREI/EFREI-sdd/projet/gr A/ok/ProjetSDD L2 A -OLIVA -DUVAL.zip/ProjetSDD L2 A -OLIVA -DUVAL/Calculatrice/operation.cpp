
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "operation.h"
using namespace std;

void initialisation(polynome **polynom)
{
    polynome *p;
    *polynom = (polynome*)malloc(sizeof(polynome));
    p = * polynom;
    p->next = NULL;

}
void saisir(polynome **polynom)
{
    int d, cpt;
    polynome *p;
    p = * polynom;
    cout << "combien de monome le polynome aura?" << endl;
    cin >> d;
    for(cpt = 0; cpt < d; cpt ++)                               // pour avoir le nombre de monome voulu
    {
        p->next = (polynome*)malloc(sizeof(polynome));
        cout << "saisir le degre du monome" << endl;
        cin >>  p->atm.degre;
        cout << "saisir le coeficiant du monome" << endl;
        cin >>  p->atm.reel;
        cout << "saisir i du monome" << endl;
        cin >>  p->atm.i;
        p =  p->next;
    }
    p->next = NULL;
}

void tri(polynome **polynom)
{
    int test;
    polynome *p, *p2, *p3;
    p = * polynom;
    p2 = p->next;
    test = 0;
    do
    {
        p =  p->next;                                           // on compte les monomes
        test = test +1;

    }while(p->next != NULL);
    if(test > 2)                                                // Si il y a plus de 2 monomes on les tri
    {
        do
        {
            p = * polynom;
            p2 = p->next;
            p3 = p2->next;
            test = 0;
            if (p->atm.degre < p2->atm.degre)                   // On tri les 2 premier monomes
            {
                p->next = p2->next;
                p2->next = p;
                *polynom = p2;
                test = 1;

            }
            p = * polynom;
            p2 = p->next;
            p3 = p2->next;

            do                                              // On tri les autres premier monomes
            {
                if (p2->atm.degre < p3->atm.degre)
                {
                    p2->next = p3->next;
                    p3->next =  p->next;
                    p->next = p3;
                    test=1;
                        p2 = p->next;
                        p3 = p2->next;
                }
                if (p2->atm.degre == p3->atm.degre)
                {
                    p3->atm.reel = p2->atm.reel + p3->atm.reel;
                    p3->atm.i = p2->atm.i + p3->atm.i;
                    p->next = p2->next;
                    test =2;
                    p2 = p3;
                    p3 = p3->next;
                }
                if(test != 2)
                {
                    p = p->next;
                    p2 = p2->next;
                    p3 = p3->next;
                }


            }while(p3->next != NULL);
        }while(test != 0);
    }
}

void addition(polynome **poly , polynome **poly2, polynome **poly3 )
{
    int test = 0;
     polynome *p, *p2,*p3;
     p = *poly;
     p2 = *poly2;
     p3 = *poly3;
     do
     {
          p2 = *poly2;
         test = 0;
         do
        {
          if(p->atm.degre == p2->atm.degre)                     // si les 2 monomes on les meme degre on les additions
          {


              p3->next = (polynome*)malloc(sizeof(polynome));
              p3->atm.reel = p->atm.reel + p2->atm.reel;
              p3->atm.i = p->atm.i + p2->atm.i;
              p3->atm.degre = p->atm.degre;
              p3 = p3->next;
              test = 1;

          }
            p2 = p2->next;
        }while(p2->next != NULL);
            if(test ==0)                                       // sinon on ajout le monome a la fin
          {

              p3->next = (polynome*)malloc(sizeof(polynome));
              p3->atm.reel = p->atm.reel;
              p3->atm.degre = p->atm.degre;
              p3->atm.i = p->atm.i;
              p3 = p3->next;
          }
         p = p->next;

     }while(p->next != NULL);
     p = *poly;
     p2 = *poly2;
    do
     {
         test = 0;
         p = *poly;
         do
        {
          if(p->atm.degre == p2->atm.degre)          // On verifie que les monomes du 2eme polynome ont un monome a degre dans le premier polynome
          {
              test = 1;
          }
            p = p->next;
        }while(p->next != NULL);
        if(test ==0)                                 // Si le monomes a pas de monome a degre identique on l'ajoute a la fin
          {
              p3->next = (polynome*)malloc(sizeof(polynome));
              p3->atm.reel = p2->atm.reel;
              p3->atm.i = p2->atm.i;
              p3->atm.degre = p2->atm.degre;
              p3 = p3->next;
          }
         p2 = p2->next;

     }while(p2->next != NULL);
     p3->next = NULL;
}

void soustraction(polynome **poly , polynome **poly2, polynome **poly3 )
{
    int test = 0;
     polynome *p, *p2,*p3;
     p = *poly;
     p2 = *poly2;
     p3 = *poly3;
     do
     {
          p2 = *poly2;
         test = 0;
         do
        {
          if(p->atm.degre == p2->atm.degre)             // si les 2 monomes on les meme degre on les soustrai
          {
              p3->next = (polynome*)malloc(sizeof(polynome));
              p3->atm.reel = p->atm.reel - p2->atm.reel;
              p3->atm.i = p->atm.i - p2->atm.i;
              p3->atm.degre = p->atm.degre;
              p3 = p3->next;
              test = 1;

          }
            p2 = p2->next;
        }while(p2->next != NULL);
            if(test ==0)                                // sinon on ajout le monome a la fin
          {

              p3->next = (polynome*)malloc(sizeof(polynome));
              p3->atm.reel = p->atm.reel;
              p3->atm.degre = p->atm.degre;
              p3->atm.i = p->atm.i;
              p3 = p3->next;
          }
         p = p->next;

     }while(p->next != NULL);
     p = *poly;
     p2 = *poly2;
    do
     {
         test = 0;
         p = *poly;
         do
        {
          if(p->atm.degre == p2->atm.degre)        // On verifie que les monomes du 2eme polynome ont un monome a degre dans le premier polynome
          {
              test = 1;
          }
            p = p->next;
        }while(p->next != NULL);
        if(test ==0)
          {
              p3->next = (polynome*)malloc(sizeof(polynome));         // Si le monomes a pas de monome a degre identique on l'ajoute son inverse a la fin
              p3->atm.reel = 0 - p2->atm.reel;
              p3->atm.i = 0- p2->atm.i;
              p3->atm.degre = p2->atm.degre;
              p3 = p3->next;
          }
         p2 = p2->next;

     }while(p2->next != NULL);
     p3->next = NULL;
}

void multiplication(polynome **poly , polynome **poly2, polynome **poly3 )
{
    polynome *p, *p2,*p3;
    p = *poly;
    p2 = *poly2;
    p3 = *poly3;
    do
    {
         p2 = *poly2;
         do                                                     // on multiplie tout les monome entre eux
        {

              p3->next = (polynome*)malloc(sizeof(polynome));
              p3->atm.reel = p->atm.reel * p2->atm.reel;
              p3->atm.i = p->atm.i * p2->atm.i;
              p3->atm.degre = p->atm.degre + p2->atm.degre;
              p3 = p3->next;


            p2 = p2->next;
        }while(p2->next != NULL);

         p = p->next;

    }while(p->next != NULL);
    p3->next = NULL;
}
void derivation(polynome **poly , polynome **poly2 )
{
    polynome *p, *p2;
    p = *poly;
    p2 = *poly2;
    do
    {
        if (p->atm.degre >0)                               // si le degre est superieur a 0 on derive le polynome
        {
              p2->next = (polynome*)malloc(sizeof(polynome));
              p2->atm.reel = p->atm.reel * p->atm.degre;
              p2->atm.i = p->atm.i * p->atm.degre;
              p2->atm.degre = p->atm.degre -1;
              p2 = p2->next;
        }



         p = p->next;

    }while(p->next != NULL);
    p2->next = NULL;
}
void primitive(polynome **poly , polynome **poly2 )
{
    polynome *p, *p2;
    p = *poly;
    p2 = *poly2;
    do
    {
        if (p->atm.degre >0)                // si le degre est superieur a 0 on integre le polynome
        {
              p2->next = (polynome*)malloc(sizeof(polynome));
              p2->atm.degre = p->atm.degre +1;
              p2->atm.reel = p->atm.reel / p2->atm.degre;
              p2->atm.i = p->atm.i / p->atm.degre;
              p2 = p2->next;
        }

         p = p->next;

    }while(p->next != NULL);
    p2->next = NULL;
}
void comparaison(polynome **poly , polynome **poly2 )
{
    int test = 0;
    polynome *p, *p2;
    p = *poly;
    p2 = *poly2;

    do
    {
        if (p->atm.reel != p2->atm.reel || p->atm.i != p2->atm.i || p->atm.degre != p2->atm.degre)
        {
            test = 1;
        }

        p = p->next;
        p2 = p2->next;

    }while(p->next != NULL && p->next !=NULL );
    if(test == 0)
        cout << "les polynomes sont identiques" << endl;
    else
        cout << "les polynomes sont diferrents" << endl;

}

void conjuguer(polynome **poly , polynome **poly2 )
{
    polynome *p, *p2;
    p = *poly;
    p2 = *poly2;
    do
    {
        if (p->atm.degre >=0)                                                          // On inverce les i
        {
              p2->next = (polynome*)malloc(sizeof(polynome));
              p2->atm.reel = p->atm.reel;
              p2->atm.i = p->atm.i * -1;
              p2->atm.degre = p->atm.degre;
              p2 = p2->next;
        }



         p = p->next;

    }while(p->next != NULL);
    p2->next = NULL;
}

void affich(polynome **polynom)
{
    polynome *p;
    p = * polynom;
    do
    {
        if(p->atm.reel != 0)
        {
            cout << p->atm.reel << "x^" << p->atm.degre;
            if (p->next != NULL)
            cout <<  " + ";
        }

        if(p->atm.i != 0)
        {
            cout << p->atm.i << "ix^" << p->atm.degre;
              if(p->next->next != NULL)
              cout <<  " + ";
        }
        p =  p->next;


    }while(p->next != NULL);
    cout << endl;
}
void reelimagin(polynome **polynom)
{
    int test =0;
    polynome *p;
    p = * polynom;
    do
    {
        if(p->atm.reel != 0)                                      // affiche la partie reel des monomes
        {
            cout << p->atm.reel << "x^" << p->atm.degre;
            if (p->next->next != NULL)
            cout <<  " + ";
        }

    p =  p->next;
    }while(p->next != NULL);

    p = * polynom;

    do
    {
      if((p->atm.i != 0)&& (test==0))
      {
                  cout<<"+ i(" ;
                  test = 1;
      }

      if(p->atm.i != 0)                                         // affiche la partie imaginaire des monomes
        {
            cout << p->atm.i << "x^" << p->atm.degre;
              if(p->next->next != NULL)
              cout <<  " + ";
        }
        p =  p->next;


    }while(p->next != NULL);
    if(test!=0)
         cout<<")" ;
    cout << endl;
    }



