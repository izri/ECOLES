
typedef struct monome monome;
typedef struct polynome polynome;

typedef struct monome
{
    double reel, i;
    int degre;

}monome;

typedef struct polynome
{
    monome atm;
    polynome *next;

}polynome;

void initialisation(polynome **polynom);
void saisir(polynome **polynom);
void tri(polynome **polynom);
void addition(polynome **poly , polynome **poly2, polynome **poly3 );
void soustraction(polynome **poly , polynome **poly2, polynome **poly3 );
void multiplication(polynome **poly , polynome **poly2, polynome **poly3 );
void derivation(polynome **poly , polynome **poly2 );
void primitive(polynome **poly , polynome **poly2 );
void comparaison(polynome **poly , polynome **poly2 );
void conjuguer(polynome **poly , polynome **poly2 );
void affich(polynome **polynom);
void reelimagin(polynome **polynom);
