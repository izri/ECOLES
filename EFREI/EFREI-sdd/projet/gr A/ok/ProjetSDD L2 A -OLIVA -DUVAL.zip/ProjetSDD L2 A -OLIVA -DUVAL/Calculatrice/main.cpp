#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "operation.h"
using namespace std;

int main()
{
    int choix=0;
    polynome *p, *p2, *p3;
    initialisation(&p);
    saisir(&p);
    tri(&p);
    affich(&p);
    initialisation(&p2);
    saisir(&p2);
    tri(&p2);
    affich(&p2);
    do
    {
        cout << "Que voulez vous faire ?" << endl <<  "1.Changer a" << endl <<  "2.Changer b" << endl <<  "3.Additionner" << endl <<  "4.Soustraire"
         << endl <<  "5.Multipliyer"<< endl <<  "6.deriver" << endl <<  "7.integrer" << endl <<  "8.comparer" << endl <<  "9.conjugueur" <<endl<< "10.Separer les reels des imaginaires" << "11.Quitter" << endl;

        cin >> choix;
        if (choix == 1)
        {
            initialisation(&p);
            saisir(&p);
            tri(&p);
            affich(&p);
        }

        if (choix == 2)
        {
            initialisation(&p2);
            saisir(&p2);
            tri(&p2);
            affich(&p2);
        }
        if (choix == 3)
        {
            initialisation(&p3);
            addition(&p,&p2,&p3);
            affich(&p3);
        }
        if (choix == 4)
        {
            initialisation(&p3);
            soustraction(&p,&p2,&p3);
            affich(&p3);
        }
        if (choix == 5)
        {
            initialisation(&p3);
            multiplication(&p,&p2,&p3);
            affich(&p3);
        }
        if (choix == 6)
        {
            initialisation(&p3);
            derivation(&p,&p3);
            affich(&p3);
        }
         if (choix == 7)
        {
            initialisation(&p3);
            primitive(&p,&p3);
            affich(&p3);
        }
         if (choix == 8)
        {
            comparaison(&p,&p2);
        }
        if (choix == 9)
        {
            initialisation(&p3);
            conjuguer(&p,&p3);
            affich(&p3);
        }
         if (choix == 10)
        {

            reelimagin(&p);
        }
    }while (choix != 11);
    return 0;
}
