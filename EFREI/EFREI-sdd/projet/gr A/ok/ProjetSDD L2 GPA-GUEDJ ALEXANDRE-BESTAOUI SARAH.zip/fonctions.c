//
//  fonctions.c
//  Listes
//
//  Created by Alex GUEDJ on 27/11/2014.
//  Copyright (c) 2014 Alex GUEDJ. All rights reserved.
//

#define MAX 8
#define MIN 0

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "fonctions.h"


noeud *ajout(noeud *tete, complexe nombre, int puissance)//Ajout d'un maillon a la liste polynome
{
    noeud *p_new = (noeud *)malloc(1*sizeof(noeud));
    
    if (p_new != NULL)
    {
        p_new->nombre.re = nombre.re;
        p_new->nombre.im = nombre.im;
        p_new->puissance = puissance;
        p_new->suivant = NULL;
        
        if (tete == NULL) tete = p_new;
        else
        {
            noeud *p = tete;
            while (p->suivant != NULL)
            {
                p = p->suivant;
            }
            p->suivant = p_new;
        }
        
    }
    return tete;
}

void afficherListe(noeud *tete)//Affiche le polynome
{
    noeud *p = tete;
    while (p != NULL)
    {
        if (p->suivant == NULL)
        {
            if (p->puissance == 0) printf("(%f + %fi)", p->nombre.re, p->nombre.im);
            else printf("(%f + %fi)x^%d", p->nombre.re, p->nombre.im, p->puissance);
        }
        else
        {
            if (p->nombre.im < 0.0001 && p->nombre.re < 0.0001) printf(" ");
            else printf("(%f + %fi)x^%d + ", p->nombre.re, p->nombre.im, p->puissance);
        }
        p = p->suivant;
    }
}

noeud *trierListe(noeud *tete, int maxcase)//Trie le polynome pour que les plus grandes puissances soient au début de la liste
{
    noeud *p = NULL;
    noeud *temp = malloc(sizeof(noeud));
    int i;
    
    for (i = 0; i < maxcase - 1; i++)
    {
        p = tete;
        while (p->suivant != NULL)
        {
            if (p->suivant->puissance == p->puissance && p->suivant->suivant != NULL)
            {
                temp = p->suivant;
                p->nombre.re = p->nombre.re + p->suivant->nombre.re;
                p->nombre.im = p->nombre.im + p->suivant->nombre.im;
                p->suivant = p->suivant->suivant;
            }
            if (p->suivant->puissance > p->puissance)
            {
                temp->puissance = p->puissance;
                temp->nombre.re = p->nombre.re;
                temp->nombre.im = p->nombre.im;
                
                p->puissance = p->suivant->puissance;
                p->nombre.re = p->suivant->nombre.re;
                p->nombre.im = p->suivant->nombre.im;
                
                p->suivant->puissance = temp->puissance;
                p->suivant->nombre.re = temp->nombre.re;
                p->suivant->nombre.im = temp->nombre.im;
                
            }
            p = p->suivant;
            
        }
    }
    free(temp);
    return tete;
}

noeud *deriveeListe(noeud *tete)//Calcule la derivée du polynome
{
    noeud *p = tete;
    noeud *tmp = NULL;
    while (p != NULL)
    {
        if (p->puissance == 0)
        {
            tmp->suivant = p->suivant;
            p->suivant = NULL;
            free(tmp);
        }
        p->nombre.re = p->nombre.re*p->puissance;
        p->nombre.im = p->nombre.im*p->puissance;
        p->puissance--;
        
        tmp = p;
        p = p->suivant;
    }
    
    
    return tete;
}

noeud *primListe(noeud *tete)//Calcule une primitive du polynome
{
    noeud *p = tete;
    while (p != NULL)
    {
        if (p->puissance == 0) p->puissance++;
        else
        {
            p->puissance++;
            p->nombre.re = p->nombre.re/p->puissance;
            p->nombre.im = p->nombre.im/p->puissance;
        }
        p = p->suivant;
    }
    return tete;
}

noeud *addListe(noeud *liste1, noeud *liste2)//Addition de deux polynomes
{
    noeud *p = liste2;
    
    while (p != NULL)
    {
        liste1 = ajout(liste1, p->nombre, p->puissance);
        p = p->suivant;
    }
    return liste1;
}

noeud *sousListe(noeud *liste1, noeud *liste2)//Soustraction de deux polynomes
{
    noeud *p = liste2;
    
    while (p != NULL)
    {
        p->nombre.re = p->nombre.re*(-1);//On passe les valeurs au negatif et on additionne, cela revient a une soustraction
        p->nombre.im = p->nombre.im*(-1);
        
        liste1 = ajout(liste1, p->nombre, p->puissance);
        p = p->suivant;
    }
    return liste1;
}

noeud *multiplierListe(noeud *liste1, noeud *liste2, noeud *liste3)
{
    complexe produit;
    int puissance;
    noeud *p1 = liste1;
    noeud *p2 = liste2;
    
    while (p2 != NULL)
    {
        while (p1 != NULL)
        {
            produit.re = p1->nombre.re*p2->nombre.re - p1->nombre.im*p2->nombre.im;
            produit.im = p1->nombre.im*p2->nombre.re + p1->nombre.re*p2->nombre.im;
            puissance = p1->puissance + p2->puissance;
            liste3 = ajout(liste3, produit, puissance);
            
            p1 = p1->suivant;
        }
        p2 = p2->suivant;
        p1 = liste1;
    }
    return liste3;
        
}

void viderListe(noeud *liste)
{
    if (liste != NULL)
    {
        noeud *p = liste;
        while (p != NULL)
        {
            noeud *tmp = p;
            
            p = p->suivant;
            free(tmp);
        }
        liste = NULL;
    }
}
complexe conjugueComplexes(complexe nombre)
{
    nombre.im = nombre.im*(-1);
    return nombre;
}

complexe multiplicationComplexes(complexe nombre1, complexe nombre2)//Utile pour division des polynomes
{
    complexe resultat;
    resultat.re = nombre1.re*nombre2.re - nombre1.im*nombre2.im;
    resultat.im = nombre1.im*nombre2.re + nombre1.re*nombre2.im;
    
    return resultat;
}

complexe divisionComplexes(complexe nombre1, complexe nombre2)
{
    complexe resultat;
    
    resultat.re = multiplicationComplexes(nombre1, conjugueComplexes(nombre2)).re/(nombre2.re*nombre2.re + nombre2.im*nombre2.im);
    resultat.im = multiplicationComplexes(nombre1, conjugueComplexes(nombre2)).im/(nombre2.re*nombre2.re + nombre2.im*nombre2.im);
    
    return resultat;
    
}

void divisionListe(noeud *liste1, noeud *liste2, noeud *liste3)
{
    noeud *dividende = liste1;
    noeud *diviseur = liste2;
    noeud *quotien = NULL;
    noeud *reste = NULL;
    noeud *p = NULL;
    int puissance, cpt = 0;
    
    
    
    while (diviseur->puissance <= dividende->puissance && dividende->suivant != NULL && cpt < 10)
    {
        puissance = dividende->puissance - diviseur->puissance;
        quotien = ajout(quotien, divisionComplexes(dividende->nombre, diviseur->nombre), puissance);
        
        if (cpt == 1)
        {

            p = quotien;
            p = p->suivant;
            reste = sousListe(dividende, multiplierListe(p, diviseur, liste3));
        }
        else if (cpt == 0)
        {
            reste = sousListe(dividende, multiplierListe(quotien, diviseur, liste3));
        }
        
        trierListe(quotien, 5);
        trierListe(reste, 5);
        dividende = dividende->suivant;
        
        cpt++;
        
        free(liste3);
    }
    
    printf("\nQuotient : ");
    afficherListe(quotien);
    
    
    printf("\n\nReste : ");
    afficherListe(reste);
    
    
    
}
