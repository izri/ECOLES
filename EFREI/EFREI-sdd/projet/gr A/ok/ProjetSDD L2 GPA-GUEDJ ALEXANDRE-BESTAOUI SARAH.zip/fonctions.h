//
//  fonctions.h
//  Listes
//
//  Created by Alex GUEDJ on 27/11/2014.
//  Copyright (c) 2014 Alex GUEDJ. All rights reserved.
//

#ifndef __Listes__fonctions__
#define __Listes__fonctions__

#include <stdio.h>

typedef struct complexe
{
    float re;
    float im;
} complexe;

typedef struct noeud
{
    complexe nombre;
    int puissance;
    struct noeud *suivant;
} noeud;

noeud *ajout(noeud *tete, complexe nombre, int puissance);
void afficherListe(noeud *tete);
noeud *trierListe(noeud *tete, int maxcase);
noeud *deriveeListe(noeud *tete);
noeud *primListe(noeud *tete);
noeud *addListe(noeud *liste1, noeud *liste2);
noeud *sousListe(noeud *liste1, noeud *liste2);
noeud *multiplierListe(noeud *liste1, noeud *liste2, noeud *liste3);
void viderListe(noeud *liste);
void divisionListe(noeud *liste1, noeud *liste2, noeud *liste3);


#endif /* defined(__Listes__fonctions__) */
