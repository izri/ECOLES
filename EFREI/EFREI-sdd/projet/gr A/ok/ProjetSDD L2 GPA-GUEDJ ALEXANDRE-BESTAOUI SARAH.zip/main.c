//
//  main.c
//  Listes
//
//  Created by Alex GUEDJ on 17/11/2014.
//  Copyright (c) 2014 Alex GUEDJ. All rights reserved.
//

#define MAX 8
#define MIN 0

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "fonctions.h"


int main()
{
    int choix = 0, cpt2 = 0, puissance = 0, maxcase1 = 0, maxcase2 = 0, continuer = 0;
    complexe nombre;
    noeud *liste1 = NULL;
    noeud *liste2 = NULL;
    noeud *liste3 = NULL;
    
    srand(time(NULL));
    printf(" ========== GESTION DE POLYNOMES ==========\n\n");
    printf("1. Entrer un polynome\n2. Polynome aléatoire\n\nChoix : ");
    scanf("%d", &choix);
    printf("\nCombien de monomes souhaitez vous ? ");
    scanf("%d", &maxcase1);
    
    if (choix == 2)
    {
        for (cpt2 = 0; cpt2 < maxcase1; cpt2++)//On crée le premier polynome aléatoire
        {
            nombre.re = (rand() % (MAX - MIN + 1)) + 1;
            nombre.im = (rand() % (MAX - MIN + 1)) + 1;
            puissance = (rand() % (MAX - MIN + 1)) + MIN;
            
            liste1 = ajout(liste1, nombre, puissance);
        }
    }
    else if (choix == 1)
    {
        for (cpt2 = 0; cpt2 < maxcase1; cpt2++)//On crée le premier polynome aléatoire
        {
            printf("Coefficient reel : ");
            scanf("%f", &nombre.re);
            printf("Coefficient imaginaire : ");
            scanf("%f", &nombre.im);
            printf("Degré du monome : ");
            scanf("%d", &puissance);
            
            liste1 = ajout(liste1, nombre, puissance);
        }

    }
    
    while(choix != 7)
    {
        
        continuer = 0;
        
    printf(" ========== GESTION DE POLYNOMES ==========\n\n");
    trierListe(liste1, maxcase1);
        
    printf("P(x) = ");
    
    afficherListe(liste1);
    printf("\n\n");
    printf("1. Addition de polynomes\n2. Soustraction de polynomes\n3. Multipication de polynomes\n");
    printf("4. Derivee de polynome\n5. Primitive de polynome\n6. Division euclidienne\n7. Quitter\n\nChoix : ");
    scanf("%d", &choix);
        
        if (choix == 1)
        {
            while (continuer != 2)
            {
                printf(" ========== ADDITION DE POLYNOME ==========\n\n");
                printf("Saisie du deuxieme polynome : \n");
                printf("Nombre de monomes : ");
                scanf("%d", &maxcase2);
                for (cpt2 = 0; cpt2 < maxcase2; cpt2++)//On crée le premier polynome aléatoire
                {
                    printf("\nCoefficient reel : ");
                    scanf("%f", &nombre.re);
                    printf("Coefficient imaginaire : ");
                    scanf("%f", &nombre.im);
                    printf("Degré du monome : ");
                    scanf("%d", &puissance);
                    
                    liste2 = ajout(liste2, nombre, puissance);
                }
                printf("\n\n ========== ADDITION DE POLYNOME ==========\n\n");
                printf("P2(X) = ");
                afficherListe(trierListe(liste2, maxcase2));
                printf("\n\nP1(x) + P2(X) = ");
                afficherListe(trierListe(addListe(liste1, liste2), maxcase1 + maxcase2));
                printf("\n\n1. Additionner a nouveau\n2. Retour au menu principal\n\nChoix : ");
                scanf("%d", &continuer);
                
                
            }
        }
        
        if (choix == 2)
        {
            while (continuer != 2)
            {
                printf(" ========== SOUSTRACTION DE POLYNOME ==========\n\n");
                printf("Saisie du deuxieme polynome : \n");
                printf("Nombre de monomes : ");
                scanf("%d", &maxcase2);
                for (cpt2 = 0; cpt2 < maxcase2; cpt2++)//On crée le premier polynome aléatoire
                {
                    printf("\nCoefficient reel : ");
                    scanf("%f", &nombre.re);
                    printf("Coefficient imaginaire : ");
                    scanf("%f", &nombre.im);
                    printf("Degré du monome : ");
                    scanf("%d", &puissance);
                    
                    liste2 = ajout(liste2, nombre, puissance);
                }
                printf("\n\n ========== SOUSTRACTION DE POLYNOME ==========\n\n");
                printf("P2(X) = ");
                afficherListe(trierListe(liste2, maxcase2));
                printf("\n\nP1(x) - P2(X) = ");
                afficherListe(trierListe(sousListe(liste1, liste2), maxcase1 + maxcase2));
                printf("\n\n1. Soustraire a nouveau\n2. Retour au menu principal\n\nChoix : ");
                scanf("%d", &continuer);
                
                
            }
        }

        if (choix == 3)
        {
                printf(" ========== MULTIPLICATION DE POLYNOMES ==========\n\n");
                printf("Saisie du deuxieme polynome : \n");
                printf("Nombre de monomes : ");
                scanf("%d", &maxcase2);
            
                for (cpt2 = 0; cpt2 < maxcase2; cpt2++)//On crée le premier polynome aléatoire
                {
                    printf("\nCoefficient reel : ");
                    scanf("%f", &nombre.re);
                    printf("Coefficient imaginaire : ");
                    scanf("%f", &nombre.im);
                    printf("Degré du monome : ");
                    scanf("%d", &puissance);
                    
                    liste2 = ajout(liste2, nombre, puissance);
                }
            
                printf("\n\n ========== MULTIPLICATION DE POLYNOMES ==========\n\n");
                printf("P2(X) = ");
                afficherListe(trierListe(liste2, maxcase2));
                printf("\n\nP1(x) x P2(X) = ");
                afficherListe(trierListe(multiplierListe(liste1, liste2, liste3), maxcase1*maxcase2));
                printf("\n\n1. Multiplier a nouveau\n2. Retour au menu principal\n\nChoix : ");
                scanf("%d", &continuer);
                free(liste2);
            
        }
            
    
        if (choix == 4)
        {
            while (continuer != 2)
            {
                printf(" ========== DERIVEE DE POLYNOME ==========\n\n");
                printf("P'(x) = ");
                afficherListe(deriveeListe(liste1));
                printf("\n\n1. Deriver a nouveau\n2. Retour au menu principal\n\nChoix : ");
                scanf("%d", &continuer);
            }
        }
        
        if (choix == 5)
        {
            while (continuer != 2)
            {
                printf(" ========== PRIMITIVE DE POLYNOME ==========\n\n");
                printf("P(x) = ");
                afficherListe(primListe(liste1));
                printf("\n\n1. Primitiver a nouveau\n2. Retour au menu principal\n\nChoix : ");
                scanf("%d", &continuer);
            }
        }
        
        if (choix == 6)
        {
            printf(" ========== DIVISION DE POLYNOMES ==========\n\n");
            printf("Saisie du deuxieme polynome : \n");
            printf("Nombre de monomes : ");
            scanf("%d", &maxcase2);
            
            for (cpt2 = 0; cpt2 < maxcase2; cpt2++)//On crée le premier polynome aléatoire
            {
                printf("\nCoefficient reel : ");
                scanf("%f", &nombre.re);
                printf("Coefficient imaginaire : ");
                scanf("%f", &nombre.im);
                printf("Degré du monome : ");
                scanf("%d", &puissance);
                
                liste2 = ajout(liste2, nombre, puissance);
            }
            
            printf(" ========== DIVISION DE POLYNOMES ==========\n\n");
            divisionListe(liste1, liste2, liste3);
            printf("\n\n1. Retour au menu principal.");
            scanf("%d", &continuer);
        }

        if (choix == 7)
        {
            viderListe(liste1);
            viderListe(liste2);
            viderListe(liste3);
        }

        
        
    }

    return 0;
}
