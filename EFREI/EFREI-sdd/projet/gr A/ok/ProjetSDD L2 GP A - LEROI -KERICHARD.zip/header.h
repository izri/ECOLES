#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

///STRUCTURES
typedef struct complexe
{
    double re;
    double im;
} t_complexe;

typedef struct developpe
{
    t_complexe coef;
    int puis;
    struct developpe *suiv;
    struct developpe *prec;
}developpe;
typedef struct developpe* t_developpe;

typedef struct dev
{
    t_developpe tete;
    t_developpe queue;
}dev;

typedef struct factorise
{
    t_complexe coef;
    int puis;
    struct factorise *suiv;
}factorise;
typedef struct factorise* t_factorise;

typedef struct polynome
{
    t_factorise fac;
    dev *dvp;
    struct polynome *suivant;
}polynome;
typedef struct polynome* t_polynome;


void menu();

///POLYNOMES

void construireListe(t_polynome *, int);

t_polynome premierElt(t_polynome *);

t_polynome creatCellPOLY();

void AfficherPoly(t_polynome);

t_polynome AjouterPoly(t_polynome*);

double* saisir(t_developpe, int);

void supprimerDev(t_developpe);

dev* creatCellDEV_etoile();

///FORME DEVELOPPEE

t_developpe creatCellDEV();

void AfficherDEV(t_developpe);

void remplirDEV(dev**, double*);

dev*    duplicationDEV(dev*);


///OPERATIONS
int    Comparaison(dev*, dev*);
void    AffiPolyAvance(dev*, int);
dev*    AddiSousPoly(dev*, dev*, int);
dev*    MultiplicationPoly(dev*, dev*);
dev*    DerivationPoly(dev*);
dev*    IntegrationPoly(dev*);
dev*    DivisionPoly(dev*, dev*);
dev*    CompositionPoly(dev*, dev*);
dev*    SelectionDEV(t_polynome);
t_complexe EvaluationPoly(dev*, int);
dev*    PGCD(dev*, dev*);

int     puissance(int, int);

///FONCTIONNALITES

void saisieManuelle(t_polynome *);

void saisieAutomatique(t_polynome *);

void supprimerPoly(t_polynome *);

#endif // HEADER_H_INCLUDED
