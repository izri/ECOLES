#include <stdio.h>
#include <stdlib.h>
#include "header.h"
#include <math.h>

void construireListe(t_polynome* lst, int nbpoly)        ///CREATION DE TOUTE LES CASES POLYNOMES
{
    t_polynome case_preced,case_suiv;
    int i;
    if(nbpoly != 0)
    {
        case_preced = premierElt(lst);
        for (i=1; i<nbpoly; i++)
        {
            case_suiv = creatCellPOLY();
            case_suiv->dvp = creatCellDEV_etoile();
            case_preced->suivant = case_suiv;
            case_preced = case_suiv;
        }
    }
}


t_polynome premierElt(t_polynome *lst)
{
    *lst = creatCellPOLY();
    (*lst)->dvp = creatCellDEV_etoile();
    return *lst;
}

dev* creatCellDEV_etoile()
{
    dev* case_d;

    case_d = (dev*)malloc(sizeof(dev));
    case_d->tete = NULL;
    case_d->queue = NULL;

    return case_d;
}


t_polynome creatCellPOLY()
{
    t_polynome case_poly;

    case_poly = (t_polynome)malloc(sizeof(polynome));       ///Cr�ation de la lst dev de la structure polynome
    case_poly->suivant = NULL;
    case_poly->dvp = NULL;
    case_poly->fac = NULL;

    return case_poly;
}

void AfficherPoly(t_polynome lst)
{
    t_polynome element = lst;
    int cpt = 1;

    if (element == NULL) printf("\nErreur : pas de polynome !\n");

    while(element != NULL)
    {
        printf("\n%d : ", cpt);
        cpt++;
        AfficherDEV(element->dvp->tete);
        element = element->suivant;
        printf("\n");
    }
    system("pause");
}

t_polynome AjouterPoly(t_polynome *lst)
{
    t_polynome element = *lst;

    if(element == NULL)
    {
        *lst = creatCellPOLY();
        (*lst)->dvp = creatCellDEV_etoile();
    }
    else
    {
        while(element->suivant != NULL)
        {
            element = element->suivant;
        }
        element->suivant = creatCellPOLY();
        element->suivant->dvp = creatCellDEV_etoile();
    }
    return element->suivant;
}


void supprimerPoly(t_polynome *lst)
{
    t_polynome tmp = *lst, tmp2 = *lst;
    t_developpe element = NULL, element2 = NULL;


    if(tmp == NULL)
    {
        system("cls");
        printf("Erreur : liste vide !\n");
        system("pause");
        return;
    }

    while(tmp != NULL)      ///On parcourt la liste Poly
    {
        element = tmp->dvp->tete;

        while(element != NULL)      ///On parcourt la liste DEV (On efface un element a chaque fois)
        {
            element2 = element->suiv;
            free(element);
            element = element2;
        }
        ///Penser a faire aussi un while pour parcourir et supprimer la liste FAC
        free(tmp->dvp);
        free(tmp->fac);
        tmp2 = tmp->suivant;
        free(tmp);
        tmp = tmp2;
    }
    free(lst);
    *lst = NULL;
    printf("\nSuppression effectuee !\n");
    system("pause");
    return;
}


void AffiPolyAvance(dev *liste, int choix)
{
    t_developpe element = liste->tete;

    if (element == NULL) printf("\nListe Vide !\n");
    else
    {
        if (choix == 7) ///CONJUGUEE
        {
            printf("\nConjugue : ");
            while(element != NULL)          // on parcourt la liste a afficher
            {
                if(element->puis != 0) printf("(");
                if(element->coef.re != 0)   printf("%g", element->coef.re);         //on gere les cas d'affichage des coefs nuls ou negatifs
                if((-element->coef.im > 0) && (element->coef.re != 0))   printf("+");
                if(-element->coef.im != 0)   printf("%gi", -element->coef.im);

                if(element->puis == 1)  printf(")x");
                else if(element->puis != 0)   printf(")x^%d", element->puis);

                if(element->suiv != NULL) printf(" + ");
                element = element->suiv;
            }
        }
        else if (choix == 8) ///EXTRACTION
        {
            printf("\nPartie reelle : ");
            while(element != NULL)          // on parcourt la liste a afficher
            {
                if(element->coef.re != 0)           //on gere les cas d'affichage des coefs nuls ou negatifs
                {
                    printf("(%g", element->coef.re);
                    if(element->puis == 1)  printf("x)");
                    else if(element->puis != 0)   printf("x^%d)", element->puis);
                    else    printf(")");
                }
                if(element->suiv != NULL)
                {
                    if(element->suiv->coef.re != 0)    printf(" + ");
                }
                element = element->suiv;
            }
            element = liste->tete;
            printf("\nPartie imaginaire : ");
            while(element != NULL)          // on parcourt la liste a afficher
            {
                if(element->coef.im != 0)            //on gere les cas d'affichage des coefs nuls ou negatifs
                {
                    printf("(%gi", element->coef.im);
                    if(element->puis == 1)  printf("x)");
                    else if(element->puis != 0)   printf("x^%d)", element->puis);
                    else    printf(")");
                }
                if(element->suiv != NULL)
                {
                    if(element->suiv->coef.im != 0)    printf(" + ");
                }
                element = element->suiv;
            }
        }

        printf("\n");
    }
    system("pause");
    free(element);
}


int Comparaison(dev *p2, dev *p1)
{
    t_developpe tmp1 = p1->tete, tmp2 = p2->tete;
    int module1, module2;

    while(tmp1 != NULL && tmp2 != NULL)
    {
        if(tmp1->puis > tmp2->puis)             return 1;
        else if(tmp1->puis < tmp2->puis)        return 2;

        else  {                             //Poly egaux
            module1 = sqrt(tmp1->coef.re * tmp1->coef.re + tmp1->coef.im * tmp1->coef.im);
            module2 = sqrt(tmp2->coef.re * tmp2->coef.re + tmp2->coef.im * tmp2->coef.im);
            if(module1 > module2)       return 1;
            else if(module1 < module2)  return 2;
        }
        tmp1 = tmp1->suiv;
        tmp2 = tmp2->suiv;
    }
    if(tmp1 == NULL && tmp2 == NULL)        return 0;
    else if(tmp1 != NULL && tmp2 == NULL)   return 1;
    else if(tmp1 == NULL && tmp2 != NULL)   return 2;
}




