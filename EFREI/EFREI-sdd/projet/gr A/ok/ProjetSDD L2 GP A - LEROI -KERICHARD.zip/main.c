#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "header.h"


int main()
{
    int nb, quitter = 0, s;
    t_polynome lst_poly = NULL, queue_poly = NULL;
    t_complexe eval;

    printf("\n\n\n\n        Bienvenue dans la calculatrice polynomiale !\n             (Yann KERICHARD - Jerome LEROI)\n\n        ");
    system("pause");
    do{
        system("cls");
        printf("Comment voulez-vous saisir vos polynomes?\n1: Manuellement\n2: Automatiquement\n");
        scanf("%d", &s);
    }while(s != 1 && s != 2);

    if(s == 1)          saisieManuelle(&lst_poly);
    else if(s == 2)     saisieAutomatique(&lst_poly);
    queue_poly = lst_poly;
    while(queue_poly->suivant != NULL)  queue_poly = queue_poly->suivant;

    ///FONCTIONNALITES
    do
    {
        menu();
        scanf("%d", &nb);
        switch(nb)
        {
        case 1:
            system("cls");
            AfficherPoly(lst_poly);
            break;
        case 2 :
            saisieManuelle(&lst_poly);
            queue_poly = queue_poly->suivant;
            break;
        case 3 :
            supprimerPoly(&lst_poly);
            break;
        case 4 :
            do
            {
                system("cls");
                printf("1) Addition de deux polynomes\n2) Soustraction de deux polynomes\n3) Multiplication de deux polynomes\n4) Division d'un polynome\n5) Derivation d'un polynome\n6) Integration d'un polynome\n7) Conjugue d'un polynome\n8) Extraction des parties reelle et imaginaire d'un polynome\n9) Comparaison de deux polynomes\n10) Evaluation en X d'un polynome\n11) PGCD de deux polynomes\n");
                scanf("%d", &nb);
            }while((nb < 1) || (nb > 11));
            system("cls");
            if(nb == 1 || nb == 2)
            {
                if (nb == 1) printf("ADDITION");
                else printf("SOUSTRACTION");
                AfficherPoly(lst_poly);
                queue_poly->suivant = creatCellPOLY();
                queue_poly->suivant->dvp = AddiSousPoly(SelectionDEV(lst_poly), SelectionDEV(lst_poly), nb);   ///On cr�� une nouvelle case qui contient l'addition des 2 polynomes
                if (nb == 1) printf("\nAddition effectuee !\nResultat : ");
                else printf("\nSoustraction effectuee !\nResultat : ");
                if(queue_poly->suivant->dvp->tete != NULL)
                {
                    queue_poly = queue_poly->suivant;        ///On incremente la queue de la liste de polynomes
                    AfficherDEV(queue_poly->dvp->tete);     ///Affichage du resultat
                }
                else
                {
                    printf("0\n");
                    free(queue_poly->suivant);
                    queue_poly->suivant = NULL;
                }
                printf("\n");
                system("pause");
            }
            else if(nb == 3)
            {
                printf("MULTIPLICATION");
                AfficherPoly(lst_poly);
                queue_poly->suivant = creatCellPOLY();
                queue_poly->suivant->dvp = MultiplicationPoly(SelectionDEV(lst_poly), SelectionDEV(lst_poly));   ///Case poly multipli�e
                printf("\nMultiplication effectuee !\nResultat : ");
                queue_poly = queue_poly->suivant;
                AfficherDEV(queue_poly->dvp->tete);
                printf("\n");
                system("pause");
            }
            else if(nb == 4)
            {
                printf("DIVISION");
                AfficherPoly(lst_poly);
                printf("\nPremier Polynome : dividende, Deuxieme Polynome : diviseur\n");
                queue_poly->suivant = creatCellPOLY();
                queue_poly->suivant->dvp = DivisionPoly(SelectionDEV(lst_poly), SelectionDEV(lst_poly));
                printf("\nDivision effectuee !\nResultat : \n\nQuotient = ");
                if(queue_poly->suivant->dvp->tete == NULL)   ///Quotient nul = On supprime la case poly
                {
                    printf("0");        ///Affichage quotient
                    printf("\nReste = ");
                    AfficherDEV(queue_poly->suivant->dvp->queue);
                    free(queue_poly->suivant->dvp->tete);
                    queue_poly->suivant->dvp->queue = NULL; ///Il ne faut pas supprimer le diviseur de la memoire !
                    free(queue_poly->suivant->dvp);
                    free(queue_poly->suivant);
                    queue_poly->suivant = NULL;
                }
                else  ///Quotient non nul
                {
                    queue_poly = queue_poly->suivant;
                    AfficherDEV(queue_poly->dvp->tete); ///Affichage quotient
                    printf("\nReste = ");
                    if(queue_poly->dvp->queue == NULL)  printf("0");     ///Reste Nul = Affichage, pas de stockage
                    else
                    {   ///Si quotient et reste non nuls, Reste stock� dans un deuxi�me polynome
                        queue_poly->suivant = creatCellPOLY();
                        queue_poly->suivant->dvp = creatCellDEV_etoile();
                        queue_poly->suivant->dvp->tete = queue_poly->dvp->queue;
                        queue_poly = queue_poly->suivant;
                        AfficherDEV(queue_poly->dvp->tete);
                    }
                }
                printf("\n");
                system("pause");
            }
            else if(nb == 5)
            {
                printf("DERIVATION");
                AfficherPoly(lst_poly);
                queue_poly->suivant = creatCellPOLY();
                queue_poly->suivant->dvp = creatCellDEV_etoile();
                queue_poly->suivant->dvp = DerivationPoly(SelectionDEV(lst_poly));   ///Case poly deriv�e
                printf("\nDerivation effectuee !\nResultat : ");
                if(queue_poly->suivant != NULL)
                {
                    queue_poly = queue_poly->suivant;        ///On incremente la queue de la liste de polynomes
                    AfficherDEV(queue_poly->dvp->tete);     ///Affichage du resultat
                }
                else    printf("0\n");
                printf("\n");
                system("pause");
            }
            else if(nb == 6)
            {
                printf("INTEGRATION");
                AfficherPoly(lst_poly);
                queue_poly->suivant = creatCellPOLY();
                queue_poly->suivant->dvp = creatCellDEV_etoile();
                queue_poly->suivant->dvp = IntegrationPoly(SelectionDEV(lst_poly));   ///Case poly deriv�e
                printf("\nIntegration effectuee !\nResultat : ");
                queue_poly = queue_poly->suivant;        ///On incremente la queue de la liste de polynomes
                AfficherDEV(queue_poly->dvp->tete);     ///Affichage du resultat
                printf("\n");
                system("pause");
            }
            else if(nb == 7 || nb == 8)
            {
                if(nb == 7) printf("CONJUGUE");
                if(nb == 8) printf("EXTRACTION");
                AfficherPoly(lst_poly);
                AffiPolyAvance(SelectionDEV(lst_poly), nb);
            }
            else if(nb == 9)
            {
                printf("COMPARAISON");
                AfficherPoly(lst_poly);
                nb = Comparaison(SelectionDEV(lst_poly), SelectionDEV(lst_poly));
                if(nb == 0) printf ("\nEgalit� !\n");
                else if(nb == 1) printf ("\nLe premeir polynome selectionne est plus grand que le deuxieme\n");
                else printf ("\nLe deuxieme polynome selectionne est plus grand que le premier\n");
                system("pause");
            }
            else if(nb == 10)
            {
                printf("EVALUATION");
                AfficherPoly(lst_poly);
                printf("\nSaisir la valeur de X : ");
                scanf("%d", &nb);
                eval = EvaluationPoly(SelectionDEV(lst_poly), nb);
                printf("\nResultat = ");
                if(eval.re != 0)   printf("%g", eval.re);         //on gere les cas d'affichage des coefs nuls ou negatifs
                if((eval.im > 0) && (eval.re != 0))   printf("+");
                if(eval.im != 0)   printf("%gi", eval.im);
                if(eval.im == 0 && eval.re == 0)    printf("0");
                printf("\n");
                system("pause");
            }
           /* else if(nb == 11)
            {
                printf("PGCD");
                AfficherPoly(lst_poly);
                queue_poly->suivant = creatCellPOLY();
                queue_poly->suivant->dvp = PGCD(SelectionDEV(lst_poly), SelectionDEV(lst_poly));   ///Case poly multipli�e
                printf("\nCalcul du PGCD effectuee !\nResultat : ");
                queue_poly = queue_poly->suivant;
                AfficherDEV(queue_poly->dvp->tete);
                printf("\n");
                system("pause");
            }*/
            break;
        case 5 :
            break;
        case 6:
            quitter = 1;
            break;
        }
    }while(quitter == 0);

    return 0;
}



void menu()
{
        system("cls");  ///Menu d'acceuil, les differentes options possibles
        printf("--------------------Menu--------------------\n");
        printf("1) Affichage liste des polynomes (forme DEV)\n");
        printf("2) Ajouter un polynome\n");
        printf("3) Supprimer tous les polynomes\n");
        printf("4) Voir les operations possibles sur les ploynomes\n");
        printf("5) Menu vide\n");
        printf("6) Quitter\n");
}


void saisieManuelle(t_polynome* lst_poly)
{
    int nbpoly;
    t_polynome tmp = NULL;
    double *tab = NULL;

    if(*lst_poly == NULL)       ///Cas ou on cree la liste et on stocke dedans.
    {
        do{
            printf("Nombre de polynomes a inserer ?\n");
            scanf("%d", &nbpoly);
        }while(nbpoly < 0);
        if(nbpoly != 0)     construireListe(lst_poly, nbpoly);
        tmp = (*lst_poly);
    }
    else        ///Cas ou la liste poly existe deja, on rajoute une boite poly � la fin de la liste.
    {
        tmp = AjouterPoly(lst_poly);
    }
    while(tmp != NULL)
    {
        system("cls");
        tab = saisir(tmp->dvp->queue, 1); ///saisie puissance max
        while(tab[0] >= 0)
        {
            remplirDEV(&(tmp->dvp), tab);         ///On envoie la liste polynome ainsi qu'un monome : on rajoute maillon par maillon.
            system("cls");
            printf("Pour quitter, rentrez une puissance negative !\n\n");
            printf("Votre polynome : ");
            AfficherDEV(tmp->dvp->tete);
            printf("\n");
            if(tab[0] == 0) tab[0] = -1;    ///On sort
            else if(tab[0] > 0)  tab = saisir(tmp->dvp->queue, 2);    ///saisie generale
        }

        free(tab);
        tmp=tmp->suivant;
        printf("\nPolynome enregistre!\n");
        system("pause");
    }
}


void saisieAutomatique(t_polynome* lst_poly)
{

    int nbpoly, deg_max, cpt = 1;
    t_polynome tmp = NULL;
    double *tab = NULL;
    srand(time(NULL)); ///Initialise la fonction aleatoire

    tab = malloc(3*sizeof(double));
    do{
        printf("\nNombre de polynomes a inserer ?\n");
        scanf("%d", &nbpoly);
    }while(nbpoly < 0);
    if(nbpoly != 0)     construireListe(lst_poly, nbpoly);

    tmp = (*lst_poly);
    system("cls");

    while(tmp != NULL)
    {
        do{
            printf("Saisissez le degre maximal du polynome %d qui va etre genere: ", cpt);
            scanf("%d",&deg_max);
        }while(deg_max < 0);

        do
        {
            tab[0] = deg_max;   ///Fonction aleatoire
            tab[1] = ((rand()%2000) / 10.0) - 100;   ///Generation d'un nombre, /10 pour 1 chiffre apr�s virgule
            tab[2] = ((rand()%2000) / 10.0) - 100;   ///et -100 pour avoir la possibilit� d'un nombre negatif
            remplirDEV(&(tmp->dvp), tab);               ///Coefs generes entre -100 et 100 !
            deg_max--;
        }while(deg_max >= 0);
        tmp=tmp->suivant;
        printf("Polynome %d genere avec succes !\n\n", cpt);
        cpt++;
    }
    free(tab);
}
