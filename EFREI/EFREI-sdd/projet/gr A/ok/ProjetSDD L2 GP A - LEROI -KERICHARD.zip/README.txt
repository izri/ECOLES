Fonctionnalit�s du programme :
- Toutes les structures de donn�es ont �t� cr��s
- Forme d�velop�e
- Forme factoris�e
- Coefficient complexes
- Operations d'addition, soustraction, multiplication, division (euclidienne), conjugaison, comparaison, extraction des parties reelle et imaginaire de polynomes.
- Evaluation en un point (Ruffini-Horner)
- Derivation et integration

Fonctionnalit�s non finies :
- Recherche du PGCD de deux polynomes

Fonctionnalit�s non effectu�s :
- Recherche de racines et factorisation
- Compositions, d�composition (pour changements de variables)
- Les fonctions du niveau interm�diare

