#include <stdio.h>
#include <stdlib.h>
#include "header.h"

dev* AddiSousPoly(dev *p2, dev *p1, int choix)
{
    double *tab = NULL;
    dev *p3 = NULL;

    if(Comparaison(p1,p2) == 0)  p1 = duplicationDEV(p1);
    p3 = creatCellDEV_etoile();      ///Initialisation des pointeurs des tetes de liste DEV
    p1->queue = p1->tete;
    p2->queue = p2->tete;
    tab = malloc(3*sizeof(double));

    while(p1->queue != NULL || p2->queue != NULL)
    {
        if(p1->queue == NULL)         ///Si on a fini le poly 1, on ajoute le poly 2
        {
            tab[0] = p2->queue->puis;
            if (choix == 1)                         /// Pour l'addition
            {
                tab[1] = p2->queue->coef.re;
                tab[2] = p2->queue->coef.im;
            }
            else if (choix == 2)                    /// Pour la soustraction
            {
                tab[1] = -p2->queue->coef.re;
                tab[2] = -p2->queue->coef.im;
            }
            p2->queue = p2->queue->suiv;
        }
        else if(p2->queue == NULL)    ///On ajoute tmp1
        {
            tab[0] = p1->queue->puis;
            tab[1] = p1->queue->coef.re;
            tab[2] = p1->queue->coef.im;
            p1->queue = p1->queue->suiv;
        }
        else                            ///p1 et p2 ne sont pas nuls
        {
            if((p1->queue->puis < p2->queue->puis))             ///Puissance Poly 2 superieure a celle du Poly 1
            {
                tab[0] = p2->queue->puis;
                if (choix == 1)                         /// Pour l'addition
                {
                    tab[1] = p2->queue->coef.re;
                    tab[2] = p2->queue->coef.im;
                }
                else if (choix == 2)                    /// Pour la soustraction
                {
                    tab[1] = -p2->queue->coef.re;
                    tab[2] = -p2->queue->coef.im;
                }
                p2->queue = p2->queue->suiv;
            }

            else if((p2->queue->puis < p1->queue->puis))       ///Puissance du Poly 1 superieure a celle de Poly 2
            {
                tab[0] = p1->queue->puis;
                tab[1] = p1->queue->coef.re;
                tab[2] = p1->queue->coef.im;
                p1->queue = p1->queue->suiv;
            }
            else                                             ///Puissance Poly 1 = Poly2
            {
                tab[0] = p1->queue->puis;
                if (choix == 1)                                                 /// Pour l'addition
                {
                    tab[1] = p1->queue->coef.re + p2->queue->coef.re;
                    tab[2] = p1->queue->coef.im + p2->queue->coef.im;
                }
                else if (choix == 2)                                            /// Pour la soustraction
                {
                    tab[1] = p1->queue->coef.re - p2->queue->coef.re;
                    tab[2] = p1->queue->coef.im - p2->queue->coef.im;
                }
                p1->queue = p1->queue->suiv;
                p2->queue = p2->queue->suiv;
            }
        }
        remplirDEV(&p3, tab);
    }

    return p3;
}


dev* MultiplicationPoly(dev *p1, dev *p2)
{
    int present = 0;
    dev *p3 = NULL;
    t_developpe check = NULL;
    double *tab = NULL;

    p3 = creatCellDEV_etoile();

    p1->queue = p1->tete;
    p2->queue = p2->tete;
    tab = malloc(3*sizeof(double));

    while(p1->queue != NULL)  ///On multiplie deja le 1er coef du 2eme poly a tous les coef du 1er poly
    {
        tab[0] = (p1->queue->puis) + (p2->queue->puis);
        ///Multiplication complexe
        tab[1] = (p1->queue->coef.re * p2->queue->coef.re) - (p1->queue->coef.im * p2->queue->coef.im);
        tab[2] = (p1->queue->coef.re * p2->queue->coef.im) + (p1->queue->coef.im * p2->queue->coef.re);
        remplirDEV(&p3, tab);
        p1->queue = p1->queue->suiv;
    }
    p2->queue = p2->queue->suiv;    ///On decale du 1er au 2eme coef du polynome 2

    while(p2->queue != NULL)  ///On va multiplier tous les coefs du 2eme poly(sauf le premier car deja fait) a tous ceux du 1er poly
    {
        p1->queue = p1->tete;
        while(p1->queue != NULL)
        {
            present = 0;
            tab[0] = p1->queue->puis + p2->queue->puis;
            ///Multiplication complexe
            tab[1] = (p1->queue->coef.re * p2->queue->coef.re) - (p1->queue->coef.im * p2->queue->coef.im);
            tab[2] = (p1->queue->coef.re * p2->queue->coef.im) + (p1->queue->coef.im * p2->queue->coef.re);

            check = p3->tete; ///On veut verifier si la puissance de X est presente ou non dans la liste
            while(check != NULL)
            {
                if(check->puis == tab[0])   ///La puissance est deja presente
                {
                    check->coef.re = check->coef.re + tab[1];   ///Alors on additionne les coefs de meme puissance
                    check->coef.im = check->coef.im + tab[2];
                    present = 1;
                    check = NULL;
                }
                else if(check->puis < tab[0])   check = NULL;
                else    check = check->suiv;
            }
            if(present == 0)    remplirDEV(&p3, tab);  ///On ne cr�� une case qu'a la condition que la puissance de X n'existe pas encore
            p1->queue = p1->queue->suiv;
        }
        p2->queue = p2->queue->suiv;
    }
    return p3;
}


dev* DerivationPoly(dev* p1)
{
    dev *p3 = NULL;
    double *tab = NULL;

    if(p1->tete->puis == 0)    return NULL;    ///Polynome de puissance 0 (va donner le poly nul)

    tab = malloc(3*sizeof(double));
    p3 = creatCellDEV_etoile();
    p1->queue = p1->tete;

    while(p1->queue != NULL && p1->queue->puis != 0)        ///On derive toutes les puissances > 0 et on les stocke
    {
        tab[0] = (p1->queue->puis)-1;                          ///La constante n'est pas stock�e (puissance 0)
        tab[1] = (p1->queue->puis * p1->queue->coef.re);
        tab[2] = (p1->queue->puis * p1->queue->coef.im);
        remplirDEV(&p3, tab);
        p1->queue = p1->queue->suiv;
    }
    return p3;
}


dev* IntegrationPoly(dev *p1)
{
    dev *p3 = NULL;
    double *tab = NULL;

    p3 = creatCellDEV_etoile();
    tab = malloc(3*sizeof(double));
    p1->queue = p1->tete;

    while(p1->queue != NULL)        ///On integre
    {
        tab[0] = (p1->queue->puis)+1;
        tab[1] = (p1->queue->coef.re / tab[0]);
        tab[2] = (p1->queue->coef.im / tab[0]);
        remplirDEV(&p3, tab);
        p1->queue = p1->queue->suiv;
    }

    printf("\nSaisissez la partie reelle de la constante ? :");     ///Ajout de la constante saisie
    scanf("%lf", &tab[1]);
    printf("\nSaisissez la partie imaginaire de la constante ? :");
    scanf("%lf", &tab[2]);
    tab[0] = 0;
    remplirDEV(&p3, tab);
    return p3;
}


dev* DivisionPoly(dev *diviseur, dev *dividende)
{
    dev *reste = NULL, *quotient = NULL, *sup = NULL, *save_div = NULL, *fin = NULL, *tmp_quot = NULL;
    t_developpe tmp = NULL;

    if(diviseur->tete->puis > dividende->tete->puis)
    {
        fin = creatCellDEV_etoile();

        fin = duplicationDEV(diviseur);   ///RESTE = dividende dupliqu�
        fin->queue = fin->tete;
        fin->tete = NULL;       ///QUOTIENT

        return fin;
    }

    else
    {   ///CALCUL QUOTIENT
        quotient = creatCellDEV_etoile();
        quotient->tete = creatCellDEV();
        quotient->tete->puis = (dividende->tete->puis) - (diviseur->tete->puis);         ///Puissance d'un terme du quotient
        quotient->tete->coef.re = ((dividende->tete->coef.re * diviseur->tete->coef.re) + (dividende->tete->coef.im * diviseur->tete->coef.im)) / ((diviseur->tete->coef.re * diviseur->tete->coef.re) + (diviseur->tete->coef.im * diviseur->tete->coef.im));
        quotient->tete->coef.im = ((diviseur->tete->coef.re * dividende->tete->coef.im) - (dividende->tete->coef.re * diviseur->tete->coef.im)) / ((diviseur->tete->coef.re * diviseur->tete->coef.re) + (diviseur->tete->coef.im * diviseur->tete->coef.im));
        ///CALCUL RESTE
        sup = MultiplicationPoly(quotient, diviseur);
        reste = AddiSousPoly(sup, dividende, 2);    ///Reste = Dividende - (Quotient * Diviseur)
        if(reste->tete == NULL) return quotient;
        system("pause");
        if(sup != NULL)
        {
            sup->queue = sup->tete;
            while(sup->tete->suiv != NULL)
            {
                sup->tete = sup->tete->suiv;
                free(sup->tete);      ///Vieux dividende effac�
            }
            free(sup->queue);
            free(sup);
        }
        if(reste->tete != NULL)       ///Reste non completement nul car l'ordi tronque = on le supprime
        {
            if(reste->tete->puis == dividende->tete->puis)
            {
                tmp = reste->tete;
                reste->tete = reste->tete->suiv;
                free(tmp);
            }
        }
        quotient->queue = quotient->tete;   ///On sauvegarde la tete du quotient
        save_div = creatCellDEV_etoile();   ///On sauvegarde le dividende de base
        save_div->tete = dividende->tete;
        dividende->tete = NULL;
        tmp_quot = creatCellDEV_etoile();
        if(reste->tete != NULL)
        {
            while(reste->tete->puis >= diviseur->tete->puis)
            {
                dividende->tete = reste->tete;      ///Le dividende devient l'ancien reste
                reste->tete = NULL;

                quotient->queue->suiv = creatCellDEV();              ///CALCUL DU TERME SUIVANT DU QUOTIENT
                quotient->queue = quotient->queue->suiv;
                quotient->queue->puis = (dividende->tete->puis) - (diviseur->tete->puis);         ///Puissance d'un terme du quot
                quotient->queue->coef.re = ((dividende->tete->coef.re * diviseur->tete->coef.re) + (dividende->tete->coef.im * diviseur->tete->coef.im)) / ((diviseur->tete->coef.re * diviseur->tete->coef.re) + (diviseur->tete->coef.im * diviseur->tete->coef.im));
                quotient->queue->coef.im = ((diviseur->tete->coef.re * dividende->tete->coef.im) - (dividende->tete->coef.re * diviseur->tete->coef.im)) / ((diviseur->tete->coef.re * diviseur->tete->coef.re) + (diviseur->tete->coef.im * diviseur->tete->coef.im));
                ///CALCUL RESTE
                tmp_quot->tete = quotient->queue;
                tmp_quot->queue = NULL;
                sup = MultiplicationPoly(tmp_quot, diviseur);
                reste = AddiSousPoly(sup, dividende, 2);    ///Reste = Dividende - (Quotient * Diviseur)
                quotient->queue = quotient->tete;
                while(quotient->queue->suiv != NULL)    quotient->queue = quotient->queue->suiv;    ///Maj queue de quotient
                if(reste->tete != NULL )       ///Reste non completement nul car l'ordi tronque = on le supprime
                {
                    if(reste->tete->puis == dividende->tete->puis)
                    {
                        tmp = reste->tete;
                        reste->tete = reste->tete->suiv;
                        free(tmp);
                    }
                }
                ///SUPPRESSION POLYNOME ISSU DE LA MULTIPLICATION
                sup->queue = sup->tete;
                while(sup->tete->suiv != NULL)      ///Suppression du polynome de la multiplication
                {
                    sup->tete = sup->tete->suiv;
                    free(sup->tete);
                }
                free(sup->queue);

                 ///SUPPRESSION VIEUX DIVIDENDE
                dividende->queue = dividende->tete;

                while(dividende->tete != NULL)
                {
                    free(dividende->tete);          ///Vieux dividende effac�
                    dividende->tete = dividende->tete->suiv;

                }
                dividende->queue = NULL;
                if(reste == NULL )  break;
                else if (reste->tete == NULL)   break;
            }
        }
        dividende->tete = save_div->tete;
        dividende->queue = NULL;
        fin = creatCellDEV_etoile();        ///RENVOI DES VALEURS
        fin->tete = quotient->tete; ///Stockage du quotient
        if(reste != NULL)   fin->queue = reste->tete;   ///Stockage du reste
        else                fin->queue = NULL;

        return fin;
    }
}


t_complexe EvaluationPoly(dev *poly, int val)
{
    dev *tmp = NULL;
    t_complexe resultat;
    int puis = poly->tete->puis;
    int cpt, x;

    poly->queue = poly->tete;
    while (poly->queue->suiv != NULL) poly->queue = poly->queue->suiv;

    if(val == 0)    ///Cas ou on �value en 0
    {
        if (poly->queue->puis == 0)         ///Cas ou la puissance est 0, on renvoit la partie constante
        {
            resultat.im = poly->queue->coef.im;
            resultat.re = poly->queue->coef.re;
            return resultat;
        }
        else        ///Cas ou il y a pas de partie constante, le resultat est nul
        {
            resultat.im = 0;    ///On gere le cas ou il n'y a pas de constante dans le poly
            resultat.re = 0;
            return resultat;
        }
    }

    poly->queue = poly->tete;
    resultat = poly->queue->coef;
    for(cpt=1; cpt<=puis; cpt++)
    {

        if (poly->queue->suiv != NULL)  ///Utile quand les puissances ne sont pas d�croissantes 1 � 1
        {
            x = poly->queue->puis - poly->queue->suiv->puis;
            poly->queue = poly->queue->suiv;
            resultat.re = (resultat.re * puissance(val, x)) + poly->queue->coef.re;
            resultat.im = (resultat.im * puissance(val, x)) + poly->queue->coef.im;
        }
        else
        {
            x = poly->queue->puis;
            resultat.re = (resultat.re * puissance(val, x));
            resultat.im = (resultat.im * puissance(val, x));
        }
        cpt = x + cpt -1;       ///On prend en compte le d�calage de puissance
    }

    return resultat;
}

int puissance(int a, int n)     ///a : nombre, n : puissance
{
    if(n == 0)  return 1;
    else return (a * puissance(a, n-1));
}

/*
dev* PGCD(dev *poly2, dev *poly1)
{
    dev *resultat = NULL, *resultat2 = NULL, *p1 = NULL, *p2 = NULL;
    int maxi;

    p1 = duplicationDEV(poly1);
    p2 = duplicationDEV(poly2);
    maxi = Comparaison(p1, p2);

    if(maxi == 0)   return p1;
    resultat = DivisionPoly(p2, p1);       ///Diviseur , Dividende
    if(maxi == 1)
    {
        p1->queue = p1->tete;       ///echange de p1 et p2 car dividende < diviseur
        p1->tete = p2->tete;
        p2->tete = p1->queue;
        p1->queue = NULL;
        p2->queue = NULL;
        while(resultat->queue != NULL)       ///SUPPRESSION DU RESTE CREE
        {
            free(resultat->queue);          ///On supprime le dividende
            resultat->queue = resultat->queue->suiv;
        }
        resultat = DivisionPoly(p2, p1);
    }

    if(Comparaison(resultat->tete, p2) == 2)        ///P2 > quotient, on doit les inverser
    {
        p2->queue = resultat->tete;
        resultat->tete = p2->tete;
        p2->tete = p2->queue;
    }
    while(p1->tete != NULL)
    {
        free(p1->tete);          ///On supprime le dividende
        p1->tete = p1->tete->suiv;
    }
    while(resultat->tete != NULL)
    {
        free(resultat->tete);          ///On supprime le quotient
        resultat->tete = resultat->tete->suiv;
    }
    if(resultat->queue == NULL)
    {
        printf("\nFini, le PGCD est : maxi :%d\n", Comparaison(p1,p2));
        AfficherDEV(p2->tete);
        system("pause");
        return p2;           ///Reste Nul : Pgcd = diviseur
    }
    printf("3");
    system("pause");
    while(resultat->queue != NULL)
    {
        while(resultat->tete != NULL)///SUPPRESSION QUOTIENT
        {
            free(resultat->tete);
            resultat->tete = resultat->tete->suiv;
        }
        resultat->tete = resultat->queue;
        p1->tete = p2->tete;
        p2->tete = resultat->tete;
        p1->queue = NULL;
        p2->queue = NULL;
        free(resultat);

        resultat = DivisionPoly(p2, p1);       ///Diviseur , Dividende

        while(p1->tete != NULL)
        {
            free(p1->tete);              ///On supprime le dividende
            p1->tete = p1->tete->suiv;
        }
    }
    printf("\nFini, le PGCD est : ");

    AfficherDEV(p2->tete);
    system("pause");
    return p2;
}
*/

