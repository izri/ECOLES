#include <stdio.h>
#include <stdlib.h>
#include "header.h"

t_developpe creatCellDEV()
{
    t_developpe case_dev;

    case_dev = (t_developpe)malloc(sizeof(developpe));
    case_dev->suiv = NULL;
    return case_dev;
}



void AfficherDEV(t_developpe liste)
{
    t_developpe element = liste;

    if (element == NULL) printf("\nPolynome nul !\n");
    else
    {

        while(element != NULL)          // on parcourt la liste a afficher
        {
            if(element->puis != 0) printf("(");
            if(element->coef.re != 0)   printf("%g", element->coef.re);         //on gere les cas d'affichage des coefs nuls ou negatifs
            if((element->coef.im > 0) && (element->coef.re != 0))   printf("+");
            if(element->coef.im != 0)   printf("%gi", element->coef.im);

            if(element->puis == 1)  printf(")x");
            else if(element->puis != 0)   printf(")x^%d", element->puis);

            if(element->suiv != NULL) printf(" + ");
            element = element->suiv;
        }
    }
    free(element);
}


void remplirDEV(dev **dvp, double* monome)
{
    ///On remplit seulement si les coef sont pas nuls !
    if(monome[1] != 0 || monome[2] != 0)
    {
        if ((*dvp)->tete == NULL)
        {
            (*dvp)->tete = creatCellDEV();            ///Premier element
           (*dvp)->tete->prec = NULL;
           (*dvp)->queue = (*dvp)->tete;
        }
        else
        {
            (*dvp)->queue->suiv = creatCellDEV();      ///Autre element
            (*dvp)->queue = (*dvp)->queue->suiv;
        }
        (*dvp)->queue->puis = monome[0];
        (*dvp)->queue->coef.re = monome[1];
        (*dvp)->queue->coef.im = monome[2];
    }
}


double * saisir(t_developpe dev_queue, int cas)
{
    double *tmp = NULL;
    int maxi, puis;

    tmp = malloc(3 * sizeof(double));
    if(cas == 1)
    {
        do{
            printf("Saisissez la puissance maximale de votre polynome : ");
            scanf("%d", &maxi);
        }while(maxi < 0);

        tmp[0] = maxi;

        do{
            printf("\nSaisir le coefficient reel correspondant a x^%d : ", maxi);
            scanf("%lf", &tmp[1]);
            printf("\nSaisir le coefficient imaginaire correspondant a x^%d : ", maxi);
            scanf("%lf", &tmp[2]);
        }while(tmp[1] == 0 && tmp[2] == 0);

    }

    else if(cas == 2)
    {
                do{ ///tant que puissance decroissante
                printf("\nSaisir la puissance tel que X<%d : ", dev_queue->puis);
                scanf("%d", &puis);
        }while(puis >= dev_queue->puis);

        tmp[0] = puis;
        if(tmp[0] >= 0)
        {
            printf("\nSaisir le coefficient reel correspondant a x^%d : ", puis);
            scanf("%lf", &tmp[1]);
            printf("\nSaisir le coefficient imaginaire correspondant a x^%d : ", puis);
            scanf("%lf", &tmp[2]);
        }
        else
        {
            tmp[1] = 0;
            tmp[2] = 0;
        }
    }
    return tmp;
}


void supprimerDev(t_developpe lst)
{
    t_developpe tmp = NULL;

    if(lst == NULL) return;
    else
    {
        while(lst != NULL)
        {
            tmp = lst->suiv;
            free(lst);
            lst = tmp;
        }
    }
}


dev* SelectionDEV(t_polynome lst_poly)
{
    int nb, cpt = 1;
    t_polynome poly = lst_poly;

    do{
        printf("\nVeuillez saisir un polynome : ");
        scanf("%d", &nb);
    }while(nb <= 0);

    while (cpt < nb && poly->suivant != NULL)
    {
        poly = poly->suivant;
        cpt++;
    }
    return poly->dvp;
}

dev*    duplicationDEV(dev *originel)
{
    dev *doublon = creatCellDEV_etoile();
    double *tab = malloc(3*sizeof(double));

    if(originel == NULL)        return NULL;
    if(originel->tete == NULL)  return doublon;

    tab[0] = originel->tete->puis;
    tab[1] = originel->tete->coef.re;
    tab[2] = originel->tete->coef.im;
    remplirDEV(&doublon, tab);
    originel->queue = originel->tete->suiv;
    while(originel->queue != NULL)
    {
        tab[0] = originel->queue->puis;
        tab[1] = originel->queue->coef.re;
        tab[2] = originel->queue->coef.im;
        remplirDEV(&doublon, tab);
        originel->queue = originel->queue->suiv;
    }

    return doublon;
}


