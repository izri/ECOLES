#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "conio.h"
#include "projet_sdd_versionX.h"

void Addition(monome* polynome1, monome* polynome2, monome** polynome3)
{

    monome * tmp1 ;
    monome * tmp2 ;
    tmp1 = polynome1 ;
    tmp2 = polynome2 ;

    while ((tmp1 != NULL)&&(tmp2 != NULL))//on additionne ssi les deux polynome existe
    {
        monome * resultat ;
        resultat = (monome*)malloc(sizeof(monome));
        resultat->suivant = NULL;

        if((tmp1->puissance) == (tmp2->puissance))//on v�rifie les puissances pour additionner
        {
            resultat->puissance = tmp1->puissance;
            resultat->coef.imaginaire = tmp1->coef.imaginaire + tmp2->coef.imaginaire;
            resultat->coef.reel = tmp1->coef.reel + tmp2->coef.reel;

            AjoutMonome(polynome3,resultat);

            tmp1 = tmp1->suivant;
            tmp2 = tmp2->suivant;
        }
        else if (tmp1->puissance > tmp2->puissance)
        {
            resultat->puissance = tmp1->puissance;
            resultat->coef.imaginaire = tmp1->coef.imaginaire;
            resultat->coef.reel = tmp1->coef.reel;

            AjoutMonome(polynome3,resultat);

            tmp1 = tmp1->suivant;
        }
        else /*(tmp1->puissance < tmp2->puissance)*/
        {
            resultat->puissance = tmp2->puissance;
            resultat->coef.imaginaire = tmp2->coef.imaginaire;
            resultat->coef.reel = tmp2->coef.reel;

            AjoutMonome(polynome3,resultat);

            tmp2 = tmp2->suivant;
        }
    }

    while(tmp1!=NULL)//cas ou 1 polynome est nul
    {
        monome * copie ;
        copie = (monome*)malloc(sizeof(monome));
        copie->suivant = NULL;

        copie->puissance = tmp1->puissance;
        copie->coef.imaginaire = tmp1->coef.imaginaire;
        copie->coef.reel = tmp1->coef.reel;

        AjoutMonome(polynome3,copie);

        tmp1 = tmp1->suivant;
    }
    while(tmp2!=NULL)//cas ou l'autre polynome est nul
    {
        monome * copie ;
        copie = (monome*)malloc(sizeof(monome));
        copie->suivant = NULL;

        copie->puissance = tmp2->puissance;
        copie->coef.imaginaire = tmp2->coef.imaginaire;
        copie->coef.reel = tmp2->coef.reel;

        AjoutMonome(polynome3,copie);

        tmp2 = tmp2->suivant;
    }
}

void AffichagePolynomeDvp(monome* poly_developpe,int res_sous)
{
    monome* temp = poly_developpe;
    int cpt = 0;


    while (temp != NULL)
    {
        if ((temp->coef.reel!=0.00) || (temp->coef.imaginaire != 0.00))
        {
            if(res_sous == 2 && cpt== 0)
            {
                printf("-");
            }
            if(res_sous == 3)
            {
                printf("-");
            }
            printf("(");
            if(temp->coef.reel != 0)
                printf("%.0lf",temp->coef.reel);
            if(temp->coef.imaginaire > 0 && temp->coef.reel != 0)
                printf("+");
            if(temp->coef.imaginaire != 0)
                printf("%.0lfi",temp->coef.imaginaire);
            printf(")");
            if(temp->puissance != 0)
            {
                if (temp->puissance == 1)
                {
                    printf("x");
                }
                else
                {
                    printf("x^%d", temp->puissance);
                }
            }

            if (temp->suivant != NULL)
            {
                printf(" + ");
            }

        }
        cpt = cpt + 1;
        temp = temp->suivant;
    }
    printf("\n");
    temp = NULL ;
}

monome * AjoutMonome (monome ** polynome1 , monome * monome1)
{
    if (*polynome1 == NULL)
    {
        *polynome1 = monome1 ;
    }
    else
    {
        monome* tmp = (*polynome1);

        while(tmp->suivant != NULL)
        {
            tmp = tmp -> suivant ;
        }

        tmp -> suivant = monome1 ;
    }

    return *polynome1;
}

void ConstruirePolynome(monome ** poly_developpe) // creation de toute la liste double etoile car modification contenue
{
    monome * m1, *tmp;
    int i,nb;

    printf("--> Nombre de monomes ? \n");
    scanf("%d", &nb);

    for(i = 1 ; i <= nb ; i++)
    {
        if(i == 1)
        {
            m1 =  CreationMonome();
            (*poly_developpe)=m1;
            tmp = (*poly_developpe);
        }
        else
        {

            m1 = CreationMonome();
            tmp->suivant = m1;
            tmp = tmp->suivant;
        }

    }

}

monome* CreationMonome()   // creation d'une nouvelle cellule
{
    monome* m;
    m = (monome*)malloc(sizeof(monome)); // allocation pour p qui aura comme type LSCcontact, et comme taille contact
    printf("saisir coefficient complexe \n");
    printf("saisir la partie reel \n");
    scanf("%lf", &m->coef.reel);
    printf("saisir la partie imaginaire \n");
    scanf("%lf",&m->coef.imaginaire);
    printf("saisir puissance \n");
    scanf("%d", &m->puissance);
    m -> suivant = NULL; // passer au maillon suivant

    return m;
}

void DeriverPolynome(monome*poly_developpe)
{
    if(poly_developpe != NULL)
    {

        (poly_developpe)->coef.reel = (poly_developpe)->coef.reel * (poly_developpe)->puissance;
        (poly_developpe)->coef.imaginaire = (poly_developpe)->coef.imaginaire * (poly_developpe)->puissance;
        (poly_developpe)->puissance--;

        printf("(%.0lf + %.0lfi)x^%d",poly_developpe->coef.reel, poly_developpe->coef.imaginaire,poly_developpe->puissance);

        poly_developpe= poly_developpe->suivant;
    }
}

void Evaluation(complexe * result, monome * poly_developpe, double point_eval)
{
    int puiss = poly_developpe->puissance-1;
    result->reel = result->reel * point_eval + poly_developpe->coef.reel;
    result->imaginaire = result->imaginaire* point_eval + poly_developpe->coef.imaginaire;

    monome * tmp = poly_developpe->suivant;
    if(tmp->suivant == NULL)
    {
        // CALCUL DIRECT A FAIRE
    }
    while(tmp != NULL || puiss >= 0)

    {
        if(tmp != NULL && tmp->puissance == puiss)
        {
            result->reel = result->reel * point_eval + tmp->coef.reel;
            result->imaginaire = result->imaginaire* point_eval + tmp->coef.imaginaire;

            tmp = tmp->suivant;
            puiss = puiss - 1;
        }
        else
        {
            result->reel = result->reel * point_eval;
            result->imaginaire = result->imaginaire* point_eval;

            puiss = puiss - 1;
        }
    }
    printf("%f + %fi \n",result->reel,result->imaginaire);
}

void IntegrationPolynome(monome *poly_developpe)
{
    int reponse,maximum,minimum;

    printf("le polynome integre est : \n");
    printf("1----Donnez les bornes de l'integrale \n");
    printf("2----Donnez la primitive \n");
    scanf("%d", &reponse);

    if (reponse==1)
    {
        printf("borne maximum : \n");
        scanf("%d", &maximum);
        printf("borne minimum : \n");
        scanf("%d", &minimum);
    }

    while (poly_developpe != NULL)
    {
        if (reponse==1)
        {
            TrierPolynome(&poly_developpe);
            InversionListe(&poly_developpe);
            printf("((%.0lf + %.0lfi)/ %d)^%d ",((poly_developpe->coef.imaginaire)*maximum),((poly_developpe->coef.reel)*maximum),((poly_developpe->puissance+1)*maximum),poly_developpe->puissance+1);
            if (poly_developpe->suivant != NULL)
            {
                if((poly_developpe->coef.imaginaire > 0) && (poly_developpe->coef.reel != 0))
                    printf("+");
            }
            poly_developpe = poly_developpe->suivant;
        }
        if (reponse==2)
        {
            TrierPolynome(&poly_developpe);
            InversionListe(&poly_developpe);
            printf("((%.0lf + %.0lfi)/ %d)x^%d ",poly_developpe->coef.imaginaire, poly_developpe->coef.reel,poly_developpe->puissance+1,poly_developpe->puissance+1);
            if (poly_developpe->suivant != NULL)
            {
                if(poly_developpe->coef.imaginaire > 0 && poly_developpe->coef.reel != 0)
                    printf("+");
            }
            poly_developpe = poly_developpe->suivant;
        }
    }
}

void InversionListe(monome **poly_developpe)
{
    monome* l = (*poly_developpe);
    if(!l || !(l->suivant))return;
    monome* q = l->suivant;
    InversionListe(&(l->suivant));
    q->suivant=l;
    (*poly_developpe)=l->suivant;
    q->suivant->suivant=NULL;
}

monome * Multiplication(monome * polynome,monome * polynome1, monome ** resultat)
{
    monome * tmp ;
    tmp = polynome ;

    if((polynome == NULL)||(polynome1==NULL))
    {
        return *resultat ;
    }

    while(tmp != NULL)
    {
        monome * tmp1 ;
        tmp1 = polynome1 ;

        while(tmp1 != NULL)
        {
            monome * copie ;
            copie = (monome*)malloc(sizeof(monome));
            copie -> suivant = NULL ;

            copie->coef.reel = (tmp->coef.reel*tmp1->coef.reel)-(tmp->coef.imaginaire*tmp1->coef.imaginaire);
            copie->coef.imaginaire = (tmp->coef.reel*tmp1->coef.imaginaire)+(tmp->coef.imaginaire*tmp1->coef.reel);
            copie->puissance = tmp->puissance + tmp1->puissance ;

            monome * resultattmp;
            resultattmp = NULL ;

            Addition(*resultat,copie,&resultattmp);

            while(*resultat != NULL)
            {
                monome * suivant ;
                suivant = (*resultat) -> suivant ;
                free (*resultat) ;
                *resultat = suivant ;
            }

            *resultat = resultattmp ;
            tmp1 = tmp1 -> suivant ;
        }
        tmp = tmp->suivant ;
    }

    AffichagePolynomeDvp(*resultat,1);
    return *resultat;
}

int NouveauPolynome(monome* poly_stockage,int nombre_polynome)
{
    if(nombre_polynome == 0)
    {
        poly_stockage =  malloc(sizeof(monome));

        if( poly_stockage == NULL )
        {
            fprintf(stderr,"Allocation impossible");
            exit(EXIT_FAILURE);
        }
        else
            nombre_polynome++;
        return nombre_polynome;
    }
    else
    {

        poly_stockage= realloc(poly_stockage, sizeof(monome*));
        nombre_polynome++;
        return nombre_polynome;
    }
}
int Soustraction(monome* polynome1, monome* polynome2, monome** polynome3)
{
    int res_sous;
    res_sous = 0;
    monome * tmp1 ;
    monome * tmp2 ;
    tmp1 = polynome1 ;
    tmp2 = polynome2 ;

    while ((tmp1 != NULL)&&(tmp2 != NULL))
    {
        monome * resultat ;
        resultat = (monome*)malloc(sizeof(monome));
        resultat->suivant = NULL;

        if((tmp1->puissance) == (tmp2->puissance))
        {
            resultat->puissance = tmp1->puissance;
            resultat->coef.imaginaire = tmp1->coef.imaginaire - tmp2->coef.imaginaire;
            resultat->coef.reel = tmp1->coef.reel - tmp2->coef.reel;

            AjoutMonome(polynome3,resultat);

            tmp1 = tmp1->suivant;
            tmp2 = tmp2->suivant;
        }
        else if (tmp1->puissance > tmp2->puissance)
        {
            res_sous = 3 ;
            resultat->puissance = tmp1->puissance;
            resultat->coef.imaginaire = tmp1->coef.imaginaire;
            resultat->coef.reel = tmp1->coef.reel;

            AjoutMonome(polynome3,resultat);

            tmp1 = tmp1->suivant;
        }
        else
        {
            res_sous = 2 ;
            resultat->puissance = tmp2->puissance;
            resultat->coef.imaginaire = tmp2->coef.imaginaire;
            resultat->coef.reel = tmp2->coef.reel;

            AjoutMonome(polynome3,resultat);

            tmp2 = tmp2->suivant;
        }
    }

    while(tmp1!=NULL)
    {
        monome * copie ;
        copie = (monome*)malloc(sizeof(monome));
        copie->suivant = NULL;

        copie->puissance = tmp1->puissance;
        copie->coef.imaginaire = tmp1->coef.imaginaire;
        copie->coef.reel = tmp1->coef.reel;

        AjoutMonome(polynome3,copie);

        tmp1 = tmp1->suivant;
    }
    while(tmp2!=NULL)
    {
        monome * copie ;
        copie = (monome*)malloc(sizeof(monome));
        copie->suivant = NULL;

        copie->puissance = tmp2->puissance;
        copie->coef.imaginaire = tmp2->coef.imaginaire;
        copie->coef.reel = tmp2->coef.reel;

        AjoutMonome(polynome3,copie);

        tmp2 = tmp2->suivant;
    }

    return res_sous;
}

void TrierPolynome(monome ** poly_developpe)
{
    int modif ;
    monome *tmp = NULL;

    do
    {
        modif = 0 ;
        monome * precedent = NULL;
        monome * courant = NULL;
        courant = (*poly_developpe);

        while (courant != NULL)
        {
            tmp = courant->suivant;
            if ( (courant->suivant != NULL) && ((courant->puissance) > (tmp->puissance)) )
            {
                modif = 1 ;
                monome * suivant ;
                suivant  = courant->suivant ;


                if (precedent == NULL)
                {
                    (*poly_developpe)=courant->suivant;
                    courant->suivant = suivant->suivant ;
                    suivant->suivant = courant ;

                }
                else
                {
                    courant->suivant = suivant->suivant ;
                    precedent->suivant = suivant ;
                    suivant->suivant  = courant ;
                }
            }
            precedent = courant ;
            courant = courant->suivant;
        }

    }
    while(modif!=0);

}

void TeteMenu()
{
    ///affichage de la tete
    int cpt;
    gotoxy(25,1);
    printf("############################");
    gotoxy(25,2);
    printf("# Calculatrice de Polynome #");
    gotoxy(25,3);
    printf("############################");
    for(cpt = 0; cpt < 19; cpt++)
    {
        gotoxy(50,cpt+4);
        printf("|");
    }
}
void Menu()
{
    ///initialisation des diff�rentes variables
    int reponse = 0;
    int saisie = 0;
    int selection = 0;
    int choix1 = -1;
    int choix2 = -1;
    double point_eval=0;
    int nombre_polynome;
    nombre_polynome=0;
    complexe result;
    monome* polynome;
    monome** poly_stockage;
    poly_stockage =  malloc(sizeof(monome*));
    result.reel = 0;
    result.imaginaire = 0;

    do
    {
        system("cls");
        TeteMenu();
        gotoxy(1,7);
        printf("- 1 - Nouveau Polynome \n\n");
        printf("- 2 - Supprimer Polynome \n\n");
        printf("- 3 - Operations Mathematiques \n\n");
        printf("- 4 - Informations et tests de Polynomes \n\n");
        printf("- 5 - Evalutation en un point \n\n");
        printf("- 6 - Demonstrations \n\n");
        printf("- 7 - Quitter \n\n");

        AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
        reponse=SaisieSecure(1,7);

        if( reponse == 1)
        {
            do
            {
                system("cls");
                TeteMenu();
                gotoxy(1,7);
                printf("- Nouveau Polynome \n\n");
                printf("  - 1 - Generer de facon aleatoire \n\n");
                printf("  - 2 - Entrer manuellement le Polynome \n\n");
                printf("  - 3 - Retour \n\n");
                AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
                saisie = SaisieSecure(1,3);

                if(saisie == 1)
                {
                    gotoxy(20,24);
                    printf("Construction du polynome, veuillez patienter...");
                    CreationMonomeAleatoire();
                    Sleep(1000);
                }
                else if(saisie == 2)
                {
                    ///cr�ation d'un polynome par un utilisateur
                    gotoxy(20,24);
                    nombre_polynome=NouveauPolynome(poly_stockage[nombre_polynome],nombre_polynome);
                    ConstruirePolynome(&polynome);
                    poly_stockage[nombre_polynome-1]=polynome;
                    TrierPolynome(&poly_stockage[nombre_polynome-1]);
                    InversionListe(&poly_stockage[nombre_polynome-1]);
                    AffichagePolynomeDvp(poly_stockage[nombre_polynome-1],1);
                }
            }
            while(saisie != 3);///sortir
            reponse = 0;
            saisie = 0;
        }
        if( reponse == 2 && nombre_polynome > 0)
        {
            do
            {
                system("cls");
                TeteMenu();
                gotoxy(1,7);
                printf("- Supprimer Polynome \n\n");
                printf("  - 1 - Selectionner le polynome a supprimer \n\n");
                printf("  - 2 - Retour \n\n");
                AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
                saisie = SaisieSecure(1,2);
                ///suppr�sion d'un polynome s�lectionn� par un polynome
                if(saisie == 1 && nombre_polynome != 0)
                {
                    nombre_polynome = SupprimerPolynome(poly_stockage,nombre_polynome);
                }
            }
            while(saisie != 2);///sortir
            reponse = 0;
            saisie = 0;
        }
        else if( reponse == 3 && nombre_polynome > 0)
        {
            do
            {
                system("cls");
                TeteMenu();
                gotoxy(1,7);
                printf("- Operations Mathematiques \n\n");
                printf("  - 1 - Operations Basiques \n\n");
                printf("  - 2 - Operations Avancees \n\n");
                printf("  - 3 - Retour \n\n");
                AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
                saisie = SaisieSecure(1,3);
                if (saisie == 1)
                {
                    do
                    {
                        system("cls");
                        TeteMenu();
                        gotoxy(1,7);
                        printf("  - 1 - Addition de deux polynomes \n\n");
                        printf("  - 2 - Soustractions de deux polynomes \n\n");
                        printf("  - 3 - Multiplication de deux polynomes \n\n");
                        printf("  - 4 - Division Euclidienne de deux polynomes \n\n");
                        printf("  - 5 - Retour \n\n");
                        AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
                        selection = SaisieSecure(1,5);
                        if(selection == 1)///addition
                        {
                            choix1 = selectionPolynome(nombre_polynome);
                            choix2 = selectionPolynome(nombre_polynome);
                            nombre_polynome=NouveauPolynome(poly_stockage[nombre_polynome],nombre_polynome);
                            poly_stockage[nombre_polynome-1]=NULL;
                            Addition(poly_stockage[choix1],poly_stockage[choix2],&poly_stockage[nombre_polynome-1]);
                        }
                        else if(selection == 2)///soustraction
                        {
                            choix1 = selectionPolynome(nombre_polynome);
                            choix2 = selectionPolynome(nombre_polynome);
                            nombre_polynome=NouveauPolynome(poly_stockage[nombre_polynome],nombre_polynome);
                            poly_stockage[nombre_polynome-1]=NULL;
                            Soustraction(poly_stockage[choix1],poly_stockage[choix2],&poly_stockage[nombre_polynome-1]);
                        }
                        else if(selection == 3)///multiplication
                        {
                            choix1 = selectionPolynome(nombre_polynome);
                            choix2 = selectionPolynome(nombre_polynome);
                            nombre_polynome=NouveauPolynome(poly_stockage[nombre_polynome],nombre_polynome);
                            poly_stockage[nombre_polynome-1]=NULL;
                            poly_stockage[nombre_polynome-1] = Multiplication(poly_stockage[choix1],poly_stockage[choix2],&poly_stockage[nombre_polynome-1]);
                        }
                        else if(selection == 4)///division
                        {
                            gotoxy(20,24);
                            printf("En construction");
                            Sleep(1000);
                        }
                    }
                    while(selection != 5);///sortir
                    selection = 0;
                }
                if (saisie == 2)
                {
                    do
                    {
                        system("cls");
                        TeteMenu();
                        gotoxy(1,7);
                        printf("  - 1 - Derivee \n\n");
                        printf("  - 2 - Integration \n\n");
                        printf("  - 3 - PGCD \n\n");
                        printf("  - 4 - Composition \n\n");
                        printf("  - 5 - Decomposition \n\n");
                        printf("  - 6 - Racines du polynome \n\n");
                        printf("  - 7 - Retour \n\n");
                        AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
                        selection = SaisieSecure(1,7);
                        if(selection == 1)///d�river
                        {
                            choix1 = selectionPolynome(nombre_polynome);
                            DeriverPolynome(poly_stockage[choix1]);
                        }
                        else if(selection == 2)///int�grer
                        {
                            choix1 = selectionPolynome(nombre_polynome);
                            IntegrationPolynome(poly_stockage[choix1]);
                            Sleep(1000);
                        }
                        else if(selection == 3)///PGCD
                        {
                            gotoxy(20,24);
                            printf("En construction");
                            Sleep(1000);
                        }
                        else if(selection == 4)///Composition
                        {
                            gotoxy(20,24);
                            printf("En construction");
                            Sleep(1000);
                        }
                        else if(selection == 5)///D�composition
                        {
                            gotoxy(20,24);
                            printf("En construction");
                            Sleep(1000);
                        }
                        else if(selection == 6)///racine
                        {
                            gotoxy(20,24);
                            printf("En construction");
                            Sleep(1000);
                        }
                    }
                    while(selection != 7);///sortir
                    selection = 0;
                }
            }
            while(saisie != 3);///sortir
            reponse = 0;
            saisie = 0;
        }
        else if(reponse == 4)
        {
            do
            {
                system("cls");
                TeteMenu();
                gotoxy(1,7);
                printf("  - 1 - Comparaison de deux polynomes \n\n");
                printf("  - 2 - Extraction des parties imaginaire et reel \n\n");
                printf("  - 3 - conjugue du polynome \n\n");
                printf("  - 4 - Retour \n\n");
                AfficherTTpolynomeDVP(poly_stockage,nombre_polynome);
                saisie = SaisieSecure(1,4);

                if(saisie == 1)///comparaison
                {
                    choix1 = selectionPolynome(nombre_polynome);
                    choix2 = selectionPolynome(nombre_polynome);
                    ComparaisonDeuxPolynomes(poly_stockage[choix1],poly_stockage[choix2]);
                }
                else if(saisie == 2)///extraction parti imaginaire/partie reel
                {
                    choix1 = selectionPolynome(nombre_polynome);
                    extractionPartieReelleEtImaginaire(poly_stockage[choix1]);
                }
                else if(saisie == 3)///conjugu�
                {
                    gotoxy(20,24);
                    nombre_polynome=NouveauPolynome(poly_stockage[nombre_polynome],nombre_polynome);
                    choix1 = selectionPolynome(nombre_polynome);
                    ConjuguePolynome(&polynome,poly_stockage[choix1]);
                    poly_stockage[nombre_polynome-1]=polynome;
                    AffichagePolynomeDvp(poly_stockage[nombre_polynome-1],1);
                }
            }
            while(saisie != 4);///sortir
            reponse = 0;
            saisie = 0;
        }
        else if(reponse == 5 && nombre_polynome > 0)///Evaluation en un point
        {
            result.reel = 0;
            result.imaginaire = 0;
            choix1 = selectionPolynome(nombre_polynome);
            printf("Point a evaluer: ");
            scanf("%lf",&point_eval);
            Evaluation(&result,poly_stockage[choix1],point_eval);
            Sleep(3000);
        }
        else if(reponse == 6)
        {
            gotoxy(20,24);
            printf("En construction");
            Sleep(1000);
        }
    }
    while(reponse != 7);///sortir
}

int SaisieSecure(int mini, int maxi)
{
    int saisie = 0;
    do
    {
        fflush(stdin);//on vide la m�moire tampon au cas ou la valeur entr� a �t� un caract�re
        scanf("%d",&saisie);
        if(saisie < mini && saisie > maxi)
        {
            system("clear");
            printf("ERREUR DE SAISIE\nNOUVELLE SAISIE: ");
        }
    }
    while(saisie < mini && saisie > maxi);
    return saisie;
}

void AfficherTTpolynomeDVP(monome** poly_stockage,int nombre_polynome)
{
    int cpt;

    for(cpt = 0 ; cpt < nombre_polynome ; cpt++)//pour de 0 au dernier polynome qui existe
    {
        gotoxy(51,7+cpt);
        printf("(%d) ",cpt+1);
        AffichagePolynomeDvp(poly_stockage[cpt],1);
    }
    gotoxy(20,24);
}

int selectionPolynome(int nombre_polynome)
{
    int choix;
    do
    {
        printf("Choix de polynome: ");
        choix = SaisieSecure(1,nombre_polynome-1) - 1;// on prend la valeur -1 car le polynome 1 est stock� en poly_stockage[0]
    }
    while(choix > nombre_polynome-1 || choix < 0);
    return choix;//on retourne le choix
}

void Composition1(monome * resultat, monome * poly_developpe, monome * compose)
{
    monome * constant ;
    constant = (monome*)malloc(sizeof(monome)) ;
    constant -> suivant = NULL ;
    constant->coef.reel = constant->coef.imaginaire = 0 ;
    constant->puissance = 0 ;

    if((compose==NULL)||(poly_developpe=NULL))//si le polynome est nul, on sort
    {
        return ;
    }

    int nb = 0;
    monome ** tmp = NULL ;

    Multiplication(resultat,compose,&tmp);
    resultat = *tmp ;
    *tmp = NULL ;

    constant->coef = poly_developpe->coef ;
    Addition(resultat,constant,&tmp);
    resultat = *tmp ;
    *tmp = NULL ;


    if (poly_developpe->suivant != NULL)
    {
        nb = poly_developpe->puissance - poly_developpe->suivant->puissance;
        while(nb>1)
        {
            Multiplication(resultat,compose,&tmp);
            resultat = *tmp ;
            *tmp = NULL ;
            nb = nb - 1;
        }


        Composition1(resultat,poly_developpe->suivant, compose);

    }
    else
    {
        printf("(%.0lf + %.0lfi)x^%d \n",(resultat)->coef.reel,(resultat)->coef.imaginaire,(resultat)->puissance);

    }

    free(constant);
}

void CreationMonomeAleatoire()
{
    long tablcoefreel[10]= {(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10)};
    long tablcoefimaginaire[10]= {(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10)};
    long tablcoefpuissance[10]= {(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10),(rand()%10)};
    monome * polynome5, *polynome6, *polynome7, *polynome8, *polynome9, *polynome10 ;

    polynome10 = (monome*)malloc(sizeof(monome));
    polynome9 = (monome*)malloc(sizeof(monome));
    polynome8 = (monome*)malloc(sizeof(monome));
    polynome7 = (monome*)malloc(sizeof(monome));
    polynome6 = (monome*)malloc(sizeof(monome));
    polynome5 =(monome*)malloc(sizeof(monome));

    polynome5->coef.reel = tablcoefreel[rand()%10];
    polynome5->coef.imaginaire= tablcoefimaginaire[rand()%10];
    polynome5->puissance = tablcoefpuissance[rand()%10];
    polynome5->suivant=NULL ;

    polynome6->coef.reel = tablcoefreel[rand()%10];
    polynome6->coef.imaginaire= tablcoefimaginaire[rand()%10];
    polynome6->puissance = tablcoefpuissance[rand()%10];
    polynome6->suivant=NULL ;

    polynome7->coef.reel = tablcoefreel[rand()%10];
    polynome7->coef.imaginaire= tablcoefimaginaire[rand()%10];
    polynome7->puissance = tablcoefpuissance[rand()%10];
    polynome7->suivant=NULL ;

    polynome8->coef.reel = tablcoefreel[rand()%10];
    polynome8->coef.imaginaire= tablcoefimaginaire[rand()%10];
    polynome8->puissance = tablcoefpuissance[rand()%10];
    polynome8->suivant=NULL ;

    polynome9->coef.reel = tablcoefreel[rand()%10];
    polynome9->coef.imaginaire= tablcoefimaginaire[rand()%10];
    polynome9->puissance = tablcoefpuissance[rand()%10];
    polynome9->suivant=NULL ;

    polynome10->coef.reel = tablcoefreel[rand()%10];
    polynome10->coef.imaginaire= tablcoefimaginaire[rand()%10];
    polynome10->puissance = tablcoefpuissance[rand()%10];
    polynome10->suivant=NULL ;


    AffichagePolynomeDvp(polynome10,1);
    AffichagePolynomeDvp(polynome9,1);
    AffichagePolynomeDvp(polynome8,1);
    AffichagePolynomeDvp(polynome7,1);
    AffichagePolynomeDvp(polynome6,1);
    AffichagePolynomeDvp(polynome5,1);

    return ;
}

int SupprimerPolynome(monome** poly_stockage,int nombre_polynome)
{
    int choix;
    int cpt;

    choix = selectionPolynome(nombre_polynome);

    for(cpt = choix ; cpt < nombre_polynome-1 ; cpt++)//on d�cale les valeurs vers le d�but a partir du polynome choisi
    {
        poly_stockage[cpt] = poly_stockage[cpt+1];
    }

    poly_stockage= realloc(poly_stockage, sizeof(monome*));//puis on lib�re la derni�re case
    nombre_polynome--;
    return nombre_polynome;

}

void extractionPartieReelleEtImaginaire( monome *polynome)
{

    if (polynome != NULL)
    {
        monome  * tmp;
        tmp->coef.reel = polynome->coef.reel;
        tmp->coef.imaginaire= polynome->coef.imaginaire;
        tmp->puissance = polynome->puissance;
        printf("%d \n",tmp->puissance);


        while (tmp!= NULL)
        {

            if ( tmp == polynome)
            {
                printf("( %0.lf x^%d ", tmp->coef.reel, tmp->puissance);
            }

            else if (tmp->coef.reel == 0)
            {

            }

            else if (tmp->coef.reel < 0)
            {

                printf("%0.lf X^%d ", tmp->coef.reel, tmp->puissance);
            }

            else
            {
                printf(" + %0.lf X^%d", tmp->coef.reel, tmp->puissance);
            }

            tmp = tmp->suivant;
        }

        printf(") + ");

        tmp = polynome;

        while (tmp != NULL)
        {

            if (tmp == polynome)
            {
                printf("i( %0.lf x^%d ", tmp->coef.imaginaire, tmp->puissance);
            }

            else if (tmp->coef.imaginaire == 0)
            {

            }

            else if (tmp->coef.imaginaire < 0)
            {

                printf("%lf x^%d ", tmp->coef.imaginaire, tmp->puissance);
            }

            else
            {
                printf(" + %lf x^%d ", tmp->coef.imaginaire, tmp->puissance);
            }

            tmp = tmp->suivant;
        }

        printf(")");
    }
}

void ComparaisonDeuxPolynomes(monome *polynome, monome*polynome2)
{

    monome * premier;
    premier = polynome;
    monome * deuxieme;
    deuxieme = polynome2;

    while ((premier->coef.reel == deuxieme->coef.reel) && (premier->coef.imaginaire == deuxieme->coef.imaginaire) && (premier->puissance == deuxieme->puissance) && (premier != NULL && deuxieme != NULL))
    {
        premier = premier->suivant;
        deuxieme = deuxieme->suivant;
        printf("Ce sont deux polynomes identiques\n");

    }

    if (premier == NULL && deuxieme == NULL)
    {
        printf("Ce sont deux polynomes identiques\n");
    }
    else printf("Ce n'est pas les memes polynomes \n");
}

void ConjuguePolynome(monome** poly_developpe, monome* polynome)
{
    monome* tmp;
    monome* m1;
    monome* temp;
    temp = polynome;//copie de polynome
    int i=1;
    do
    {
        if(i == 1)//on cr�er le premier monome
        {

            m1 = (monome*)malloc(sizeof(monome)); // allocation pour p qui aura comme type LSCcontact, et comme taille contact
            //on donne les valeurs des diff�rentes parties en fonction du polynome de r�f�rence
            m1->coef.reel = temp->coef.reel;
            m1->coef.imaginaire = -(temp->coef.imaginaire);//on le conjugue
            m1->puissance = temp->puissance;
            m1 -> suivant = NULL;

            (*poly_developpe)=m1;
            tmp = (*poly_developpe);
            i++;
            temp = temp->suivant;

        }
        else
        {
            m1 = (monome*)malloc(sizeof(monome)); // allocation pour p qui aura comme type LSCcontact, et comme taille contact
            //on donne les valeurs des diff�rentes parties en fonction du polynome de r�f�rence
            m1->coef.reel = temp->coef.reel;
            m1->coef.imaginaire = -(temp->coef.imaginaire);//on le conjugue
            m1->puissance = temp->puissance;
            m1 -> suivant = NULL;

            tmp->suivant = m1;
            tmp = tmp->suivant;
            temp = temp->suivant;

        }
    }
    while(temp!= NULL);//on continu tant que le polynome � des monomes pas encore conjugu�
}
