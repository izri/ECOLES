#ifndef PROJET_SDD_VERSIONX_H_INCLUDED
#define PROJET_SDD_VERSIONX_H_INCLUDED

// faire seulement dvp

typedef struct complexe
{
 double reel;
 double imaginaire;
}complexe;


typedef struct monome
{
    complexe coef;
    int puissance;
    struct monome *suivant;

} monome;

typedef struct t_polynomial
{
    monome *dvp;
    monome *fact;

} polynomial;

monome* CreationMonome();

void ConstruirePolynome(monome**);

void AffichagePolynomeDvp(monome*,int);
void TrierPolynome(monome **);
void InversionListe(monome **);
void AfficherTTpolynomeDVP(monome**,int);

int NouveauPolynome(monome*,int);

void Addition(monome*,monome*,monome**);
int Soustraction(monome*, monome*, monome**);
monome * Multiplication(monome*,monome*,monome**);

void IntegrationPolynome(monome *);
void DeriverPolynome(monome*);
void Evaluation(complexe *, monome *, double);
void Composition1(monome*,monome*,monome*);

monome *  MultiplicationPuissance(monome*,int);
monome * AjoutMonome (monome **, monome *);

void TeteMenu();
void Menu();
int SaisieSecure(int,int);
int selectionPolynome(int);
void CreationMonomeAleatoire(void);
int SupprimerPolynome(monome**,int);
void extractionPartieReelleEtImaginaire( monome *);
void ComparaisonDeuxPolynomes(monome *, monome*);
void ConjuguePolynome(monome** polynome, monome* conjugue);

#endif // PROJET_SDD_VERSIONX_H_INCLUDED
