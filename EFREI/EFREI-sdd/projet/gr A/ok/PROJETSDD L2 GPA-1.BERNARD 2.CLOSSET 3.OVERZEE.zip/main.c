#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "projet_sdd_versionX.h"

int main()
{

    system ("mode con cols=100 lines=100");
    srand(time(NULL));
    Menu();
    return 0;
}
