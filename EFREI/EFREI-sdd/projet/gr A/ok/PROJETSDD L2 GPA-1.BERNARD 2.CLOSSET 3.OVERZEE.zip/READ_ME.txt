PROJET C L2 C � BERNARD CLOSSET OVERZEE

Etat d'avancement:

1. polynome definie par deux structures chainees qui correspondent a ses
formes developpees et factorisee. Ces deux structures sont encapsulees dans une troisieme
qui donne le type polynomial --> Type polynomial cree avec forme developpe realise mais factorisation pas effectue.

2. Les deux composantes du coeficient complexe sont stockees --> realise. 

3. visualiser polynome --> realise.

4. Creation polynome aleatoire ou saisie utilisateur --> realise.


5. les operations d'addition, soustraction, multiplication, conjugaison, comparaison, extraction des
parties reelle et imaginaire de polynome --> realise.

6. Evaluation en un point methode ruffini horner --> realise


7.Derivation et integration	--> realise

8. Fonction de tri et inversion de la liste	--> realise	

9. ajout de monomes  -->   realise

10. Division et composition --> avec des erreurs pas fonctionnel. 

11. Recherche de racine pour pourvoir effectuer la factorisation --> non realiser mais en etat de reflexion avec la methode de bairsto.


webographie

1. wikipedia



