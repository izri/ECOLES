//
//  polynome.c
//  Projet_SDD_Polynomes
//
//  Created by Edouard Soares on 14/10/14.
//  Copyright (c) 2014 Edouard Soares. All rights reserved.
//

#include <stdio.h>
#include "polynome.h"
#include <stdlib.h>


void menu()
{
    Polynome *monPolynome = initialisation();
    Polynome *monPolynome2 = initialisation();
    while (1)
    {
        system("cls");
        printf("\* Calculatrice pour polynomes */\n");
        printf("\n 1) \tGenerer 2 polynomes aleatoires");
        printf("\n 2) \tRemplir 2 polynomes soit-meme");
        printf("\n 3) \tAdditionner les polynomes");
        printf("\n 4) \tSoustraire les polynomes");
        printf("\n 5) \tMultiplier les polynomes");
        printf("\n 6) \tDiviser les polynomes");
        printf("\n 7) \tDeriver les polynomes");
        printf("\n 8) \tPrimitive des polynomes");
        printf("\n 9) \tReinitialiser les polynomes");
        printf("\n 10)\tConjugue de chaque polynome");
        printf("\n 11)\tComparaison des polynomes");
        printf("\n 12)\tExtraction parties reelle et imaginaire pour chaque polynome");
        if (monPolynome->premier!=NULL && monPolynome2->premier!=NULL)
        {
            printf("\n\nLe premier polynome vaut :");
            afficherPolynome(monPolynome);
            printf("Le second polynome vaut :");
            afficherPolynome(monPolynome2);
        }
        int choix=0;
        while (choix<1 || choix>12)
        {
            printf("\n\nChoisissez une option :");
            scanf("%d",&choix);
        }

        if (choix==1)
        {
            srand(time(NULL));
            const int N = 3;
            int puissance[N];
            Complexe nombre[N];
            int i;
            for (i = 0; i < N ; i++) {
                puissance[i] = (rand() % (8 - 0 + 1)) + 0;

            }

            for (i = 0; i < N; i++) {
                nombre[i].reel = (rand() % (15 - (-15) + 1)) + (-15);
                nombre[i].imaginaire = (rand() % (15 - (-15) + 1)) + (-15);
            }

            for (i = 0; i < N; i++) {
                insertion(&monPolynome, puissance[i], nombre[i]);
            }

            // 2ème polynome

            for (i = 0; i < N ; i++) {
                puissance[i] = (rand() % (4 - 0 + 1)) + 0;

            }

            for (i = 0; i < N; i++) {
                nombre[i].reel = (rand() % (15 - (0) + 1)) + (0);
                nombre[i].imaginaire = (rand() % (15 - (0) + 1)) + (0);
            }


            for (i = 0; i < N; i++) {
                insertion(&monPolynome2, puissance[i], nombre[i]);
            }
        }

        if (choix==2)
        {
            char continuer='o';
            int puissance;
            Complexe nombre;
            system("cls");
            printf("Remplissage du premier polynome\n");
            while (continuer=='o')  // 1er polynome
            {
                printf("\nEntrez une puissance : ");
                scanf("%d",&puissance);
                printf("\nNombre complexe associe a la puissance x^%d",puissance);
                printf("\n\t\t\tEntrez sa partie reelle : ");
                scanf("%lf",&nombre.reel);
                printf("\t\t\tEntrez sa partie imaginaire : ");
                scanf("%lf",&nombre.imaginaire);
                insertion(&monPolynome,puissance,nombre);
                printf("\nVoulez-vous ajouter d'autres valeurs ? (o/n) ");
                scanf("%s",&continuer);
                printf("\n\n");
            }
            continuer='o';
            system("cls");
            printf("Remplissage du second polynome\n");
            while (continuer=='o')  // 1er polynome
            {
                printf("\nEntrez une puissance : ");
                scanf("%d",&puissance);
                printf("\nNombre complexe associe a la puissance x^%d",puissance);
                printf("\n\t\t\tEntrez sa partie reelle : ");
                scanf("%lf",&nombre.reel);
                printf("\t\t\tEntrez sa partie imaginaire : ");
                scanf("%lf",&nombre.imaginaire);
                insertion(&monPolynome2,puissance,nombre);
                printf("\nVoulez-vous ajouter d'autres valeurs ? (o/n) ");
                scanf("%s",&continuer);
                printf("\n\n");
            }
        }
        if (choix==3)
        {
            Polynome *temp=initialisation();
            additionPolynome(temp,monPolynome);
            additionPolynome(temp,monPolynome2);
            system("cls");
            printf("L'addition des deux polynomes vaut : ");
            afficherPolynome(temp);
            system("pause");
        }
        if (choix==4)
        {
            Polynome *temp=initialisation();
            additionPolynome(temp,monPolynome);
            soustractionPolynome(&temp,monPolynome2);
            system("cls");
            printf("La soustraction des deux polynomes vaut : ");
            afficherPolynome(temp);
            system("pause");
        }
        if (choix==5)
        {
            system("cls");
            printf("Le produit des deux polynomes vaut :\n\n");
            afficherPolynome(multiplicationPolynome(monPolynome,monPolynome2));
            system("pause");
        }
        if (choix==6)
        {
            system("cls");
            Polynome *reste=initialisation();
            reste=divisionPolynome(monPolynome,monPolynome2);
            if (reste!=NULL)
            {
                printf("et le reste est :");
                afficherPolynome(reste);
                system("pause");
            }
        }
        if (choix==7)
        {
            Polynome *temp=initialisation();
            additionPolynome(temp,monPolynome);
            derivationPolynome(temp);
            system("cls");
            printf("La derivee du premier polynome est : ");
            afficherPolynome(temp);

            temp=initialisation();
            additionPolynome(temp,monPolynome2);
            derivationPolynome(temp);
            printf("La derivee du second polynome est : ");
            afficherPolynome(temp);
            system("pause");
        }
        if (choix==8)
        {
            Polynome *temp=initialisation();
            additionPolynome(temp,monPolynome);
            primitivePolynome(temp);
            system("cls");
            printf("La primitive du premier polynome est : ");
            afficherPolynome(temp);

            temp=initialisation();
            additionPolynome(temp,monPolynome2);
            primitivePolynome(temp);
            printf("La primitive du second polynome est : ");
            afficherPolynome(temp);
            system("pause");
        }
        if (choix==9)
        {
            monPolynome=initialisation();
            monPolynome2=initialisation();
        }
        if (choix==10)
        {
            Polynome *temp=initialisation();
            additionPolynome(temp,monPolynome);
            conjuguePolynome(temp);
            system("cls");
            printf("Le conjugue du premier polynome est : ");
            afficherPolynome(temp);

            temp=initialisation();
            additionPolynome(temp,monPolynome2);
            conjuguePolynome(temp);
            printf("Le conjugue du second polynome est : ");
            afficherPolynome(temp);
            system("pause");
        }
        if (choix==11)
        {
            system("cls");
            comparaisonPolynome(monPolynome,monPolynome2);
            system("pause");
        }

        if (choix==12)
        {
            system("cls");
            printf("L'extraction du premier polynome est :\n");
            extractionPartieReelleEtImaginaire(monPolynome);
            printf("\n\nL'extraction du second polynome est :\n");
            extractionPartieReelleEtImaginaire(monPolynome2);
            printf("\n");
            system("pause");
        }
    }
}




Polynome *initialisation(){

    Polynome *polynome = malloc(sizeof(*polynome));

    polynome->premier = NULL;
    polynome->dernier = NULL;
    polynome->taille = 0;



    return polynome;
}


void insertion(Polynome **polynome, int puissance, Complexe nombre){

        /* Création du nouveau monome */
        Polynome *p = *polynome;
        if (nombre.imaginaire != 0 || nombre.reel !=0) {

            Monome *nouveau = malloc(sizeof(*nouveau));
            Monome *compteur = p->premier;
            Monome *dernier = p->dernier;

            //Attribution des puissances et de l'indice au nouveau monome
            nouveau->puissance = puissance;
            nouveau->nombre.imaginaire = nombre.imaginaire;
            nouveau->nombre.reel = nombre.reel;

            if (compteur == NULL) {

                nouveau->suivant = NULL;
                p->premier = nouveau;
                p->dernier = nouveau;
                p->taille ++;
            }

            else {

                if (nouveau->puissance > compteur->puissance) { // Si la puissance du nouveau est supérieure au premier monome, on l'ajoute devant.

                    nouveau->suivant = p->premier;
                    p->premier = nouveau;
                    p->taille ++;
                }

                else if (nouveau->puissance < dernier->puissance){

                    nouveau->suivant = NULL;
                    dernier->suivant = nouveau;
                    p->dernier = nouveau;
                    p->taille ++;
                }

                else if (nouveau->puissance < compteur->puissance ){  // Si la puissance est inférieure au premier monome de la liste

                    while (nouveau->puissance < compteur->puissance && compteur->suivant != NULL && compteur->suivant->puissance > nouveau->puissance ) { // alors on va jusqu'au monome qui a une puissance inférieure au nouveau monome tant que compteur suivant n'est pas plus petit que le nouveau monome

                        compteur = compteur->suivant;
                    }



                    if  (compteur->suivant == NULL){

                        nouveau->suivant = NULL;
                        compteur->suivant = nouveau;
                    }

                    else if (nouveau->puissance == compteur->suivant->puissance) { // Si les puissances sont égales, on ajoute les indices des monomes.

                        compteur->suivant->nombre = additionComplexe(compteur->suivant->nombre, nouveau->nombre);

                        if ( (compteur->suivant->nombre.reel == 0 && compteur->suivant->nombre.imaginaire == 0 ) || (compteur->suivant->nombre.reel <= 0.E-5 && compteur->suivant->nombre.imaginaire <= 0.E-5) ) {

                            Monome *poubelle = compteur->suivant;
                            compteur->suivant = compteur->suivant->suivant;
                            free(poubelle);
                        }
                        free(nouveau);
                    }

                    else {

                        // On ajoute le nouveau monome devant le suivant.
                        nouveau->suivant = compteur->suivant;
                        compteur->suivant = nouveau;
                        p->taille ++;
                    }

                }

                else if (nouveau->puissance == compteur->puissance) { // Si les puissances sont égales, on ajoute les indices des monomes.

                    compteur->nombre = additionComplexe(compteur->nombre, nouveau->nombre);

                    if ( (compteur->nombre.imaginaire == 0 && compteur->nombre.reel == 0 ) || (compteur->nombre.imaginaire <= 0.E-5 && compteur->nombre.reel <= 0.E-5) ) {

                        p->premier = p->premier->suivant;
                        free(compteur);
                    }

                    free(nouveau);
                }

            }




        }
}





void additionPolynome(Polynome *polynome, Polynome *polynome2) {

    Monome *actuel = polynome2->premier;

    while (actuel != NULL) { // On va insérer les monomes de la liste 2 dans la liste 1.

        insertion(&polynome, actuel->puissance, actuel->nombre);
        actuel = actuel->suivant;
    }

}






void soustractionPolynome(Polynome **polynome, Polynome *polynome2) {

    Monome *actuel = polynome2->premier;

    while (actuel != NULL) { // On va insérer les monomes de la liste 2 dans la liste 1.
        actuel->nombre.imaginaire *= -1;
        actuel->nombre.reel *= -1;
        insertion(polynome, actuel->puissance, actuel->nombre);
        actuel = actuel->suivant;
    }
}




Polynome *multiplicationPolynome(Polynome *polynome, Polynome *polynome2) {

    Monome *actuel1 = polynome->premier;
    Monome *actuel2 = polynome2->premier;

    Complexe nombre;
    int puissance;

    Polynome *nouveau = initialisation();

    while (actuel1 != NULL) { // On parcourt le premier polynome et on le multiplie avec tous les monomes du second polynome. On réitère tant que le premier polynome n'est pas null

        while (actuel2 != NULL) {

            nombre = multiplicationComplexe(actuel1->nombre, actuel2->nombre);

            puissance = actuel2->puissance + actuel1->puissance;

            insertion(&nouveau, puissance, nombre); // On insère le produit des monomes dans un nouveau polynome

            actuel2 = actuel2->suivant;
        }

        actuel2 = polynome2->premier;
        actuel1 = actuel1->suivant;
    }
    return nouveau; // On retourne un nouveau polynome qui est le produit des deux polynomes
}







Polynome *divisionPolynome(Polynome *polynome, Polynome *polynome2) {

    Monome *dividende = polynome->premier;
    Monome *diviseur = polynome2->premier;

    Polynome *quotient = initialisation();
    Polynome *reste = NULL;

    int puissance, puissance2;
    Complexe nombre, nombre2;

    if (diviseur ==  NULL) { // Si le diviseur est nul on ne peut pas diviser (division par 0)

        printf("impossible de diviser par 0 !!");
        return reste;
    }

    else if (diviseur->puissance > dividende->puissance) { // si le diviseur est plus grand que le dividende on ne peut pas faire de division euclidienne

        printf(" Pas de division possible car le diviseur est supérieur au dividende");
        return reste;
    }

    else {

        while (dividende != NULL && diviseur->puissance <= dividende->puissance) { // Tant que le monome de plus haut degré est sur le dividende on continue à diviser

            Polynome *reste   = NULL;
            reste=initialisation();


            puissance = dividende->puissance - diviseur->puissance;
            nombre = divisionComplexe(dividende->nombre, diviseur->nombre);

            insertion(&quotient, puissance, nombre); // On insère le quotient dans le polynome quotient


            while (diviseur != NULL) {

                puissance2 = puissance + diviseur->puissance;
                nombre2 = multiplicationComplexe(nombre, diviseur->nombre);

                insertion(&reste, puissance2, nombre2);  // On multiplie le diviseur par le quotient du moment et on insère le résultat dans le polynome reste

                diviseur = diviseur->suivant;
            }

            diviseur = polynome2->premier;

            soustractionPolynome(&polynome, reste);// On soustrait le dividende au reste que l'on vient de touver

            dividende = polynome->premier;
            free(reste);  // On libère reste car on va la réinitialiser pour la prochaine division
        }

        printf("Le quotient est   :  ");
        afficherPolynome(quotient);  // On affiche le quotient

        return polynome;  // et on renvoie le reste
    }
}




void derivationPolynome(Polynome *polynome) {

    Monome *provisoire = polynome->premier;

    while (provisoire != NULL) {  // Tant qu'on a pas parcouru tous les monomes

        provisoire->nombre.imaginaire *= provisoire->puissance;  // On multiplie le coefficient du monome par sa puissance
        provisoire->nombre.reel *= provisoire->puissance;
        provisoire->puissance --; // On baisse sa puissance de 1

        if ( provisoire->suivant != NULL && provisoire->suivant->puissance == 0) { // Si le dernier monome est de puissance 0, On libère le dernier monome

            Monome *trash = provisoire->suivant;
            provisoire->suivant = NULL;
            free(trash);

        }

        provisoire = provisoire->suivant;
    }
}






void primitivePolynome(Polynome *polynome) {

    Monome *provisoire = polynome->premier;

    while (provisoire != NULL) {  // Tant qu'on a pas parcouru tous les monomes

        provisoire->puissance ++; // On augmente sa puissance de 1
        provisoire->nombre.imaginaire /= provisoire->puissance;  // On divise le coefficient du monome par sa puissance + 1
        provisoire->nombre.reel /= provisoire->puissance;




        provisoire = provisoire->suivant;
    }
}




void conjuguePolynome(Polynome *polynome) {

    Monome *conjugue = polynome->premier;

    while (conjugue != NULL) {

        conjugue->nombre.imaginaire *= -1;  // On multiplie par -1 la partie imaginaire de chaque monome
        conjugue = conjugue->suivant;
    }
}



void comparaisonPolynome(Polynome *polynome, Polynome *polynome2) {

    if (polynome->premier!=NULL && polynome2->premier!=NULL)
    {
        Monome *a = polynome->premier;
        Monome *b = polynome2->premier;

        while (a != NULL && b!= NULL && a->nombre.reel == b-> nombre.reel && a->nombre.imaginaire == b->nombre.imaginaire && a->puissance == b->puissance) { // On vérifie que les polynomes sont égaux partout
            a = a->suivant;
            b = b->suivant;
        }

        if (a == NULL && b == NULL) {
            printf("Les deux polynomes sont egaux !\n");
        }
        else printf("Les deux polynomes ne sont pas egaux !\n");
    }

}






void afficherPolynome(Polynome *polynome)
{
    if (polynome != NULL) {

        Monome *actuel = polynome->premier;

        while (actuel != NULL)
        {
            if (actuel->nombre.imaginaire < 0) {

                if (actuel->nombre.reel == 0) {

                    printf(" (%.2lf i )", actuel->nombre.imaginaire);

                }
                else {
                    printf(" (%.2lf %.2lf i)", actuel->nombre.reel, actuel->nombre.imaginaire);
                }


            }

            else if (actuel->nombre.imaginaire == 0) {

                printf(" (%.2lf )", actuel->nombre.reel);

            }

            else {

                if (actuel->nombre.reel == 0) {

                    printf(" (%.2lf i )", actuel->nombre.imaginaire);

                }
                else {
                    printf(" (%.2lf + %.2lf i)", actuel->nombre.reel, actuel->nombre.imaginaire);
                }

            }

            printf("X^");

            if (actuel->suivant == NULL) {

                printf("%d\n", actuel->puissance);
            }

            else {
                printf("%d + ", actuel->puissance);
            }
            actuel = actuel->suivant;
        }

    }


}







void extractionPartieReelleEtImaginaire( Polynome *polynome) {

    if (polynome != NULL) {

        Monome *actuel = polynome->premier;


        while (actuel != NULL) {

            if (actuel == polynome->premier) {
                printf("( %.2lf X^%d ", actuel->nombre.reel, actuel->puissance);
            }

            else if (actuel->nombre.reel == 0) {

            }

            else if (actuel->nombre.reel < 0) {

                printf("%.2lf X^%d ", actuel->nombre.reel, actuel->puissance);
            }

            else {
                printf(" + %.2lf X^%d", actuel->nombre.reel, actuel->puissance);
            }

            actuel = actuel->suivant;
        }

        printf(") + ");

        actuel = polynome->premier;

        while (actuel != NULL) {

            if (actuel == polynome->premier) {
                printf("i ( %.2lf X^%d ", actuel->nombre.imaginaire, actuel->puissance);
            }

            else if (actuel->nombre.imaginaire == 0) {

            }

            else if (actuel->nombre.imaginaire < 0) {

                printf("%.2lf X^%d ", actuel->nombre.imaginaire, actuel->puissance);
            }

            else {
                printf(" + %.2lf X^%d ", actuel->nombre.imaginaire, actuel->puissance);
            }

            actuel = actuel->suivant;
        }

        printf(")");
    }
}












Complexe additionComplexe(Complexe c1, Complexe c2) {

    Complexe nombre;

    nombre.reel = c1.reel + c2.reel;
    nombre.imaginaire = c1.imaginaire +c2.imaginaire;

    return nombre;
}



Complexe multiplicationComplexe(Complexe c1, Complexe c2) {

    Complexe nombre;

    nombre.reel = (c1.reel * c2.reel) - (c1.imaginaire * c2.imaginaire);
    nombre.imaginaire = (c1.reel * c2.imaginaire) + (c1.imaginaire * c2.reel);

    return nombre;
}



Complexe divisionComplexe(Complexe c1, Complexe c2) {

    Complexe nombre;

    nombre.reel = ( (c1.reel * c2.reel) + (c1.imaginaire * c2.imaginaire) ) / ( (c2.reel * c2.reel) + (c2.imaginaire * c2.imaginaire) );
    nombre.imaginaire = ( (c1.imaginaire * c2.reel) - (c1.reel * c2.imaginaire) ) / ( (c2.reel * c2.reel) + (c2.imaginaire * c2.imaginaire) );

    return nombre;
}



