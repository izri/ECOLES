//
//  main.c
//  Projet_SDD_Polynomes
//
//  Created by Edouard Soares on 14/10/14.
//  Copyright (c) 2014 Edouard Soares. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "polynome.h"
#include <time.h>

int main(int argc, const char * argv[])
{
    menu();
    return 0;
}

