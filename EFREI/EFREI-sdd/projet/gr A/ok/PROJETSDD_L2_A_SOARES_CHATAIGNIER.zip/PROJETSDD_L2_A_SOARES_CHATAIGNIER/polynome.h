//
//  polynome.h
//  Projet_SDD_Polynomes
//
//  Created by Edouard Soares on 14/10/14.
//  Copyright (c) 2014 Edouard Soares. All rights reserved.
//

#ifndef Projet_SDD_Polynomes_polynome_h
#define Projet_SDD_Polynomes_polynome_h

typedef struct Monome Monome;
typedef struct Polynome Polynome;
typedef struct Complexe Complexe;

struct Complexe{
    double reel, imaginaire;
};

struct Monome{
    Complexe nombre;
    int puissance;
    Monome *suivant;
};

struct Polynome{
    Monome *premier, *dernier;
    int taille;
};



void menu();

Polynome *initialisation();

void insertion(Polynome **polynome, int puissance, Complexe nombre);
void afficherPolynome(Polynome *polynome);
void additionPolynome(Polynome *polynome, Polynome *polynome2);
void soustractionPolynome(Polynome **polynome, Polynome *polynome2);
void derivationPolynome(Polynome *polynome);
void primitivePolynome(Polynome *polynome);
void conjuguePolynome(Polynome *polynome);
void comparaisonPolynome(Polynome *polynome, Polynome *polynome2);
void extractionPartieReelleEtImaginaire( Polynome *polynome);

Polynome *multiplicationPolynome(Polynome *polynome, Polynome *polynome2);
Polynome *divisionPolynome(Polynome *polynome, Polynome *polynome2);

Complexe additionComplexe(Complexe c1, Complexe c2);
Complexe multiplicationComplexe(Complexe c1, Complexe c2);
Complexe divisionComplexe(Complexe c1, Complexe c2);


#endif
