Avanc�e :

A la premi�re soutenance :
- cr�ation des structures et des listes chain�es du polynome 1 et 2

Pendant les vacances : 
- Affichage des polynomes
- Algorithmes (qui se sont av�r�s faux) pour l'addition et la soustraction

A la rentr�e :
- rien jusqu'au 21 Novembre
- 22/11 : Addition + Soustraction
- du 23/11 au 28/11 : Multiplication
- 29/11 : d�rivation + int�gration + comparaison en un point + essayer la division
- 30/11 : rapport �crit