#include <stdio.h>
#include <stdlib.h>


typedef struct polynome
{
    int coef;
    int degre;
    struct polynome* suivant;
} polynome;



typedef struct polynome* LSpoly;

LSpoly creationcoef(cpt) //cr�er un polynome
{
    LSpoly p;
    p=(LSpoly)malloc(sizeof(polynome));
    p->degre=cpt;
    printf ("Saisir coefficient de degre %d : \n", p->degre);
    scanf("%d", & p->coef);

    p->suivant=NULL;

return p;
}

LSpoly creationcase(cpt) //cr�er un polynome
{
    LSpoly p;
    p=(LSpoly)malloc(sizeof(polynome));
    p->degre=cpt;
    p->coef=0;


    p->suivant=NULL;

return p;
}




LSpoly premierELT(LSpoly *poly1,int cpt) //cr�er la premiere cellule, t�te de liste
{
    LSpoly l;
    l=creationcoef(cpt);
    *poly1=l;

return l;

}

LSpoly premierELT_r(LSpoly *polyresultat,int cpt) //cr�er la premiere cellule, t�te de liste
{
    LSpoly l;
    l=creationcase(cpt);
    *polyresultat=l;

return l;

}



void constructpoly(LSpoly *poly1, int n) //cr�ation du polynome
{
    LSpoly p,l;
    int i,cpt;
    cpt=n;

    p=premierELT(poly1, cpt);
    cpt=cpt-1;

    for(i=1; i<n+1; i++)

        {
            l=creationcoef(cpt);
            p -> suivant=l;
            p=l;
            cpt=cpt-1;
        }
    p->suivant=NULL;
}

void constructpoly_vide(LSpoly *poly1, int n3) //cr�ation du polynome vide
{
    LSpoly p,l;
    int i,cpt;
    cpt=n3;

    p=premierELT_r(poly1, cpt);
    cpt=cpt-1;

    for(i=1; i<n3+1; i++)

        {
            l=creationcase(cpt);
            p -> suivant=l;
            p=l;
            cpt=cpt-1;
        }

    p->suivant=NULL;
}



void Afficher(LSpoly poly1)
{

polynome* p=poly1;
if (p == NULL) printf(" Vide \n");
else

printf("\n \n le Polynome s'ecrit :");

while(p != NULL)
{

    if (p->coef==0)
    {
            p=p->suivant;
    }

    else
    {

            printf("%d", p->coef);
            printf("x^%d + ", p->degre);

            p = p->suivant;
    }

}

printf ("\n \n");
}


void Addition(LSpoly poly1,LSpoly poly2, LSpoly polyresultat_add)
{

polynome* p1=poly1;
polynome* p2=poly2;

while (p1->degre > p2->degre)
{
    polyresultat_add->coef=p1->coef;
    polyresultat_add=polyresultat_add->suivant;
    p1=p1->suivant;
}

while (p2->degre > p1->degre)
{
    polyresultat_add->coef=p2->coef;
    polyresultat_add=polyresultat_add->suivant;
    p2=p2->suivant;

}

while (polyresultat_add != NULL)
{
    polyresultat_add->coef= p1->coef + p2-> coef;
    polyresultat_add=polyresultat_add->suivant;
    p1=p1->suivant;
    p2=p2->suivant;
}


}

void Soustraction(LSpoly poly1,LSpoly poly2, LSpoly polyresultat_add)
{

polynome* p1=poly1;
polynome* p2=poly2;

while (p1->degre > p2->degre)
{
    polyresultat_add->coef=p1->coef;
    polyresultat_add=polyresultat_add->suivant;
    p1=p1->suivant;
}

while (p2->degre > p1->degre)
{
    polyresultat_add->coef= - p2->coef;
    polyresultat_add=polyresultat_add->suivant;
    p2=p2->suivant;

}

while (polyresultat_add != NULL)
{
    polyresultat_add->coef= p1->coef - p2-> coef;
    polyresultat_add=polyresultat_add->suivant;
    p1=p1->suivant;
    p2=p2->suivant;
}


}

void Soustraction2(LSpoly poly1,LSpoly poly2, LSpoly polyresultat_add)
{

polynome* p1=poly1;
polynome* p2=poly2;

while (p1->degre > p2->degre)
{
    polyresultat_add->coef= - p1->coef;
    polyresultat_add=polyresultat_add->suivant;
    p1=p1->suivant;
}

while (p2->degre > p1->degre)
{
    polyresultat_add->coef=p2->coef;
    polyresultat_add=polyresultat_add->suivant;
    p2=p2->suivant;

}

while (polyresultat_add != NULL)
{
    polyresultat_add->coef= p2->coef - p1-> coef;
    polyresultat_add=polyresultat_add->suivant;
    p1=p1->suivant;
    p2=p2->suivant;
}


}

void Multiplication(LSpoly poly1,LSpoly poly2, LSpoly polyresultat_multi)
{

int degre_t, coef_t;
polynome* p1=poly1;
polynome* p2=poly2;
polynome* temp=polyresultat_multi;
polynome* temp2=poly2;

while (p1 != NULL)
{

    p2=temp2;

    while (p2 != NULL)
    {
        polyresultat_multi=temp;

        coef_t=p1->coef * p2->coef;
        degre_t=p1->degre+p2->degre;

        while (polyresultat_multi != NULL)
        {

            if (degre_t==polyresultat_multi->degre)
            {
                polyresultat_multi->coef=polyresultat_multi->coef + coef_t;
                printf ("le nombre est %d au degre %d\n", coef_t, degre_t);
            }

            polyresultat_multi=polyresultat_multi->suivant;

        }

        p2=p2->suivant;

}

    p1=p1->suivant;
}

}

void Derivation(LSpoly poly1, LSpoly polyderive1)
{
    polynome* p1=poly1;

    while (polyderive1 != NULL)
    {
        polyderive1->coef=p1->coef * p1->degre;
        polyderive1->degre=p1->degre-1;

        polyderive1=polyderive1->suivant;
        p1=p1->suivant;
    }
}

void Integration(LSpoly poly1, LSpoly polyintegre1)
{
    polynome* p1=poly1;

    while (polyintegre1 != NULL)
    {
        polyintegre1->coef=p1->coef/p1->degre;
        polyintegre1->degre=p1->degre+1;

        polyintegre1=polyintegre1->suivant;
        p1=p1->suivant;
    }
}

void Comparaison (LSpoly polyresultat_add,LSpoly polyresultat_comp)
{
    polynome* p=polyresultat_add;
    int point;
    int i;
    int temp=0;

    printf ("saisir le point pour la comparaison \n");
    scanf ("%d", &point);

    while (p != NULL)
    {
        polyresultat_comp->coef=p->coef;

        for(i=0;i<polyresultat_comp->degre+2 ;i++)
        {
            polyresultat_comp->coef=polyresultat_comp->coef*point;
        }

        temp = temp + polyresultat_comp->coef;


        polyresultat_comp=polyresultat_comp->suivant;
        p=p->suivant;
    }

    printf ("le r�sultat est : %d donc : \n", temp);

    if (temp<0)
        {
            printf ("Le polynome 2 est plus grand que le polynome 1 en %d\n\n", point);
        }

    else if (temp>0)
        {
            printf ("Le polynome 1 est plus grand que le polynome 2 en %d\n\n", point);
        }
    else if (temp==0)
        {
            printf ("Les polynomes sont egaux en %d\n\n", point);
        }
}


