#include <stdio.h>
#include <stdlib.h>
#include "polynome.h"

int main()
{
    LSpoly poly1;
    LSpoly poly2;

    LSpoly polyaffiche;
    LSpoly polyresultat_add;
    LSpoly polyresultat_multi;
    LSpoly polyresultat_comp;

    LSpoly polyderive1;
    LSpoly polyderive2;

    LSpoly polyintegre1;
    LSpoly polyintegre2;

    int n1,n2,n3, n4;

    printf ("Bonjour et bienvenue sur ce programme de calcul scientifique de polynomes\n");


    printf("Commencons par le plus haut degre de votre premier polynome a:\n");
    scanf ("%d", &n1);
    constructpoly(&poly1, n1);
    Afficher(poly1);


    printf("Ensuite par le plus haut degre de votre deuxieme polynome a:\n");
    scanf ("%d", &n2);
    constructpoly(&poly2, n2);
    Afficher(poly2);

    if (n1<n2)
    {
        n3=n2;
    }

    else
    {
        n3=n1;
    }

    //construction de la liste chainee pour accueillir le resultat de l'addition et de la soustraction
    constructpoly_vide(&polyresultat_add, n3);

    //consutrction de la liste chainee pour accueillir le resultat de la comparaison en un point
    constructpoly_vide(&polyresultat_comp, n3);

    //construction de la liste chainee pour accueillir le resultat de la multiplication
    n4=n1+n2;
    constructpoly_vide(&polyresultat_multi, n4);

    //construction des listes chainees vides pour accueillir les derivees du poly 1 et 2
    constructpoly_vide(&polyderive1, n1-1);
    constructpoly_vide(&polyderive2, n2-1);

    //construction des listes chainees vides pour accueillir les integrales du poly 1 et 2
    constructpoly_vide(&polyintegre1, n1+1);
    constructpoly_vide(&polyintegre2, n2+1);


    int choix;
    int choix2;
    int choix3;
    int choix4;
    int choix5;

    printf("Appuyez sur 0 pour arreter, 2 pour afficher un polynome,\n");
    printf("Appuyez sur 3 pour additioner les deux polynomes entre eux\n");
    printf("Appuyez sur 4 pour soustraire un polynome par un autre\n");
    printf("Appuyez sur 5 pour multiplier les polynomes entre eux\n");
    printf("Appuyez sur 6 pour visualiser la derivee du polynome de votre choix\n");
    printf("Appuyez sur 7 pour comparer les polynomes entre eux en un point donne\n");
    printf("Appuyez sur 8 pour visualiser l'integrale du polynome de votre choix\n");

    scanf ("%d", &choix);

    printf ("\n");

    while (choix!=0)

    {

        if (choix==2)
        {
            printf ("Quel polynome voulez vous utiliser ? 1 pour polynome 1 et 2 pour polynome 2\n");
            scanf("%d", &choix2);

            if(choix2==1)
            {
                polyaffiche=poly1;
                Afficher(polyaffiche); //Affichage poly 1

            }

            if (choix2==2)
            {
                polyaffiche=poly2; //affichage poly 2
                Afficher(polyaffiche);
            }
        }



        if (choix==3) //addition
        {
            Addition(poly1,poly2, polyresultat_add);
            Afficher(polyresultat_add);

        }



        if (choix==4) //soustraction
        {
            printf("1. Polynome 1 - Polynome 2 ? Appuyez 1 \n");
            printf ("2. Polynome 2 - Polynome 1 ? Appuyez 2\n");
            scanf ("%d", &choix3);

            if (choix3==1) // P1 - P2
            {
                Soustraction(poly1,poly2, polyresultat_add);
                Afficher(polyresultat_add);
            }


            else if (choix3==2) // P2-P1
            {
                Soustraction2(poly1,poly2, polyresultat_add);
                Afficher(polyresultat_add);
            }

        }


        if (choix==5) //multiplication
        {
                Multiplication(poly1,poly2, polyresultat_multi);
                Afficher(polyresultat_multi);
        }


        if (choix==6) //derivation
        {
            printf ("Quel polynome voulez vous utiliser ? 1 pour polynome 1 et 2 pour polynome 2\n");
            scanf("%d", &choix4);

            if (choix4==1)
            {
                Derivation(poly1,polyderive1);
                Afficher(polyderive1);
            }


            else if (choix4==2)
            {
                Derivation(poly2,polyderive2);
                Afficher(polyderive2);
            }
        }


        if (choix==7) //comparaison
        {
                Soustraction(poly1,poly2, polyresultat_add);
                printf ("On fait d'abord la soustraction du Polynome 1 par le Polynome 2 : \n");
                Afficher(polyresultat_add);
                printf ("\n");

                Comparaison(polyresultat_add, polyresultat_comp);
        }


        if (choix==8) //integration
        {
            printf ("Quel polynome voulez vous utiliser ? 1 pour polynome 1 et 2 pour polynome 2\n");
            scanf("%d", &choix5);

            if (choix5==1)
            {
                Integration(poly1,polyintegre1);
                Afficher(polyintegre1);
            }


            else if (choix5==2)
            {
                Integration(poly2,polyintegre2);
                Afficher(polyintegre2);
            }
        }


    printf("Appuyez sur 0 pour arreter, 2 pour afficher un polynome,\n");
    printf("Appuyez sur 3 pour additioner les deux polynomes entre eux\n");
    printf("Appuyez sur 4 pour soustraire un polynome par un autre\n");
    printf("Appuyez sur 5 pour multiplier les polynomes entre eux\n");
    printf("Appuyez sur 6 pour visualiser la derivee du polynome de votre choix\n");
    printf("Appuyez sur 7 pour comparer les polynomes entre eux en un point donn�\n");
    printf("Appuyez sur 8 pour visualiser l'integrale du polynome de votre choix\n");


    scanf ("%d", &choix);

    printf ("\n");

    }

return 0;
}
