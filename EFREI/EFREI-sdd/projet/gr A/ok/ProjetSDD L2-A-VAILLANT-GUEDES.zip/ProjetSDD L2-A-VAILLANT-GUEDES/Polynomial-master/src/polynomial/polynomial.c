#include "polynomial.h"
#include "operations.h"
#include "../utils/bool.h"
#include "../utils/utility.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

inline Polynomial Polynomial_create()
{
    Polynomial polynomial;
    polynomial.monomials = List_create(Monomial_freeHandler);
    polynomial.roots = List_create(PolynomialRoot_freeHandler);

    return polynomial;
}

Polynomial Polynomial_createWithCoefficents(int polynomial_degree, Complex coefficients[])
{
    Polynomial polynomial = Polynomial_create();

    int i;
    for(i = 0; i < polynomial_degree; ++i)
    {
        if(coefficients[i].real != 0 || coefficients[i].imaginary != 0)
        {
            Monomial* monomial = Monomial_create(coefficients[i], i);
            LIST_APPEND_LAST(polynomial.monomials, monomial);
        }
    }

    return polynomial;
}

Polynomial Polynomial_fromString(char* polynomial_string, Bool* success)
{
    // Pour construre le polynôme on isole chaque monôme de la chaine de charactère
    // et on crée un monôme à l'aide de la fonction Monomial_fromString.
    *success = True;
    Polynomial polynomial = Polynomial_create();

    polynomial_string = String_removeSpaces(polynomial_string);
    char* monomial_token = NULL;
    char monomial_delemiters[] = " +";

    do
    {
        monomial_token = String_sep(&polynomial_string, monomial_delemiters);

        if(monomial_token != NULL && strcmp(monomial_token, "") != 0)
        {
            // On tente de créer le monôme isolé.
            Monomial* new_monomial = Monomial_fromString(monomial_token);

            if(new_monomial != NULL)
            {
                Polynomial_addMonomial(&polynomial, new_monomial);
                Monomial_destroy(new_monomial);
            }
            else
            {
                *success = False;
                return polynomial;
            }
        }

    } while(monomial_token != NULL);


    return polynomial;
}

Polynomial Polynomial_copy(const Polynomial* other)
{
    Polynomial polynomial = Polynomial_create();

    Monomial* current_monomial = (Monomial*)other->monomials.head;
    while(current_monomial != NULL)
    {
        LIST_APPEND_LAST(polynomial.monomials, Monomial_copy(current_monomial));

        LIST_ADVANCE_AS(Monomial*, current_monomial);
    }

    PolynomialRoot* current_root = (PolynomialRoot*)other->roots.head;
    while(current_root != NULL)
    {
        LIST_APPEND_LAST(polynomial.roots, PolynomialRoot_copy(current_root));

        LIST_ADVANCE_AS(PolynomialRoot*, current_root);
    }

    return polynomial;
}

int Polynomial_maximumDegree(Polynomial* polynomial)
{
    if(polynomial->monomials.tail != NULL)
    {
        return ((Monomial*)polynomial->monomials.tail)->exponant;
    }
    else
    {
        return 0;
    }
}

int Polynomial_minimumDegree(Polynomial* polynomial)
{
    if(polynomial->monomials.head != NULL)
    {
        return ((Monomial*)polynomial->monomials.head)->exponant;
    }
    else
    {
        return 0;
    }
}

void Polynomial_displayMonomials(Polynomial* polynomial)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {
        printf("(");
        Complex_display(&current->factor);
        printf(")x^%d", current->exponant);

        if(current != (Monomial*)polynomial->monomials.tail)
        {
            printf(" + ");
        }

        LIST_ADVANCE_AS(Monomial*, current);
    }

    PRINT_ENDL();
}

void Polynomial_displayRoots(Polynomial* polynomial)
{
    PolynomialRoot* current = LIST_BEGIN_AS(PolynomialRoot*, polynomial->roots);
    while(current != NULL)
    {
        printf("(x - (");
        Complex_display(&current->value);
        printf("))");

        LIST_ADVANCE_AS(PolynomialRoot*, current);
    }

    PRINT_ENDL();
}

void Polynomial_printMonomials(Polynomial* polynomial, FILE* target)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {
        fprintf(target, "(%lf,%lf)", current->factor.real, current->factor.imaginary);
        fprintf(target, "x^%d", current->exponant);

        if(current != (Monomial*)polynomial->monomials.tail)
        {
            fputs(" + ", target);
        }

        LIST_ADVANCE_AS(Monomial*, current);
    }
}

void Polynomial_destroy(Polynomial* polynomial)
{
    List_clear(&polynomial->monomials);
    List_clear(&polynomial->roots);
}
