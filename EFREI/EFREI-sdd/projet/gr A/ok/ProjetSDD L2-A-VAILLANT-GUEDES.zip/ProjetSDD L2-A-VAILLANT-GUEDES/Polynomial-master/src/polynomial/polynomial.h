#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include "../utils/list.h"
#include "monomial.h"
#include "polynomial_root.h"

#include <stdio.h>

typedef List MonomialList;
typedef List PolynomialRootList;

/**
 * @brief Représente un polynôme
 *
 * La forme polynomial est comporte deux représentations:
 *  - la forme développé (Liste de monôme)
 *  - la forme factorisé (Liste des racines du polynome)
*/
typedef struct Polynomial
{
    MonomialList monomials;
    PolynomialRootList roots;
} Polynomial;

/**
 * @brief Polynomial_create Crée un polynôme vide
*/
Polynomial Polynomial_create();

/**
 * @brief Polynomial_createWithCoefficents Crée un polynôme à partir des coefficients donnés en
 * paramètre.
 *
 * Le tableau coefficients doit être de la même taille que polynomial_degree.
*/
Polynomial Polynomial_createWithCoefficents(int polynomial_degree, Complex coefficients[]);

/**
 * @brief Polynomial_fromString Crée un polynôme à partir d'une chaine de charactères.
 *
 * La chaine de charactère doit être sous la forme de (x1,y1)x^d1 + (x2,y2)x^d2 ...
*/
Polynomial Polynomial_fromString(char* polynomial_string, Bool* success);

/**
 * @brief Polynomial_copy Crée un polynôme en copiant le polynôme donné en paramètre
*/
Polynomial Polynomial_copy(const Polynomial* other);

/**
 * @brief Polynomial_maximumDegree Retourne le degré maximum du polynôme.
*/
int Polynomial_maximumDegree(Polynomial* polynomial);

/**
 * @brief Polynomial_minimumDegree Retourne le degré minimul du polynôme.
*/
int Polynomial_minimumDegree(Polynomial* polynomial);

/**
 * @brief Polynomial_displayMonomials Affiche la forme développez d'un polynôme.
*/
void Polynomial_displayMonomials(Polynomial* polynomial);

/**
 * @brief Polynomial_displayMonomials Affiche la forme factorisée d'un polynôme.
*/
void Polynomial_displayRoots(Polynomial* polynomial);

/**
 * @brief Polynomial_printMonomials Ecrit un polynôme dans un fichier donné.
*/
void Polynomial_printMonomials(Polynomial* polynomial, FILE* target);

/**
 * @brief Polynomial_destroy Libère la mémoire allouée lors de la création du polynôme.
*/
void Polynomial_destroy(Polynomial* polynomial);


#endif // POLYNOMIAL_H
