#ifndef APPLICATION_H
#define APPLICATION_H

#include "../utils/bool.h"
#include "../utils/utility.h"
#include "polynomial_set.h"

/**
 * @brief Structure utilitaire permettant d'initialiser les variables utiles
 * au déroulement du programme et de lancer l'execution de la boucle principale.
*/
typedef struct Application
{
    PolynomialSet polynomials;
    Bool should_quit;
    char last_file[MAX_STRING_SIZE];
} Application;

/**
 * @brief Application_create Crée une application.
*/
Application Application_create();

/**
 * @brief Application_run Lance le menu dans une boucle principale.
 *
 * La fonction random est également initialisé dans cette fonction.
*/
int Application_run(Application* app);

/**
 * @brief Application_displayMenu Affiche le menu.
*/
void Application_displayMenu(Application* app);


int Application_destroy(Application* app);

#endif // APPLICATION_H
