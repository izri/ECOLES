#ifndef POLYNOMIAL_ROOT_H
#define POLYNOMIAL_ROOT_H

#include "../utils/list.h"
#include "../utils/complex.h"

/**
 * @brief Représente une racine d'un polynôme.
 *
 * Cette structure peut être chainée avec PolynomialRoot_freeHandler
*/
typedef struct PolynomialRoot
{
    ListNode node;

    Complex value;
} PolynomialRoot;

/**
 * @brief PolynomialRoot_create Crée une racine polynômial suivant les paramètres donnés.
*/
PolynomialRoot* PolynomialRoot_create(Complex value);

/**
 * @brief PolynomialRoot_copy Crée une racine polynômial en copiant la racine donnée en paramètre.
*/
PolynomialRoot* PolynomialRoot_copy(PolynomialRoot* other);

/**
 * @brief PolynomialRoot_destroy Libère la mémoire allouée lors de la création de la racine.
*/
void PolynomialRoot_destroy(PolynomialRoot* root);

/**
 * @brief PolynomialRoot_freeHandler Même utilité que PolynomialRoot_destroy mais est utilisé
 * par la @sa List générique.
*/
void PolynomialRoot_freeHandler(ListNode* root);

#endif // POLYNOMIAL_ROOT_H
