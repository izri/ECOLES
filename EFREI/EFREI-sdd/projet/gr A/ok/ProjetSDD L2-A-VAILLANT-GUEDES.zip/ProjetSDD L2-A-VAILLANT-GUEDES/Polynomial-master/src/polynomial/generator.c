#include "generator.h"
#include "operations.h"

#include <stdlib.h>
#include <time.h>

Polynomial PolynomialGenerator_generate(int min_deg, int max_deg, double density)
{
    Polynomial polynomial = Polynomial_create();
    double real = 0.;
    double imaginary = 0.;

    int i;
    for(i = min_deg; i <= max_deg; ++i)
    {
        // On génère des coefficient aléatoire compris entre -100 et 100.
        real = rand()%200 + 100;
        real -= 200;

        imaginary = rand()%200 + 100;
        imaginary -= 200;

        double generate_chance = rand()%100;
        generate_chance /= 100;

        // On ajoute le monôme si la densité est assez élevée.
        if(density > generate_chance)
        {
            Monomial* monomial = Monomial_create(Complex_create(real, imaginary), i);
            Polynomial_addMonomial(&polynomial, monomial);
            Monomial_destroy(monomial);
        }
    }

    return polynomial;
}
