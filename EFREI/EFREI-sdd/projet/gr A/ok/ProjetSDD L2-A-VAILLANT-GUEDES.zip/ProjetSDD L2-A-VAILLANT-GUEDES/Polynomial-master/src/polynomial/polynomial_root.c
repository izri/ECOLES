#include "polynomial_root.h"

#include <stdlib.h>

PolynomialRoot* PolynomialRoot_create(Complex value)
{
    PolynomialRoot* root = (PolynomialRoot*)malloc(sizeof(PolynomialRoot));
    root->node = ListNode_create();
    root->value = value;

    return root;
}

PolynomialRoot* PolynomialRoot_copy(PolynomialRoot* other)
{
    return PolynomialRoot_create(
        other->value
    );
}

void PolynomialRoot_destroy(PolynomialRoot *root)
{
    free(root);
}

void PolynomialRoot_freeHandler(ListNode* root)
{
    PolynomialRoot_destroy((PolynomialRoot*)root);
}
