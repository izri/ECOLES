#ifndef BOOL_H
#define BOOL_H

/**
 * Simple enumeration pour imiter un type booléen
*/
typedef enum Bool
{
    False = 0,
    True
} Bool;

#endif // BOOL_H
