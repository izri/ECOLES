#ifndef POLYNOMIAL_SET_H
#define POLYNOMIAL_SET_H

#include "../utils/list.h"
#include "polynomial_entry.h"

#include <stdio.h>

typedef List PolynomialList;

/**
 * @brief Structure utilitaire qui permet de stockée toute les entrée de polynôme (PolynomialEntry)
 * et de permettre la récupération d'un polynôme suivant son nom.
*/
typedef struct PolynomialSet
{
    PolynomialList polynomials;
} PolynomialSet;

/**
 * @brief PolynomialSet_create Crée un PolynomialSet vide.
*/
PolynomialSet PolynomialSet_create();

/**
 * @brief PolynomialSet_fromFile Crée un PolynmialSet selon le contenu du fichier donné en paramètre.
 *
 * Si la fonction échoue, success est mis sur False. Sinon True.
*/
PolynomialSet PolynomialSet_fromFile(FILE* stream, Bool* success);

/**
 * @brief PolynomialSet_insert Ajoute une entrée à PolynomialSet.
 *
 * Aucune vérification de doublon est effectuée.
*/
void PolynomialSet_insert(PolynomialSet* set, PolynomialEntry* entry);

/**
 * @brief PolynomialSet_find Cherche un polynôme selon le nom de l'entrée associée.
 *
 * Si aucune entrée est trouvée, NULL est retourné.
*/
Polynomial* PolynomialSet_find(PolynomialSet* set, const char* name);

/**
 * @brief PolynomialSet_find Cherche une entrée selon son nom.
 *
 * Si aucune entrée est trouvée, NULL est retourné.
*/
PolynomialEntry* PolynomialSet_findEntry(PolynomialSet* set, const char* name);

/**
 * @brief PolynomialSet_displayEntries Affiche toutes les entrée contenues dans PolynomialSet.
*/
void PolynomialSet_displayEntries(PolynomialSet* set);

/**
 * @brief PolynomialSet_printEntries Ecrit toutes les entrée de PolynomialSet dans le fichier donné en paramètre.
*/
void PolynomialSet_printEntries(PolynomialSet* set, FILE* target);

/**
 * @brief PolynomialSet_destroy Libère la mémoire utilisée par PolynomialSet.
*/
void PolynomialSet_destroy(PolynomialSet* set);

#endif // POLYNOMIAL_SET_H
