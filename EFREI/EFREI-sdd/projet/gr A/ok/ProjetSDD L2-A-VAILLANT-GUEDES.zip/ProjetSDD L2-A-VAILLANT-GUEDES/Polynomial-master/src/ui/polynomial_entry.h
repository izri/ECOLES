#ifndef POLYNOMIAL_ENTRY_H
#define POLYNOMIAL_ENTRY_H

#include "../utils/list.h"
#include "../polynomial/polynomial.h"

/**
 * @brief Représente un polynôme enregistrés.
 *
 * Tout polynôme enregistré est associé à un nom.
*/
typedef struct PolynomialEntry
{
    ListNode node;

    char* name;
    Polynomial polynomial;
} PolynomialEntry;

/**
 * @brief PolynomialEntry_create Crée une entrée avec le nom donné en paramètre.
 *
 * Un polynôme vide y est associé.
*/
PolynomialEntry* PolynomialEntry_create(const char* name);

/**
 * @brief PolynomialEntry_fromString Crée une entrée depuis la chaine de charactère
 * donnée en pramètre.
 *
 * La chaine de charactère doit être sous la forme nom:polynôme. Pour la construction de polynôme
 * se réferer à la fonction Polynomial_fromString.
*/
PolynomialEntry* PolynomialEntry_fromString(char* str);

/**
 * @brief PolynomialEntry_display Affiche l'entrée en affichant son nom puis le polynôme associé.
*/
void PolynomialEntry_display(PolynomialEntry* entry);

/**
 * @brief PolynomialEntry_print Ecrit l'entrée dans un fichier donné en paramètre.
*/
void PolynomialEntry_print(PolynomialEntry* entry, FILE* target);

/**
 * @brief PolynomialEntry_destroy Libère la mémoire allouée lors de la création de l'entrée.
*/
void PolynomialEntry_destroy(PolynomialEntry* entry);

/**
 * @brief PolynomialEntry_freeHandler Même utilité que PolynomialEntry_destroy mais est utilisé
 * par la @sa List générique.
 */
void PolynomialEntry_freeHandler(ListNode* node);

#endif // POLYNOMIAL_ENTRY_H
