#ifndef UTILITY_H
#define UTILITY_H

#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Permet de réinitialiser l'affichage de la console sur différente plateformes.
*/
#ifdef _WIN32
    #include <Windows.h>

    #define CLEAR() system("cls");
#else
    #include <unistd.h>

    #define CLEAR() system("clear");
#endif

// Définie une taille arbitraire d'un buffer statique
#define MAX_BUFFER_SIZE 256

// Définie une taille arbitraire d'une chaine de charactère
#define MAX_STRING_SIZE 256

// Définie une taille minimial d'une zone mémoire d'un buffer non statique
#define MIN_CHUNCK_SIZE 256

/**
 * @brief Permet de supprimer le '\n' à la suite d'une saisie utilisateur.
*/
#define REMOVE_TRAILING_NEW_LINE(string)  \
    {                                     \
        size_t pos = strlen(string) - 1;  \
        if(string[pos] == '\n')           \
            string[pos] = '\0';           \
    }

/**
 * @brief Permet d'initialiser une chaine de charactère à '\0'
*/
#define INIT_STRING(name, size)             \
    char name[size];                        \
    memset(name, '\0', size*sizeof(char));  \

/**
 * @brief Récupère une saisie utilisateur et scanne le résultat dans value selon le format spécifié.
*/
#define ASK(txt, format, value)                 \
    {                                           \
        INIT_STRING(buffer, MAX_BUFFER_SIZE);   \
        printf(txt);                            \
        fflush(stdout);                         \
                                                \
        fgets(buffer, MAX_BUFFER_SIZE, stdin);  \
        REMOVE_TRAILING_NEW_LINE(buffer);       \
        sscanf(buffer, format, value);          \
    }

/**
 * @brief Récupère une ligne saisie par l'utilisateur est stocke le resultat dans line.
 *
 * La macro crée et initialise line.
*/
#define ASK_LINE(txt, line)             \
    INIT_STRING(line, MAX_BUFFER_SIZE); \
    printf(txt);                        \
    fflush(stdout);                     \
                                        \
    fgets(line, MAX_BUFFER_SIZE, stdin);\
    REMOVE_TRAILING_NEW_LINE(line);     \

/**
 * @brief Ajoute un saut de ligne dans stdout
*/
#define PRINT_ENDL() \
    printf("\n");


#define UNUSED(x) \
    (void)x;

/**
 * @brief String_removeSpaces Supprime tout les espaces d'une chaine de charactère.
*/
char* String_removeSpaces(char* str);

/**
 * @brief String_sep Réimplementation de strsep pour windows.
*/
char* String_sep(char** strgp, const char* delimiters);

/**
 * @brief String_subString Réimplementation de strsubstr pour windows.
*/
ssize_t String_subString(char** substr, size_t* substr_size, FILE* stream, char terminator, int offset);

/**
 * @brief String_getLine Réimplementation de get_line pour windows.
*/
ssize_t String_getLine(char** substr, size_t* substr_size, FILE* stream);

/**
 * @brief Int_max retourne l'entier supérieur
*/
int Int_sup(int left, int right);

/**
 * @brief Int_max retourne l'entier inférieur
*/
int Int_inf(int left, int right);

#endif // UTILITY_H
