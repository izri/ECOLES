#ifndef OPERATIONS_H
#define OPERATIONS_H

#include "polynomial.h"

/**
 * Ce fichier contient toute les opérations arithmétiques relatives
 * aux polynômes
*/

/**
 * Représente une pointeur sur une fonction opératoire
*/
typedef Polynomial* (*PolynomialOperation)(Polynomial*, const Polynomial*);

/**
 * @brief PolynomialOperation_fromString Tente de retourner une opération selon le string
 *
 * Si aucune opérations ne correspond NULL est retourné
*/
PolynomialOperation PolynomialOperation_fromString(const char* name);

/**
 * @brief Polynomial_add Effectue l'addition de deux polynômes
 *
 * Le polynôme à gauche de l'opération reçoit le résultat
*/
Polynomial* Polynomial_add(Polynomial* left, const Polynomial* right);

/**
 * @brief Polynomial_addMonomial Identique à la fonction @sa Polynomial_add
 * mais cette fois ci avec un monôme
 *
 * Pour tout ajout de monôme à un polynôme (y compris pendant la construction) cette
 * fonction doit être utilisée
*/
Polynomial* Polynomial_addMonomial(Polynomial* left, Monomial* right);

/**
 * @brief Polynomial_subtract Effectue une soustraction de deux polynômes
 *
 * Le polynômes à gauche de l'opération reçoit le résultat.
*/
Polynomial* Polynomial_subtract(Polynomial* left, const Polynomial* right);

/**
 * @brief Polynomial_multiply Effectue une multiplication de deux polynômes
*/
Polynomial* Polynomial_multiply(Polynomial* left, const Polynomial* right);

/**
 * @brief Polynomial_karatsuba Implementation de l'algorithme de karatsuba
 *
 * Les deux polynômes sont modifiés
*/
Polynomial* Polynomial_karatsuba(Polynomial* A, Polynomial* B);

/**
 * @brief Polynomial_rawMultiply Implementation de la multiplicatio naïve
*/
Polynomial* Polynomial_rawMultiply(Polynomial* left, const Polynomial* right);

/**
 * @brief Polynomial_rawMultiply Effectue une multiplication d'un polynôme et d'un monôme
*/
Polynomial* Polynomial_multiplyByMonomial(Polynomial* left, const Monomial* right);

/**
 * @brief Polynomial_splitAndReduceLeft Sépare un polynôme en deux sous polynôme et réduit la première partie.
 *
 * Les polynôme sont séparés selon n. Le première partie est réduit par x^n.
 * Le polynôme séparé est modifié et deviens nul.
*/
void Polynomial_splitAndReduce(Polynomial* splitted, Polynomial* left, Polynomial* right, int n);

/**
 * @brief Polynomial_increase Ajoute la puissance n tout les monôme d'un polynôme.
 *
*/
void Polynomial_increase(Polynomial* polynomial, int n);

/**
 * @brief Polynomial_multiplyByScalar Effectue une multiplication de l'ensemble des
 * monôme d'un polynôme par un scalaire.
*/
Polynomial* Polynomial_multiplyByScalar(Polynomial* left, double right);

/**
 * @brief Polynomial_evaluate Evalue un polynôme
*/
Complex Polynomial_evaluate(const Polynomial* polynomial, const Complex* value);

/**
 * @brief Polynomial_derive Derive un polynôme
*/
Polynomial* Polynomial_derive(Polynomial* polynomial);

/**
 * @brief Polynomial_integrate Integre un polynôme
*/
Polynomial* Polynomial_integrate(Polynomial* polynomial);

/**
 * @brief Polynomial_pow Elève à la puissance pow un polynôme
*/
Polynomial* Polynomial_pow(Polynomial* left, int pow);

/**
 * @brief Polynomial_compose Effectue la composition de deux polynômes left(right(X))
*/
Polynomial* Polynomial_compose(Polynomial* left, const Polynomial* right);

/**
 * @brief Polynomial_factoring Factorise un polynme à l'aide des méthode de DurandKerner et Aberth
 */
Polynomial* Polynomial_factoring(Polynomial* polynomial);

/**
 * @brief Polynomial_DurandKerner Effectue une approximation initial des racines
 */
Polynomial* Polynomial_DurandKerner(Polynomial* polynomial);

/**
 * @brief Polynomial_Aberth Affine les approximations initials des racines
*/
Polynomial* Polynomial_Aberth(Polynomial* polynomial);

/**
 * @brief Polynomial_extraction Sépare la partie imaginaire et la partie réel du polynôme
*/
Polynomial* Polynomial_extraction(Polynomial* extract, Polynomial* real_part, Polynomial* imaginary_part);

/**
 * @brief Polynomial_conjugate Conjuge les coefficients du polynôme
*/
Polynomial* Polynomial_conjugate(Polynomial* polynomial);

/**
 * @brief Polynomial_euclidean_division Division euclidienne de deux polynômes
*/
Polynomial Polynomial_euclideanDivision(Polynomial* left, Polynomial* right, Polynomial* remainder);

/**
 * @brief Polynomial_gcd Retourne le PGCD des deux polynômes
 *
 * Les deux polynômes sont modifiés
*/
Polynomial Polynomial_gcd(Polynomial* left, Polynomial* right);

/**
 * @brief Polynomial_equal Compare deux polynômes, s'il sont égaux renvoit True
*/
Bool Polynomial_equal(Polynomial* left, Polynomial* right);

#endif // OPERATIONS_H
