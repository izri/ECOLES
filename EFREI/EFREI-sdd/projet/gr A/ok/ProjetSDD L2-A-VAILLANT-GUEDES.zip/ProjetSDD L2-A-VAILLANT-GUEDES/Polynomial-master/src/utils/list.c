#include "list.h"
#include "bool.h"

#include <stdlib.h>

ListNode ListNode_create()
{
    ListNode node;
    node.next = NULL;
    node.previous = NULL;

    return node;
}

List List_create(ListFreeHandler free_handler)
{
    List list;
    list.tail = NULL;
    list.head = NULL;
    list.len = 0;
    list.free_handler = free_handler;

    return list;
}

void List_appendFirst(List* list, ListNode* node)
{
    if(list->len == 0)
    {
        list->tail = node;
        list->head = node;
    }
    else
    {
        node->next = list->head;
        list->head->previous = node;
        list->head = node;
    }

    list->len += 1;
}

void List_appendLast(List* list, ListNode* node)
{
    if(list->len == 0)
    {
        list->tail = node;
        list->head = node;
    }
    else
    {
        list->tail->next = node;
        node->previous = list->tail;
        list->tail = node;
    }

    list->len += 1;
}

void List_remove(List* list, ListNode* node)
{
    if(list->head == node)
    {
        list->head = list->head->next;
    }
    else if(list->tail == node)
    {
        list->tail = list->tail->previous;
        list->tail->next = NULL;
    }
    else
    {
        node->previous->next = node->next;
        node->next->previous = node->previous;
    }

    list->len -= 1;
    list->free_handler(node);
}

ListNode* List_popFirst(List* list)
{
    if(list->len == 0)
    {
        return NULL;
    }

    ListNode* popped = list->head;
    list->head = list->head->next;

    if(list->head)
    {
        list->head->previous = NULL;
    }
    else
    {
        list->tail = NULL;
    }

    list->len -= 1;

    popped->next = popped->previous = NULL;
    return popped;
}

int List_len(List* list)
{
    return list->len;
}

void List_clear(List* list)
{
    ListNode* current = list->head;
    while(current != NULL)
    {
        ListNode* next = current->next;
        list->free_handler(current);

        current = next;
    }
    list->head = NULL;
    list->tail = NULL;
    list->len = 0;
}


void List_appendAfter(List* list, ListNode* current, ListNode* to_append)
{
    // Si current est NULL alors ça revient à rajouter l'élement en fin de liste.
    if(current == NULL || list->tail == current)
    {
        List_appendLast(list, to_append);
    }
    else
    {
        to_append->next = current->next;
        to_append->previous = current;
        current->next->previous = to_append;
        current->next = to_append;

        list->len += 1;
    }
}


void List_appendBefore(List* list, ListNode* current, ListNode* to_append)
{
    // Si current est NULL alors on considère arbitrairement un ajout en fin de liste.
    if(current == NULL)
    {
        List_appendLast(list, to_append);
    }
    else if(current == list->head)
    {
        List_appendFirst(list, to_append);
    }
    else
    {
        to_append->next = current;
        to_append->previous = current->previous;
        current->previous->next = to_append;
        current->previous = to_append;

        list->len += 1;
    }
}
