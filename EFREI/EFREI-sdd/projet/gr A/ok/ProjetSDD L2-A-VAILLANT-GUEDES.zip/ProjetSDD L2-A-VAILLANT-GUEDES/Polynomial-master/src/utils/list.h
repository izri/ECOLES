#ifndef LIST_H
#define LIST_H

#include "bool.h"

/**
 * @brief Représente un noeud d'une liste doublement chainée
 *
 * La struct ListNode est intrusive. Les structures qui veulent
 * être listées doivent contenir la struct ListNode en premier champs
 * pour fonctionner correctement avec les fonctions de List.
*/
typedef struct ListNode
{
    struct ListNode* next;
    struct ListNode* previous;
} ListNode;

/**
 * @brief Callback appellé lors de la suppression d'un élément de la liste
 *
 * La fonction appellée doit se charger de libérer la mémoire.
 */
typedef void (*ListFreeHandler)(ListNode*);

/**
  * @brief Liste générique doublement chainée avec une seule allocation par node
  *
  * La liste prend en paramère des ListNode, il conviendra de cast le type en (ListNode*)
  * lorsque necessaire.
*/
typedef struct List {
    ListNode* head;
    ListNode* tail;
    int len;

    ListFreeHandler free_handler;
} List;

/**
 * @brief ListNode_create Facilite la création d'une structure listée
 * @return Un struct liste node initialisé à NULL
 */
ListNode ListNode_create();

/**
 * @brief List_create Crée une liste vide.
 * @param free_handler Callback pour libérer les éléments
 */
List List_create(ListFreeHandler free_handler);

/**
 * @brief List_appendFirst Ajoute un ListeNode au début de la liste
 */
void List_appendFirst(List* list, ListNode* node);

/**
 * @brief List_appendLast Ajoute un ListNode à la fin de la liste
 */
void List_appendLast(List* list, ListNode* node);

/**
 * @brief List_appendAfter Ajoute un élément après l'élément current
 */
void List_appendAfter(List* list, ListNode* current, ListNode* to_append);

/**
 * @brief List_appendBefore Ajoute un élément avant l'élément current
 */
void List_appendBefore(List* list, ListNode* current, ListNode* to_append);

/**
 * @brief List_remove Supprime un noeud donné de la liste
 */
void List_remove(List* list, ListNode* node);

/**
 * @brief List_popFirst Retire et retourne le premier élément de la liste
*/
ListNode* List_popFirst(List* list);

/**
 * @brief List_len Retourne la taille de la liste
 */
int List_len(List* list);

/**
 * @brief List_clear Supprime tous les éléments présent dans la liste
 *
 * Cette fonction libère la mémoire, il faut donc faire attention aux cross références
 */
void List_clear(List* list);

/**
 * @brief Permet d'avancer un pointeur sur un ListNode au suivant sans cast explicite
*/
#define LIST_ADVANCE_AS(type, iterator) \
    iterator = (type)iterator->node.next;

/**
 * @brief Permet de reculer un pointeur sur un ListNode au suivant sans cast explicite
*/
#define LIST_BACK_AS(type, iterator) \
    iterator = (type)iterator->node.previous;

/**
 * Permet d'ajouter un élément à la fin de liste sans cast explicite
*/
#define LIST_APPEND_LAST(list, node) \
    List_appendLast(&list, (ListNode*)node);

/**
 * Permet d'ajouter un élément après current sans cast explicite
*/
#define LIST_APPEND_AFTER(list, current, to_append) \
    List_appendAfter(&list, (ListNode*)current, (ListNode*)to_append);

/**
 * Permet d'ajouter un élément avant current sans cast exlicite
*/
#define LIST_APPEND_BEFORE(list, current, to_append) \
    List_appendBefore(&list, (ListNode*)current, (ListNode*)to_append);

/**
 * Permet de supprimer un élément de la liste sans cast explicite
*/
#define LIST_REMOVE(list, node) \
    List_remove(&list, (ListNode*)node);

/**
 * Permet de retirer et récuperer le premier élément de la liste sans cast explicite
*/
#define LIST_POP_FIRST_AS(type, list) \
    (type)List_popFirst(&list);
/**
 * Permet de récuperer le premier élément de la liste sans cast explicite
*/
#define LIST_BEGIN_AS(type, list) \
    (type)list.head;

/**
 * Permet de récuperer le premier élément de la liste sans cast explicite
*/
#define LIST_LAST_AS(type, list) \
    (type)list.tail;


#endif // LIST_H
