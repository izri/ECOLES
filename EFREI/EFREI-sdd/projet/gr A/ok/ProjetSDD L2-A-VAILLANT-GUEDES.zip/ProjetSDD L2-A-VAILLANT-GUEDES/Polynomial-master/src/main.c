#include <stdlib.h>
#include "ui/application.h"
#include "polynomial/operations.h"

#include <string.h>

int main()
{
    Application app = Application_create();
    return Application_run(&app);
}
