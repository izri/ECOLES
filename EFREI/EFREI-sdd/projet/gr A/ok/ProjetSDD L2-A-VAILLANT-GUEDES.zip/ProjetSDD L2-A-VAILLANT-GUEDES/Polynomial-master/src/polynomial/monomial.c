#include "monomial.h"

#include <stdlib.h>
#include <stdio.h>

Monomial* Monomial_create(Complex factor, int exponant)
{
    Monomial* monomial = (Monomial*)malloc(sizeof(Monomial));
    monomial->node = ListNode_create();

    monomial->factor = factor;
    monomial->exponant = exponant;

    return monomial;
}


Monomial* Monomial_fromString(char* monomial_string)
{
    double real = 0.;
    double imaginary = 0.;
    int exponent = 0;

    // On ne prend pas en compte l'écriture d'une constante seule.
    int scanned = sscanf(monomial_string, "(%lf,%lf)x^%d", &real, &imaginary, &exponent);

    if(scanned == 3)
    {
        return Monomial_create(Complex_create(real, imaginary), exponent);
    }
    else
    {
        return NULL;
    }
}

Monomial* Monomial_copy(Monomial* other)
{
    return Monomial_create(other->factor, other->exponant);
}

void Monomial_destroy(Monomial* monomial)
{
    free(monomial);
}

void Monomial_freeHandler(ListNode* monomial)
{
    Monomial_destroy((Monomial*)monomial);
}
