#include "operations.h"
#include "../utils/utility.h"

#include <stdlib.h>
#include <string.h>

PolynomialOperation PolynomialOperation_fromString(const char* name)
{
    if(strcmp(name, "add") == 0)
    {
        return &Polynomial_add;
    }
    else if(strcmp(name, "sub") == 0)
    {
        return &Polynomial_subtract;
    }
    else if(strcmp(name, "mul") == 0)
    {
        return &Polynomial_multiply;
    }
    else if(strcmp(name, "cmul") == 0)
    {
        return &Polynomial_rawMultiply;
    }
    else if(strcmp(name, "compose") == 0)
    {
        return &Polynomial_compose;
    }
    else
    {
        return NULL;
    }
}

Polynomial* Polynomial_add(Polynomial* left, const Polynomial* right)
{
    // La fonction assume que les deux polynômes ont les monômes triés.
    // Par conséquent il nous suffit de parcourir le polynôme de droite en surveillant
    // les dégrés de chaque monôme courant.

    Monomial* left_current = LIST_BEGIN_AS(Monomial*, left->monomials);
    Monomial* right_current = LIST_BEGIN_AS(Monomial*, right->monomials);
    while(right_current != NULL)
    {
        // Si les degrés des monômes sont identique on ajoute les facteurs.
        if(left_current != NULL && left_current->exponant == right_current->exponant)
        {
            Complex_add(&left_current->factor, &right_current->factor);

            // Dans le cas où l'addition nullifie un monôme on le garde en mémoire pour le supprimer
            // plus tard.
            Monomial* to_remove = NULL;
            if(left_current->factor.real == 0 && left_current->factor.imaginary == 0)
            {
                to_remove = left_current;
            }

            // Puisque les deux monômes sont identiques on peut avancer dans les deux listes.
            LIST_ADVANCE_AS(Monomial*, left_current);
            LIST_ADVANCE_AS(Monomial*, right_current);

            if(to_remove)
            {
                LIST_REMOVE(left->monomials, to_remove);
            }
        }
        else if(left_current == NULL || left_current->exponant > right_current->exponant)
        {
            // Dans le cas ou le monôme courant de gauche est NULL alors tous les monômes
            // de droite on des dégrés supérieurs et sont donc rajoutés à la fin du polynôme
            // de gauche.
            //
            // Sinon si le degré du monôme courant de droite à un degré supérieur à celui de gauche,
            // on l'ajoute avant le monôme courant de gauche et on avance dans le polynôme de droite
            // jusqu'à ce que la condition ne soit plus vérifiée.
            LIST_APPEND_BEFORE(left->monomials, left_current, Monomial_copy(right_current));


            LIST_ADVANCE_AS(Monomial*, right_current);
        }
        else
        {
            // Dans ce cas, le monôme de gauche est inférieur à tous les monômes de droite
            // on peut donc continuer dans le polynôme de gauche jusqu'à ce que cette condition
            // ne soit plus vérifiée.
            LIST_ADVANCE_AS(Monomial*, left_current);
        }
    }

    List_clear(&left->roots);
    return left;
}

Polynomial* Polynomial_addMonomial(Polynomial* left, Monomial* right)
{
    // Pour ajouter un monôme à un polynôme, on crée un polynôme temporaire
    // et on l'ajoute au polynôme de gauche.

    if(right->factor.real != 0 || right->factor.imaginary != 0)
    {
        Polynomial singleton = Polynomial_create();
        LIST_APPEND_LAST(singleton.monomials, right);

        Polynomial_add(left, &singleton);

        right->node.next = right->node.previous = NULL;
    }

    List_clear(&left->roots);
    return left;
}

Polynomial* Polynomial_subtract(Polynomial* left, const Polynomial* right)
{
    // La fonction assume que les deux polynômes ont les monômes triés.
    // Par conséquent il nous suffit de parcourir le polynôme de droite en surveillant
    // les dégrés de chaque monôme courant.

    Monomial* left_current = LIST_BEGIN_AS(Monomial*, left->monomials);
    Monomial* right_current = LIST_BEGIN_AS(Monomial*, right->monomials);
    while(right_current != NULL)
    {
        // Si les degrés des monômes sont identique on ajoute les facteurs.
        if(left_current != NULL && left_current->exponant == right_current->exponant)
        {
            Complex_subtract(&left_current->factor, &right_current->factor);

            // Dans le cas où l'addition nullifie un monôme on le garde en mémoire pour le supprimer
            // plus tard.
            Monomial* to_remove = NULL;
            if(left_current->factor.real == 0 && left_current->factor.imaginary == 0)
            {
                to_remove = left_current;
            }

            // Puisque les deux monômes sont identiques on peut avancer dans les deux listes.
            LIST_ADVANCE_AS(Monomial*, left_current);
            LIST_ADVANCE_AS(Monomial*, right_current);

            if(to_remove)
            {
                LIST_REMOVE(left->monomials, to_remove);
            }
        }
        else if(left_current == NULL || left_current->exponant > right_current->exponant)
        {
            // Dans le cas ou le monôme courant de gauche est NULL alors tous les monômes
            // de droite on des dégrés supérieurs et sont donc rajoutés à la fin du polynôme
            // de gauche.
            //
            // Sinon si le degré du monôme courant de droite à un degré supérieur à celui de gauche,
            // on l'ajoute avant le monôme courant de gauche et on avance dans le polynôme de droite
            // jusqu'à ce que la condition ne soit plus vérifiée.
            
            Monomial* copy = Monomial_copy(right_current);
            copy->factor.real *= -1; copy->factor.imaginary *= -1;
            LIST_APPEND_BEFORE(left->monomials, left_current, copy);


            LIST_ADVANCE_AS(Monomial*, right_current);
        }
        else
        {
            // Dans ce cas, le monôme de gauche est inférieur à tous les monômes de droite
            // on peut donc continuer dans le polynôme de gauche jusqu'à ce que cette condition
            // ne soit plus vérifiée.
            LIST_ADVANCE_AS(Monomial*, left_current);
        }
    }

    List_clear(&left->roots);
    return left;
}

Polynomial* Polynomial_multiply(Polynomial* left, const Polynomial* right)
{
    // L'algo de karatsuba va modifier le polynôme right, on en fait donc une copie
    Polynomial right_copy = Polynomial_copy(right);
    Polynomial_karatsuba(left, &right_copy);
    Polynomial_destroy(&right_copy);

    return left;
}

Polynomial* Polynomial_karatsuba(Polynomial* A, Polynomial* B)
{
    // Tout d'abord on vérifie si l'un des polynôme est nul.
    // Si la condition est vérifier on renvoit un résultat nul.
    if(A->monomials.len == 0 || B->monomials.len == 0)
    {
        Polynomial_destroy(A);
        *A = Polynomial_create();

        return A;
    }

    // On détermine la puissance "centrale".
    int max_degree = Int_sup(Polynomial_maximumDegree(A), Polynomial_maximumDegree(B));
    int min_degree = Int_inf(Polynomial_minimumDegree(A), Polynomial_minimumDegree(B));
    int n = (min_degree + max_degree)/2;

    // Si un deux polynôme est un singleton alors on peut effectuer la multiplication
    // classique
    if(n == 0 || A->monomials.len == 1 || B->monomials.len == 1)
    {
        return Polynomial_rawMultiply(A, B);
    }

    // On va décomposer les polynôme selon n tel que:
    // A = Au*x^n + Al et B = Au*x^n + Bl
    Polynomial Au, Al, Bu, Bl;
    Au = Al = Bu = Bl = Polynomial_create();

    Polynomial_splitAndReduce(A, &Au, &Al, n);
    Polynomial_splitAndReduce(B, &Bu, &Bl, n);

    // On commence par calculer un résultat intermediaire
    // soit D0 = Al*Bl
    Polynomial D0 = Polynomial_copy(&Al);
    Polynomial_multiply(&D0, &Bl);

    // Puis D1 = Au*Bu
    Polynomial D1 = Polynomial_copy(&Au);
    Polynomial_multiply(&D1, &Bu);

    // Al et Bl ne nous servirons plus on les réutilise pour stocker:
    // Al + Au et Bl + Bu
    Polynomial_add(&Al, &Au);
    Polynomial_add(&Bl, &Bu);

    // On commence par calculer le resultat soit:
    // Resultat = (Al + Au)*(Bl + BU) - D0 - D1
    Polynomial_multiply(&Al, &Bl);
    Polynomial_subtract(&Al, &D0);
    Polynomial_subtract(&Al, &D1);

    // On élève la puissance de Resultat et D1.
    Polynomial_increase(&Al, n);
    Polynomial_increase(&D1, 2*n);

    // Puis on ajoute au résultat D1 et D0
    Polynomial_add(&Al, &D1);
    Polynomial_add(&Al, &D0);

    // On libère la mémoire
    Polynomial_destroy(&D0);
    Polynomial_destroy(&D1);
    Polynomial_destroy(&Au);
    Polynomial_destroy(&Bu);
    Polynomial_destroy(&Bl);

    // On met à jour left et on le retourne.
    *A = Al;
    return A;
}

Polynomial* Polynomial_rawMultiply(Polynomial* left, const Polynomial* right)
{
    // On effectue une multiplication classique en développement la forme A*B.
    Polynomial result = Polynomial_create();
    Monomial* current = LIST_BEGIN_AS(Monomial*, right->monomials);
    while(current != NULL)
    {
        Polynomial left_copy = Polynomial_copy(left);

        Polynomial_add(&result, Polynomial_multiplyByMonomial(&left_copy, current));

        Polynomial_destroy(&left_copy);

        LIST_ADVANCE_AS(Monomial*, current);
    }

    Polynomial_destroy(left);
    *left = result;
    return left;
}

Polynomial* Polynomial_multiplyByMonomial(Polynomial* left, const Monomial* right)
{
    // On parcours chaque monôme de left pour le multiplier par right
    Monomial* current = LIST_BEGIN_AS(Monomial*, left->monomials);
    while(current != NULL)
    {
        Complex_multiply(&current->factor, &right->factor);
        current->exponant += right->exponant;

        Monomial* to_remove = NULL;
        if(current->factor.real == 0 && current->factor.imaginary == 0)
        {
            to_remove = current;
        }

        LIST_ADVANCE_AS(Monomial*, current);

        if(to_remove)
        {
            LIST_REMOVE(left->monomials, to_remove);
        }
    }

    return left;
}

void Polynomial_splitAndReduce(Polynomial* splitted, Polynomial* left, Polynomial* right, int n)
{
    // Pour séparer les monômes on déplace chaque monôme selon la puissance n. Si le monôme à un
    // degré supérieur ou égal à n alors on le met dans left sinon right. Pour effectuer la rédution par n
    // on soustrait à l'exposant n avant de rajouter le polynôme dans left.

    Monomial* current = LIST_POP_FIRST_AS(Monomial*, splitted->monomials);
    while(current != NULL)
    {
        if(current->exponant >= n)
        {
            current->exponant -= n;
            LIST_APPEND_LAST(left->monomials, current);
        }
        else
        {
            LIST_APPEND_LAST(right->monomials, current);
        }

        current = LIST_POP_FIRST_AS(Monomial*, splitted->monomials);
    }
}

void Polynomial_increase(Polynomial* polynomial, int n)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {
        current->exponant += n;

        LIST_ADVANCE_AS(Monomial*, current);
    }
}

Polynomial* Polynomial_multiplyByScalar(Polynomial* left, double right)
{
    Complex right_complex = Complex_create(right, 0);

    Monomial* current = LIST_BEGIN_AS(Monomial*, left->monomials);
    while(current != NULL)
    {
        Complex_multiply(&current->factor, &right_complex);

        LIST_ADVANCE_AS(Monomial*, current);
    }

    return left;
}

Complex Polynomial_evaluate(const Polynomial* polynomial, const Complex* value)
{
    // Pour évaluer un polynôme on utilise la méthode de Horner

    if(polynomial->monomials.len == 0)
    {
        return Complex_create(0., 0.);
    }

    Monomial* current = LIST_LAST_AS(Monomial*, polynomial->monomials);
    Complex result = Complex_create(1., 0.);
    while(current != NULL)
    {
        if(current->node.next == NULL)
        {
            Complex_multiply(&result, &current->factor);
        }
        else
        {
            // Pour compenser la non représentation des monôme à facteur nul on doit
            // calculer l'écart entre chaque monôme et multiplier autant de fois
            // que nécessaire par la valeur évalué.
            int gap = ((Monomial*)current->node.next)->exponant - current->exponant;
            if(gap - 1 > 0)
            {
                Complex copy = *value;
                Complex_multiply(&result, Complex_pow(&copy, gap-1));
            }

            Complex_multiply(&result, value);
            Complex_add(&result, &current->factor);
        }

        LIST_BACK_AS(Monomial*, current);
    }

    int remaining = ((Monomial*)polynomial->monomials.head)->exponant;
    if(remaining > 0)
    {
        Complex copy = *value;
        Complex_multiply(&result, Complex_pow(&copy, remaining));
    }

    return result;
}

Polynomial* Polynomial_derive(Polynomial* polynomial)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {
        Monomial* to_remove = NULL;

        if (current->exponant == 0)
        {
            to_remove = current;
        }
        else
        {
            current->factor.real *= current->exponant;
            current->factor.imaginary *= current->exponant;
            current->exponant = current->exponant - 1;
        }

        LIST_ADVANCE_AS(Monomial*, current);

        if (to_remove != NULL)
        {
            LIST_REMOVE(polynomial->monomials, to_remove);
        }
    }

    return polynomial;
}

Polynomial* Polynomial_integrate(Polynomial* polynomial)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {
        current->exponant = current->exponant + 1;
        current->factor.real /= current->exponant;
        current->factor.imaginary /= current->exponant;

        LIST_ADVANCE_AS(Monomial*, current);
    }

    return polynomial;
}

Polynomial* Polynomial_pow(Polynomial* left, int pow)
{
    // Exponentiation rapide

    if(pow == 0)
    {
        Polynomial_destroy(left);
        Polynomial_addMonomial(left, Monomial_create(Complex_create(1., 0.), 1));

        return left;
    }

    if(pow == 1)
    {
        return left;
    }
    else if(pow % 2 == 0)
    {
        return Polynomial_pow(Polynomial_multiply(left, left), pow/2);
    }
    else
    {
        Polynomial result = Polynomial_copy(left);
        Polynomial_pow(Polynomial_multiply(&result, left), (pow-1)/2);
        Polynomial_multiply(left, &result);

        Polynomial_destroy(&result);
        return left;
    }
}

Polynomial* Polynomial_compose(Polynomial* left, const Polynomial* right)
{
    // La composition repose exactement sur le même principe que l'évaluation
    // cependant au lieu d'évaluer en un point on "évalue" avec un polynôme

    if(right->monomials.len == 0 || left->monomials.len == 0)
    {
        Polynomial_destroy(left);
        return left;
    }

    Polynomial result = Polynomial_create();
    Monomial* monomial_factor = Monomial_create(Complex_create(0., 0.), 0);

    Monomial* current = LIST_LAST_AS(Monomial*, left->monomials);
    while(current != NULL)
    {
        if(current->node.next == NULL)
        {
            LIST_APPEND_LAST(result.monomials, Monomial_create(current->factor, 0));
        }
        else
        {
            int gap = ((Monomial*)current->node.next)->exponant - current->exponant;
            if(gap - 1 > 0)
            {
                Polynomial copy = Polynomial_copy(right);
                Polynomial_multiply(&result, Polynomial_pow(&copy, gap-1));

                Polynomial_destroy(&copy);
            }

            Polynomial_multiply(&result, right);
            monomial_factor->factor = current->factor;
            Polynomial_addMonomial(&result, monomial_factor);
        }

        LIST_BACK_AS(Monomial*, current);
    }

    Monomial_destroy(monomial_factor);

    int remaining = ((Monomial*)left->monomials.head)->exponant;
    if(remaining > 0)
    {
        Polynomial copy = Polynomial_copy(right);
        Polynomial_multiply(&result, Polynomial_pow(&copy, remaining));

        Polynomial_destroy(&copy);
    }

    Polynomial_destroy(left);
    *left = result;
    return left;
}

Polynomial* Polynomial_factoring(Polynomial *polynomial)
{
    // La factorisation repose sur deux méthode:
    // - La première permet de faire des approximations initials
    // - La seconde affine ces approximations

    return Polynomial_Aberth(Polynomial_DurandKerner(polynomial));
}

Polynomial* Polynomial_DurandKerner(Polynomial* polynomial)
{
    if(polynomial->monomials.len == 0)
    {
        return polynomial;
    }

    if(polynomial->roots.len != 0)
    {
        List_clear(&polynomial->roots);
    }

    int degree = ((Monomial*)polynomial->monomials.tail)->exponant;
    int i;


    // Dans C un polynôme de degré n a n racines.
    for(i = 0; i < degree; ++i)
    {
        Complex initial_root = Complex_create(0.9, 0.9);
        Complex_pow(&initial_root, i);
        PolynomialRoot* root = PolynomialRoot_create(initial_root);
        LIST_APPEND_LAST(polynomial->roots, root);
    }

    // La méthode de DurandKerner ne fonctionne qu'avec des polynômes
    // dont leurs degré dominant possède le coefficient 1
    // Si ce n'est pas notre cas on divise tout les monôme pas le coefficient.
    Complex leading = ((Monomial*)polynomial->monomials.tail)->factor;
    if(leading.real != 1 || leading.imaginary != 0)
    {
        Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
        while(current != NULL)
        {
            Complex_divide(&current->factor, &leading);
            LIST_ADVANCE_AS(Monomial*, current);
        }

        ((Monomial*)polynomial->monomials.tail)->factor = Complex_create(1., 0.);
    }

    int max = 20;
    Bool should_continue = True;
    while(should_continue && max)
    {
        PolynomialRoot* current = LIST_BEGIN_AS(PolynomialRoot*, polynomial->roots);
        while(current != NULL)
        {
            Complex dividande = Polynomial_evaluate(polynomial, &current->value);
            Complex divider = Complex_create(1., 0.);

            PolynomialRoot* root = LIST_BEGIN_AS(PolynomialRoot*, polynomial->roots);
            while(root != NULL)
            {
                if(root != current)
                {
                    Complex copy = current->value;
                    Complex_subtract(&copy, &root->value);
                    Complex_multiply(&divider, &copy);
                }

                LIST_ADVANCE_AS(PolynomialRoot*, root);
            }

            Complex new_root_value = current->value;
            Complex_subtract(&new_root_value, Complex_divide(&dividande, &divider));

            Complex copy = current->value;
            Complex_subtract(&copy, &new_root_value);


            // On vérifie si le calcul s'est stabilisé
            if(Complex_module(&copy) < 0.001)
            {
                should_continue = False;
            }

            current->value = new_root_value;

            LIST_ADVANCE_AS(PolynomialRoot*, current);
        }

        max -= 1;
    }

    return polynomial;
}

Polynomial* Polynomial_Aberth(Polynomial* polynomial)
{
    if(polynomial->roots.len == 0)
    {
        return polynomial;
    }


    Polynomial derived = Polynomial_copy(polynomial);
    Polynomial_derive(&derived);

    int max = 20;
    Bool should_countinue = True;
    while(should_countinue && max)
    {
        PolynomialRoot* current = LIST_BEGIN_AS(PolynomialRoot*, polynomial->roots);
        while(current != NULL)
        {
            Complex dividande = Polynomial_evaluate(polynomial, &current->value);

            Complex derived_eval = Polynomial_evaluate(&derived, &current->value);
            Complex_divide(&dividande, &derived_eval);

            Complex divider = Complex_create(1., 0.);

            Complex sum = Complex_create(0., 0.);
            PolynomialRoot* root = LIST_BEGIN_AS(PolynomialRoot*, polynomial->roots);
            while(root != current)
            {
                Complex sub_result = Complex_create(1., 0.);

                Complex current_root_copy = current->value;
                Complex_divide(&sub_result, Complex_subtract(&current_root_copy, &root->value));

                Complex_add(&sum, &sub_result);

                LIST_ADVANCE_AS(PolynomialRoot*, root);
            }

            Complex dividande_copy = dividande;
            Complex_multiply(&dividande_copy, &sum);
            Complex_subtract(&divider, &dividande_copy);

            Complex_divide(&dividande, &divider);
            Complex_add(&current->value, Complex_opposite(&dividande));

            if(Complex_module(&dividande) < 0.00001)
            {
                should_countinue = False;
            }

            LIST_ADVANCE_AS(PolynomialRoot*, current);

        }

        max -= 1;
    }

    Polynomial_destroy(&derived);
    return polynomial;
}


Polynomial* Polynomial_extraction(Polynomial* polynomial, Polynomial* real_part, Polynomial* imaginary_part)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {        
        if(current->factor.real != 0)
        {
            Monomial* real = Monomial_create(Complex_create(current->factor.real, 0), current->exponant);
            LIST_APPEND_LAST(real_part->monomials, real);
        }

        if(current->factor.imaginary != 0)
        {
            Monomial* imaginary = Monomial_create(Complex_create(0, current->factor.imaginary), current->exponant);
            LIST_APPEND_LAST(imaginary_part->monomials, imaginary);

        }

        LIST_ADVANCE_AS(Monomial*, current);
    }

    return polynomial;
}


Polynomial* Polynomial_conjugate(Polynomial* polynomial)
{
    Monomial* current = LIST_BEGIN_AS(Monomial*, polynomial->monomials);
    while(current != NULL)
    {
        Complex_conjugate(&current->factor);

        LIST_ADVANCE_AS(Monomial*, current);
    }

    return polynomial;
}

Polynomial Polynomial_euclideanDivision(Polynomial* left, Polynomial* right, Polynomial* remainder)
{
    if(left->monomials.len == 0 || right->monomials.len == 0)
    {
        return Polynomial_create();
    }

    Polynomial result = Polynomial_create();
    *remainder = Polynomial_copy(left);

    int remainder_degree = Polynomial_maximumDegree(remainder);
    int right_degree = Polynomial_maximumDegree(right);

    do
    {
        Polynomial copy = Polynomial_copy(right);

        Complex factor = ((Monomial*)remainder->monomials.tail)->factor;
        Complex_divide(&factor, &((Monomial*)right->monomials.tail)->factor);
        Monomial* monomial = Monomial_create(factor, remainder_degree - right_degree);

        Polynomial_multiplyByMonomial(&copy, monomial);
        Polynomial_subtract(remainder, &copy);
        Polynomial_addMonomial(&result, monomial);

        Polynomial_destroy(&copy);
        Monomial_destroy(monomial);

        remainder_degree = Polynomial_maximumDegree(remainder);
    }
    while(remainder_degree >= right_degree && remainder->monomials.len > 0);

    return result;
}

Polynomial Polynomial_gcd(Polynomial* left, Polynomial* right)
{
    if(right->monomials.len == 0)
    {
        return Polynomial_copy(left);
    }

    int left_degree = Polynomial_maximumDegree(left);
    int right_degree = Polynomial_maximumDegree(right);

    if(Polynomial_equal(left, right))
    {
        return Polynomial_copy(left);
    }
    else if(left_degree > right_degree)
    {
        return Polynomial_gcd(Polynomial_subtract(left, right), right);
    }
    else
    {
        return Polynomial_gcd(left, Polynomial_subtract(right, left));
    }
}

Bool Polynomial_equal(Polynomial* left, Polynomial* right)
{
    Bool equal = True;

    Monomial* current_left = LIST_BEGIN_AS(Monomial*, left->monomials);
    Monomial* current_right = LIST_BEGIN_AS(Monomial*, right->monomials);
    while(current_left != NULL && current_right != NULL)
    {
        if((current_left->factor.real != current_right->factor.imaginary)
                || (current_left->factor.imaginary != current_right->factor.imaginary))
        {
            equal = False;
            break;
        }

        LIST_ADVANCE_AS(Monomial*, current_left);
        LIST_ADVANCE_AS(Monomial*, current_right);
    }

    return equal;
}
