#include "command.h"
#include "../utils/utility.h"
#include "../utils/list.h"
#include "../polynomial/operations.h"
#include "../polynomial/generator.h"


#include <time.h>
#include <string.h>

Command Command_create(char* command_string)
{
    command_string = String_removeSpaces(command_string);
    INIT_STRING(command_name, MAX_STRING_SIZE);

    sscanf(command_string, "%[^-]", command_name);

    Command command;
    command.as_string = command_string;
    Command_init(&command, command_name);


    return command;
}

void Command_init(Command* command, const char* command_name)
{
    // TODO: A changer avec un pattern processor classique...
    command->type = InvalidCommand;

    if(strcmp(command_name, "eval") == 0)
    {
        command->type = EvaluateCommand;
        command->generic_processor = &Command_processEvaluate;
    }
    else if(strcmp(command_name, "gen") == 0)
    {
        command->type = GenerateCommand;
        command->generic_processor = &Command_processGenerate;
    }
    else if(strcmp(command_name, "save") == 0)
    {
        command->type = SaveCommand;
        command->generic_processor = &Command_processSave;

    }
    else if(strcmp(command_name, "load") == 0)
    {
        command->type = LoadCommand;
        command->generic_processor = &Command_processLoad;
    }
    else if(strcmp(command_name, "set") == 0)
    {
        command->type = SetCommand;
        command->generic_processor = &Command_processSet;
    }
    else if(strcmp(command_name, "display") == 0)
    {
        command->type = DisplayCommand;
        command->generic_processor = &Command_processDisplay;
    }
    else if(strcmp(command_name, "exit") == 0)
    {
        command->type = ExitCommand;
        command->generic_processor = &Command_processQuit;
    }
    else if(strcmp(command_name, "help") == 0)
    {
        command->type = HelpCommand;
        command->generic_processor = &Command_processHelp;
    }
    else if(strcmp(command_name, "clear") == 0)
    {
        command->type = ClearCommand;
        command->generic_processor = &Command_processClear;
    }
    else if(strcmp(command_name, "integrate") == 0)
    {
        command->type = IntegrateCommand;
        command->generic_processor = &Command_processIntegrate;
    }
    else if(strcmp(command_name, "derive") == 0)
    {
        command->type = DeriveCommand;
        command->generic_processor = &Command_processDerive;
    }
    else if(strcmp(command_name, "pow") == 0)
    {
        command->type = PowCommand;
        command->generic_processor = &Command_processPow;
    }
    else if(strcmp(command_name, "exec") == 0)
    {
        command->type = ExecCommand;
        command->generic_processor = &Command_processExec;
    }
    else if(strcmp(command_name, "fact") == 0)
    {
        command->type = FactoringCommand;
        command->generic_processor = &Command_processFactoring;
    }
    else if(strcmp(command_name, "div") == 0)
    {
        command->type = EuclideanCommand;
        command->generic_processor = &Command_processEuclidean;
    }
    else if(strcmp(command_name, "gcd") == 0)
    {
        command->type = GcdCommand;
        command->generic_processor = &Command_processGcd;
    }
    else if(strcmp(command_name, "extract") == 0)
    {
        command->type = ExtractCommand;
        command->generic_processor = &Command_processExtract;
    }
    else if(strcmp(command_name, "conjugate") == 0)
    {
        command->type = ConjugateCommand;
        command->generic_processor = &Command_processConjugate;
    }
    else if(strcmp(command_name, "merenda") == 0)
    {
        command->type = MerendaCommand;
        command->generic_processor = &Command_processMerenda;
    }
    else
    {
        command->arithmetic_pocessor = PolynomialOperation_fromString(command_name);
        if(command->arithmetic_pocessor != NULL)
        {
            command->type = ArithmeticCommand;
        }
    }
}

void Command_process(Application* app, Command* command)
{
    clock_t start = clock();

    if(command->type == InvalidCommand)
    {
        printf("Commande invalide !\n");
    }
    else if(command->type == ArithmeticCommand)
    {
        Command_processArithmetic(app, command);
    }
    else
    {
        command->generic_processor(app, command);
    }

    double duration = (double)(clock() - start)/CLOCKS_PER_SEC;
    printf("\nLa commande s'est executée en %.5lf secondes", duration);
    PRINT_ENDL(); PRINT_ENDL();

}

void Command_processArithmetic(Application* app, Command* command)
{
    INIT_STRING(op_name, MAX_STRING_SIZE);
    INIT_STRING(left_name, MAX_STRING_SIZE);
    INIT_STRING(right_name, MAX_STRING_SIZE);
    INIT_STRING(result_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%[^-]-%[^-]-%[^-]-%s", op_name, left_name, right_name, result_name);

    Polynomial* left = PolynomialSet_find(&app->polynomials, left_name);
    if(left == NULL)
    {
        printf("Le polynôme %s n'existe pas !\n", left_name);
        return;
    }

    Polynomial* right = PolynomialSet_find(&app->polynomials, right_name);
    if(right == NULL)
    {
        printf("Le polynôme %s n'existe pas !\n", right_name);
        return;
    }

    printf("%s %s %s = ", left_name, op_name, right_name);

    if(strlen(result_name) != 0)
    {
        PolynomialEntry* new_entry = PolynomialEntry_create(result_name);
        new_entry->polynomial = Polynomial_copy(left);

        PolynomialSet_insert(&app->polynomials, new_entry);

        command->arithmetic_pocessor(&new_entry->polynomial, right);


        printf("%s(x) = ", result_name);
        Polynomial_displayMonomials(&new_entry->polynomial);
    }
    else
    {
        command->arithmetic_pocessor(left, right);

        printf("%s(x) = ", left_name);
        Polynomial_displayMonomials(left);
    }


}

void Command_processEvaluate(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);
    INIT_STRING(complex_string, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%[^(](%[^)])", polynomial_name, complex_string);

    Polynomial* polynomial = PolynomialSet_find(&app->polynomials, polynomial_name);
    if(polynomial == NULL)
    {
        printf("Le polynôme %s n'existe pas !\n", polynomial_name);
        return;
    }

    double real, imaginary;
    int scan_result = sscanf(complex_string, "%lf,%lf", &real, &imaginary);
    if(scan_result != 2)
    {
        printf("Le nombre complexe %s est invalide !\n", complex_string);
        return;
    }

    Complex complex = Complex_create(real, imaginary);
    Complex result = Polynomial_evaluate(polynomial, &complex);

    printf("%s(%s) = ", polynomial_name, complex_string);
    Complex_display(&result);
    PRINT_ENDL();
}

void Command_processGenerate(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);
    int min_deg = 0;
    int max_deg = 0;
    double density = 0.;

    int result = sscanf(command->as_string, "%*[^-]-%[^[][%d:%d](%lf)",
                        polynomial_name, &min_deg, &max_deg, &density);
    if(result != 4)
    {
        printf("La syntax est invalide !\n");
        return;
    }

    PolynomialEntry* new_entry = PolynomialEntry_create(polynomial_name);
    new_entry->polynomial = PolynomialGenerator_generate(min_deg, max_deg, density);
    PolynomialSet_insert(&app->polynomials, new_entry);

    printf("%s(x) = ", polynomial_name);
    Polynomial_displayMonomials(&new_entry->polynomial);
}

void Command_processSave(Application* app, Command* command)
{
    INIT_STRING(file_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-file=%s", file_name);

    if(strlen(file_name) == 0)
    {
        strcpy(file_name, app->last_file);
    }

    FILE* save_file = fopen(file_name, "w+");
    if(save_file)
    {
        PolynomialSet_printEntries(&app->polynomials, save_file);

        memset(app->last_file, '\0', MAX_STRING_SIZE);
        sprintf(app->last_file, file_name);
        printf("Les polynomes ont été sauvegardés correctement.\n");

        fclose(save_file);
    }
    else
    {
        printf("Impossible d'ouvrir le fichier demandé !\n");
    }
}


void Command_processLoad(Application* app, Command* command)
{
    INIT_STRING(file_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-file=%s", file_name);

    FILE* load_file = fopen(file_name, "r");
    if(load_file)
    {
        PolynomialSet_destroy(&app->polynomials);

        Bool success = False;
        app->polynomials = PolynomialSet_fromFile(load_file, &success);

        if(success == False)
        {
            printf("Une erreur s'est produite dans le chargement du fichier !\n");
        }
        else
        {
            memset(app->last_file, '\0', MAX_STRING_SIZE);
            sprintf(app->last_file, file_name);
            printf("Le fichier s'est chargé correctement.\n");
        }

        fclose(load_file);
    }
    else
    {
        printf("Impossible d'ouvrir d'ouvrir le fichier demandé.");
    }
}


void Command_processSet(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);
    INIT_STRING(polynomial_expression, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%[^=]=%s", polynomial_name, polynomial_expression);

    if(strlen(polynomial_name) == 0)
    {
        printf("Le nom de polynôme est invalide !\n");
        return;
    }

    if(strlen(polynomial_expression) == 0)
    {
        printf("L'expression d'un polynôme ne peux pas être nulle !\n");
        return;
    }

    Bool success = False;
    PolynomialEntry* new_entry = PolynomialEntry_create(polynomial_name);
    new_entry->polynomial = Polynomial_fromString(polynomial_expression, &success);

    if(success)
    {
        PolynomialSet_insert(&app->polynomials, new_entry);
        printf("Le polynome a bien été enregistré !\n");
    }
    else
    {
        PolynomialEntry_destroy(new_entry);
        printf("\n\nIl y a une erreur de syntax !\n");
    }
}

void Command_processDisplay(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%s", polynomial_name);

    if(strlen(polynomial_name) != 0)
    {
        PolynomialEntry* entry = PolynomialSet_findEntry(&app->polynomials, polynomial_name);

        if(entry != NULL)
        {
            PolynomialEntry_display(entry);
        }
        else
        {
            printf("Le polynôme n'existe pas !\n");
        }
    }
    else
    {
        PolynomialSet_displayEntries(&app->polynomials);
    }
}


void Command_processQuit(Application* app, Command* command)
{
    UNUSED(command);

    app->should_quit = True;
}


void Command_processHelp(Application* app, Command* command)
{
    UNUSED(app);
    UNUSED(command);

    printf("Les commandes disponibles sont les suivantes:\n\n");

    printf("# Les commandes arithmétiques\n");
    printf("# Elles s'écrivent sous la forme operation -p1 -p2 [-Résultat]\n");
    printf("# Si Résultat n'est pas spécifié alors p1 prend le résultat.\n");
    printf("\t-> add/sub pour additionner/soustraire.\n");
    printf("\t-> cmul/mul pour multiplier sans ou avec karatsuba.\n\n");

    printf("# Les opérations sur un seul polynôme\n");
    printf("\t-> eval -p1(x,yi) pour faire une évaluation.\n");
    printf("\t-> derive -p1 pour faire une dérivation.\n");
    printf("\t-> integrate -p1 pour faire une integration.\n");
    printf("\t-> conjugate -p1 pour faire une conjugaison.\n");
    printf("\t-> integrate -p1 pour faire une évaluation.\n");
    printf("\t-> extract -p1 pour faire une extraction.\n");
    printf("\t-> fact -p1 pour faire une factorisation.\n");
    printf("\t-> pow -p1^n pour faire une puissance n.\n\n");

    printf("# Les opérations avec syntax différentes\n");
    printf("\t-> div -p1 -p2 -quotient -reste pour une division\n");
    printf("\t-> gcd -p1 -p2 -result pour calculer le PGCD\n\n");

    printf("# Les commandes utilitaires\n");
    printf("\t-> display [-p1] pour afficher un polynôme,\n");
    printf("\t  si aucun polynôme n'est spécifié tous les polynômes sont affichés.\n");
    printf("\t-> set -p1=(x, y)x^d + ... pour enregistrer un polynôme.\n");
    printf("\t-> gen -p1[deg_min:deg_max](densité) pour générer un polynôme aléatoire.\n");
    printf("\t-> load/save -file=fichier pour charger/sauvegarder les polnyômes.\n");
    printf("\t-> exec -file=fichier pour executer un fichier.\n");
    printf("\t-> clear pour nettoyer la console.\n");

    printf("\t-> exit pour quitter.\n\n");
}


void Command_processClear(Application* app, Command* command)
{
    UNUSED(app);
    UNUSED(command);

    CLEAR();
    Command_processHelp(app, command);
}

void Command_processIntegrate(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%s", polynomial_name);

    PolynomialEntry* entry = PolynomialSet_findEntry(&app->polynomials, polynomial_name);
    if(entry == NULL)
    {
        printf("Le polynôme specifié n'existe pas !\n");
        return;
    }

    Polynomial_integrate(&entry->polynomial);
    printf("primitive(%s)=", entry->name);
    Polynomial_displayMonomials(&entry->polynomial);
}

void Command_processDerive(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%s", polynomial_name);

    PolynomialEntry* entry = PolynomialSet_findEntry(&app->polynomials, polynomial_name);
    if(entry == NULL)
    {
        printf("Le polynôme specifié n'existe pas !\n");
        return;
    }

    Polynomial_derive(&entry->polynomial);
    printf("%s'(x)=", entry->name);
    Polynomial_displayMonomials(&entry->polynomial);
}

void Command_processPow(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);
    int pow = 0;

    sscanf(command->as_string, "%*[^-]-%[^^]^%d", polynomial_name, &pow);

    PolynomialEntry* entry = PolynomialSet_findEntry(&app->polynomials, polynomial_name);
    if(entry == NULL)
    {
        printf("Le polynôme specifié n'existe pas !\n");
        return;
    }

    Polynomial_pow(&entry->polynomial, pow);
    printf("%s^%d=", entry->name, pow);
    Polynomial_displayMonomials(&entry->polynomial);
}

void Command_processExec(Application* app, Command* command)
{
    INIT_STRING(file_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-file=%s", file_name);

    FILE* load_file = fopen(file_name, "r");
    if(load_file)
    {
        char* line = NULL;
        size_t n = 0;
        while(String_getLine(&line, &n, load_file) != -1)
        {
            printf("##############################################\n");
            printf("# %s", line);
            printf("##############################################\n\n");

            Command current_command = Command_create(line);
            Command_process(app, &current_command);

            printf("Appuyez sur une touche pour la prochaine commande...");
            getc(stdin);
            fflush(stdin);
        }

        free(line);
        fclose(load_file);

        printf("##############################################\n");
    }
    else
    {
        printf("Impossible d'ouvrir d'ouvrir le fichier demandé.");
    }

}

void Command_processFactoring(Application* app, Command* command)
{
    INIT_STRING(polynomial_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%s", polynomial_name);

    PolynomialEntry* entry = PolynomialSet_findEntry(&app->polynomials, polynomial_name);
    if(entry == NULL)
    {
        printf("Le polynôme specifié n'existe pas !\n");
        return;
    }

    // On fait une copie du polynôme pour pas le modifier
    Polynomial copy = Polynomial_copy(&entry->polynomial);
    Polynomial_factoring(&copy);

    entry->polynomial.roots = copy.roots;
    List_clear(&copy.monomials);

    printf("%s(x)=", entry->name);
    Polynomial_displayRoots(&entry->polynomial);
}

void Command_processEuclidean(Application* app, Command* command)
{
    INIT_STRING(left_name, MAX_STRING_SIZE);
    INIT_STRING(right_name, MAX_STRING_SIZE);
    INIT_STRING(remainder_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%[^-]-%[^-]-%s", left_name, right_name, remainder_name);

    if(strlen(remainder_name) == 0)
    {
        printf("Le polynôme reste doit avoir un nom !");
        return;
    }

    Polynomial* left = PolynomialSet_find(&app->polynomials, left_name);
    Polynomial* right = PolynomialSet_find(&app->polynomials, right_name);

    if(left == NULL || right == NULL)
    {
        printf("Un des deux polynômes n'existe pas !\n");
        return;
    }

    PolynomialEntry* remainder = PolynomialEntry_create(remainder_name);
    PolynomialEntry* result = PolynomialEntry_create(command->as_string);

    result->polynomial = Polynomial_euclideanDivision(left, right, &remainder->polynomial);

    PolynomialSet_insert(&app->polynomials, result);
    PolynomialSet_insert(&app->polynomials, remainder);

    printf("%s/%s = (", left_name, right_name);
    Polynomial_displayMonomials(&result->polynomial);
    printf(") * (");
    Polynomial_displayMonomials(right);
    printf(") + ");
    Polynomial_displayMonomials(&remainder->polynomial);
}

void Command_processGcd(Application* app, Command* command)
{
    INIT_STRING(left_name, MAX_STRING_SIZE);
    INIT_STRING(right_name, MAX_STRING_SIZE);
    INIT_STRING(gcd_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%[^-]-%[^-]-%s", left_name, right_name, gcd_name);

    if(strlen(gcd_name) == 0)
    {
        printf("Le polynôme PGCD doit avoir un nom !");
        return;
    }

    Polynomial* left = PolynomialSet_find(&app->polynomials, left_name);
    Polynomial* right = PolynomialSet_find(&app->polynomials, right_name);

    if(left == NULL || right == NULL)
    {
        printf("Un des deux polynômes n'existe pas !\n");
        return;
    }

    PolynomialEntry* result = PolynomialEntry_create(command->as_string);
    Polynomial left_copy = Polynomial_copy(left);
    Polynomial right_copy = Polynomial_copy(right);

    result->polynomial = Polynomial_gcd(&left_copy, &right_copy);

    Polynomial_destroy(&left_copy);
    Polynomial_destroy(&right_copy);

    PolynomialSet_insert(&app->polynomials, result);

    printf("%s PGCD %s =", left_name, right_name);
    Polynomial_displayMonomials(&result->polynomial);
}

void Command_processConjugate(Application* app, Command* command)
{
    INIT_STRING(conjugated_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%s", conjugated_name);

    Polynomial* conjugated = PolynomialSet_find(&app->polynomials, conjugated_name);
    if(conjugated == NULL)
    {
        printf("Le polynôme n'existe pas !");
        return;
    }

    Polynomial_conjugate(conjugated);

    printf("Conjugated %s = ", conjugated_name);
    Polynomial_displayMonomials(conjugated);
}

void Command_processExtract(Application* app, Command* command)
{
    INIT_STRING(extracted_name, MAX_STRING_SIZE);

    sscanf(command->as_string, "%*[^-]-%s", extracted_name);

    Polynomial* extracted = PolynomialSet_find(&app->polynomials, extracted_name);
    if(extracted == NULL)
    {
        printf("Le polynôme n'existe pas !");
        return;
    }

    INIT_STRING(realp_name, MAX_STRING_SIZE);
    strcat(realp_name, "Reel(");
    strcat(realp_name, extracted_name);
    strcat(realp_name, ")");

    INIT_STRING(imp_name, MAX_STRING_SIZE);
    strcat(imp_name, "Im(");
    strcat(imp_name, extracted_name);
    strcat(imp_name, ")");

    PolynomialEntry* real = PolynomialEntry_create(realp_name);
    PolynomialEntry* im = PolynomialEntry_create(imp_name);

    Polynomial_extraction(extracted, &real->polynomial, &im->polynomial);

    PolynomialSet_insert(&app->polynomials, real);
    PolynomialSet_insert(&app->polynomials, im);

    printf("%s = ", realp_name);
    Polynomial_displayMonomials(&real->polynomial);

    printf("\n%s = ", imp_name);
    Polynomial_displayMonomials(&im->polynomial);
}

void Command_processMerenda(Application* app, Command* command)
{
    UNUSED(app);
    UNUSED(command);

    time_t raw_time; time(&raw_time);
    struct tm *tm = localtime(&raw_time);
    int hours = tm->tm_hour;
    int minutes = tm->tm_min;

    if(hours == (-10000+10016) && minutes >= (-10000+10030))
    {
        printf("C'est l'heure du gouter\n");
    }
    else
    {
        printf("Ce n'est pas l'heure du gouter, attendez 16h30");
        printf(" et pas 16h comme monsieur Bauchart le ferait.\n");
    }

}
