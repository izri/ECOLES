#include "utility.h"
#include "bool.h"

#include <ctype.h>
#include <string.h>
#include <stdio.h>

char* String_removeSpaces(char* str)
{
    unsigned int i, j;
    char* out = str;

    for(i = 0, j = 0; i < strlen(str); i++,j++)
    {
        // Si le charactère est un espace alors on décale l'assignation
        if(isspace(str[i]))
        {
            j -= 1;
        }
        else
        {
            out[j] = str[i];
        }
    }

    // On n'oublie pas de mettre à jour la position du EOT de la nouvelle chaine de charactère.
    out[j] = '\0';
    return out;
}


char* String_sep(char** strgp, const char* delimiters)
{
    // On se déplace jusqu'au premier delimiter trouvé
    char* start = *strgp;
    char* p = (start != NULL) ? strpbrk(start, delimiters) : NULL;

    if(p == NULL)
    {
        *strgp = NULL;
    }
    else
    {
        *p = '\0';
        *strgp = p + 1;
    }

    return start;
}


ssize_t String_subString(char** substr, size_t* substr_size, FILE* stream, char terminator, int offset)
{

    int available_chars; // L'espace restant dans le buffer *substr
    char* read_pos; // Position dans le stream

    if(substr == NULL || substr_size == NULL || stream == NULL)
    {
        return -1;
    }

    // Si le buffer n'est pas alloué on alloue une zone initiale
    if(*substr == NULL)
    {
        *substr_size = MIN_CHUNCK_SIZE;
        *substr = (char*)malloc(*substr_size*sizeof(char));

        if(*substr == NULL)
        {
            return -1;
        }
    }

    available_chars = *substr_size - offset;
    read_pos = *substr + offset;
    while(True)
    {
        register int current = getc(stream);

        // Le buffer doit être supérieur à deux pour au moins avoir
        // un charactère plus le EOT
        if(available_chars < 2)
        {
            if(*substr_size > MIN_CHUNCK_SIZE)
            {
                *substr_size *= 2;
            }
            else
            {
                *substr_size += MIN_CHUNCK_SIZE;
            }

            available_chars = *substr_size + *substr - read_pos;
            *substr = (char*)realloc(*substr, *substr_size);
            if(*substr == NULL)
            {
                return -1;
            }

            read_pos = *substr_size - available_chars + *substr;
        }

        if(current == EOF || ferror(stream))
        {
            if(read_pos == *substr)
            {
                return -1;
            }
            else
            {
                break;
            }
        }

        *read_pos++ = current;
        available_chars -= 1;

        if(current == terminator)
        {
            break;
        }
    }

    *read_pos = '\0';
    return read_pos - (*substr + offset);
}

ssize_t String_getLine(char** substr, size_t* substr_size, FILE* stream)
{
    return String_subString(substr, substr_size, stream, '\n', 0);
}

int Int_sup(int left, int right)
{
    return (left > right) ? left : right;
}

int Int_inf(int left, int right)
{
    return (left < right) ? left : right;
}
