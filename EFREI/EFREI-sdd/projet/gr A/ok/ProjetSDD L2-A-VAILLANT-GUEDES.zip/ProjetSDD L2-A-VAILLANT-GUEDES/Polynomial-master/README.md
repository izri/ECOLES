Polynomial
==========

## Etat du projet

- [x] Interface Graphique
  - [x] Affichage interactif
  - [x] Création des polynômes en ligne de commande
  - [x] Chargement/Sauvegarder des polynômes créés
  - [x] Visualisation des polynômes
  - [x] Opérations depuis la ligne de commande
  - [x] Génération aléatoire d'un polynôme
  - [x] Execution fichier script
- [x] Structures
  - [x] Réprésentation des polynômes
  - [x] Liste générique
  - [x] Nombre complexe
- [ ] Opération
  - [x] Addition
  - [x] Soustraction
  - [x] Multiplication (Karatsuba)
  - [x] Factorisation
  - [x] Evaluation
  - [x] TODO: Tests complets Division euclidienne
  - [x] Integration
  - [x] Derivation
  - [x] Composition
  - [x] Extraction
  - [x] Conjugaison
  - [x] BUG: approximation double => boucle infinie PGCD
  - [ ] Decomposition

## Améliorations urgentes
 - Meilleur gestion des commandes
 - ~~Adapter Karatsuba pour les puissances négatives~~
 - ~~Meilleur affichage des opérations dans la console~~
 - ~~Mesure du temps d'execution des commandes~~

## Références
  - http://en.wikipedia.org/wiki/Main_Page
  - https://eprint.iacr.org/2006/224.pdf (Karatsuba)
  - Cours SDD
