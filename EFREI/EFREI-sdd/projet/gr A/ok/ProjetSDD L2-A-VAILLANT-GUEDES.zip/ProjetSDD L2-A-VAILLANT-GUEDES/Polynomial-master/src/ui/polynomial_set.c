#include "polynomial_set.h"
#include "../utils/utility.h"

#include <stdio.h>
#include <string.h>

PolynomialSet PolynomialSet_create()
{
    PolynomialSet set;
    set.polynomials = List_create(PolynomialEntry_freeHandler);

    return set;
}

PolynomialSet PolynomialSet_fromFile(FILE* stream, Bool* success)
{
    // On récupère chaque ligne du fichier puis on cré les entrée à l'aide
    // de la fonction PolynomialEntry_fromString.
    PolynomialSet set = PolynomialSet_create();
    *success = True;

    char* line = NULL;
    size_t n = 0;
    int count = 1;
    while(String_getLine(&line, &n, stream) != -1)
    {
        PolynomialEntry* new_entry = PolynomialEntry_fromString(line);

        if(new_entry == NULL)
        {
            printf("Erreur de syntax ligne %d", count);
            *success = False;
            break;
        }

        PolynomialSet_insert(&set, new_entry);
    }
    free(line);

    return set;
}

Polynomial* PolynomialSet_find(PolynomialSet* set, const char* name)
{
    PolynomialEntry* entry = PolynomialSet_findEntry(set, name);

    if(entry != NULL)
    {
        return &entry->polynomial;
    }
    else
    {
        return NULL;
    }
}

PolynomialEntry* PolynomialSet_findEntry(PolynomialSet* set, const char* name)
{
    PolynomialEntry* current = LIST_BEGIN_AS(PolynomialEntry*, set->polynomials);
    while(current != NULL)
    {
        if(strcmp(current->name, name) == 0)
        {
            return current;
        }

        LIST_ADVANCE_AS(PolynomialEntry*, current);
    }

    return NULL;
}

void PolynomialSet_insert(PolynomialSet* set, PolynomialEntry* entry)
{
    PolynomialEntry* current = LIST_BEGIN_AS(PolynomialEntry*, set->polynomials);
    while(current != NULL)
    {
        if(strcmp(current->name, entry->name) == 0)
        {
            LIST_APPEND_AFTER(set->polynomials, current, entry);
            LIST_REMOVE(set->polynomials, current);
            return;
        }

        LIST_ADVANCE_AS(PolynomialEntry*, current);
    }

    LIST_APPEND_LAST(set->polynomials, entry);
}

void PolynomialSet_displayEntries(PolynomialSet* set)
{
    PolynomialEntry* current = LIST_BEGIN_AS(PolynomialEntry*, set->polynomials);

    if(current == NULL)
    {
        printf("Il n'y a aucun polynome enregistré.\n");
        return;
    }

    printf("Les polynômes enregistrés sont: \n\n");
    while(current != NULL)
    {
        PolynomialEntry_display(current);
        LIST_ADVANCE_AS(PolynomialEntry*, current);
    }

}

void PolynomialSet_printEntries(PolynomialSet* set, FILE* target)
{
    PolynomialEntry* current = LIST_BEGIN_AS(PolynomialEntry*, set->polynomials);

    if(current == NULL)
    {
        printf("Il n'y a aucun polynôme à sauvegarder.");
        return;
    }

    while(current != NULL)
    {
        PolynomialEntry_print(current, target);
        fprintf(target, "\n");

        LIST_ADVANCE_AS(PolynomialEntry*, current);
    }
}

void PolynomialSet_destroy(PolynomialSet* set)
{
    List_clear(&set->polynomials);
}
