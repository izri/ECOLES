#ifndef GENERATOR_H
#define GENERATOR_H

#include "polynomial.h"

/**
 * @brief PolynomialGenerator_generate Génère un polynôme aléatoire
 *
 * La densité représente la probabilité pour un monôme d'apparaître dans le polynome
 * final.
*/
Polynomial PolynomialGenerator_generate(int min_deg, int max_deg, double density);

#endif // GENERATOR_H
