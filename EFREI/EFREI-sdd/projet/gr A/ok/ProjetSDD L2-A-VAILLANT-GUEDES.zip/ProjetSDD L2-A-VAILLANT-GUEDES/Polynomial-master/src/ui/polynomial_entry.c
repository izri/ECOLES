#include "polynomial_entry.h"
#include "../utils/utility.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

PolynomialEntry* PolynomialEntry_create(const char* name)
{
    PolynomialEntry* entry = (PolynomialEntry*)malloc(sizeof(PolynomialEntry));
    entry->node = ListNode_create();
    entry->name = strdup(name);
    entry->polynomial = Polynomial_create();

    return entry;
}

PolynomialEntry* PolynomialEntry_fromString(char* str)
{
    // Pour décomposer la chaine de charactère on sépare la chaine de charactère en deux
    // suivant le délimiteur ':' puis on utilise la fonction Polynomial_fromString.

    char* name = String_sep(&str, ":");
    char* polynomial_str = String_sep(&str, ":");

    if(name == NULL
       || polynomial_str == NULL
       || strcmp(name, "") == 0
       || strcmp(polynomial_str, "") == 0)
    {
        return NULL;
    }

    Bool success = True;
    Polynomial polynomial = Polynomial_fromString(polynomial_str, &success);

    if(success == False)
    {
        return NULL;
    }

    PolynomialEntry* entry = (PolynomialEntry*)malloc(sizeof(PolynomialEntry));
    entry->node = ListNode_create();
    entry->name = strdup(name);
    entry->polynomial = polynomial;

    return entry;
}

void PolynomialEntry_display(PolynomialEntry* entry)
{
    printf("##################################");
    PRINT_ENDL();

    // On centre l'affichage du nom.
    int name_len = strlen(entry->name);
    int name_start = (33 - name_len)/2;
    int i;
    for(i = 0; i < name_start; ++i)
    {
        printf(" ");
    }

    printf("%s", entry->name);
    PRINT_ENDL();

    printf("##################################");
    PRINT_ENDL();
    PRINT_ENDL();

    printf("Forme développée: \n ");
    Polynomial_displayMonomials(&entry->polynomial);
    PRINT_ENDL();
    PRINT_ENDL();

    printf("Forme factorisée: \n ");
    Polynomial_displayRoots(&entry->polynomial);
    PRINT_ENDL();
}

void PolynomialEntry_print(PolynomialEntry* entry, FILE* target)
{
    fprintf(target, "%s:", entry->name);
    Polynomial_printMonomials(&entry->polynomial, target);
}

void PolynomialEntry_destroy(PolynomialEntry* entry)
{
    free(entry->name);
    Polynomial_destroy(&entry->polynomial);
    free(entry);
}


void PolynomialEntry_freeHandler(ListNode* node)
{
    PolynomialEntry_destroy((PolynomialEntry*)node);
}
