#ifndef COMMAND_H
#define COMMAND_H

#include "application.h"
#include "../polynomial/polynomial.h"
#include "../utils/bool.h"
#include "../utils/complex.h"

// Ce fichier contient toute les commandes de l'interface utilisateur

typedef enum CommandType
{
    ArithmeticCommand,
    EvaluateCommand,
    GenerateCommand,
    SaveCommand,
    LoadCommand,
    SetCommand,
    DisplayCommand,
    ExitCommand,
    HelpCommand,
    ClearCommand,
    IntegrateCommand,
    DeriveCommand,
    PowCommand,
    ExecCommand,
    FactoringCommand,
    EuclideanCommand,
    GcdCommand,
    ConjugateCommand,
    ExtractCommand,
    MerendaCommand,
    InvalidCommand
} CommandType;

struct Command;
typedef Polynomial* (*ArithmeticProcessor)(Polynomial*, const Polynomial*);
typedef void (*GenericProcessor)(Application* app, struct Command* command);

typedef struct Command
{
    CommandType type;
    const char* as_string;

    union {
        GenericProcessor generic_processor;
        ArithmeticProcessor arithmetic_pocessor;
    };
} Command;

Command Command_create(char* command_string);
void Command_init(Command* command, const char* command_name);
void Command_initAsArithmetic(Command* command, const char* command_name);

void Command_process(Application* app, Command* command);
void Command_processArithmetic(Application* app, Command* command);
void Command_processEvaluate(Application* app, Command* command);
void Command_processGenerate(Application* app, Command* command);
void Command_processSave(Application* app, Command* command);
void Command_processLoad(Application* app, Command* command);
void Command_processSet(Application* app, Command* command);
void Command_processDisplay(Application* app, Command* command);
void Command_processQuit(Application* app, Command* command);
void Command_processHelp(Application* app, Command* command);
void Command_processClear(Application* app, Command* command);
void Command_processIntegrate(Application* app, Command* command);
void Command_processDerive(Application* app, Command* command);
void Command_processPow(Application* app, Command* command);
void Command_processExec(Application* app, Command* command);
void Command_processFactoring(Application* app, Command* command);
void Command_processEuclidean(Application* app, Command* command);
void Command_processGcd(Application* app, Command* command);
void Command_processConjugate(Application* app, Command* command);
void Command_processExtract(Application* app, Command* command);
void Command_processMerenda(Application* app, Command* command);

#endif // COMMAND_H
