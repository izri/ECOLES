#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED

/**
  * @brief Représentation d'un nombre complexe
*/
typedef struct Complex
{
    double real;
    double imaginary;
} Complex;

/**
 * @brief Complex_create Cré une une variable complexe avec un réel et un imaginaire donnés
 */
Complex Complex_create(double real, double imaginary);

/**
 * @brief Complex_display Affiche un nombre complexe
 */
void Complex_display(const Complex* complex);

/**
 * @brief Complex_add Ajoute deux nombres complexe.
*/
Complex* Complex_add(Complex* left, const Complex* right);

/**
 * @brief Complex_subtract Soustrait deux nombres complexe
 */
Complex* Complex_subtract(Complex* left, const Complex* right);

/**
 * @brief Complex_multiply Multiplie deux nombres complexe
 */
Complex* Complex_multiply(Complex* left, const Complex* right);

/**
 * @brief Complex_divide  Divise deux nombres complexe
 */
Complex* Complex_divide(Complex* left, const Complex* right);

/**
 * @brief Complex_conjugate Retourne le conjugué du nombre complexe
 */
Complex* Complex_conjugate(Complex* complex);

/**
 * @brief Complex_opposite Retourne l'opposé du nombre complexe
 */
Complex* Complex_opposite(Complex* complex);

/**
 * @brief Complex_module Retourne le module du nombre complexe
 */
double Complex_module(Complex* complex);

/**
 * @brief Complex_arg Retourne l'argument du nombre complexe
 */
double Complex_arg(Complex* complex);

/**
 * @brief Complex_pow Elève à la puissance pow le nombre complexe
*/
Complex* Complex_pow(Complex* complex, int pow);

#endif // COMPLEX_H_INCLUDED
