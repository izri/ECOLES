#include "complex.h"

#include <stdio.h>
#include <math.h>

Complex Complex_create(double real, double imaginary)
{
    Complex complex;
    complex.real = real;
    complex.imaginary = imaginary;

    return complex;
}


void Complex_display(const Complex* complex)
{
    printf("%.3lf + %.3lfi", complex->real, complex->imaginary);
}

Complex* Complex_add(Complex* left, const Complex* right)
{
    left->real += right->real;
    left->imaginary += right->imaginary;

    return left;
}


Complex* Complex_subtract(Complex* left, const Complex* right)
{
    left->real -= right->real;
    left->imaginary -= right->imaginary;

    return left;
}



Complex* Complex_multiply(Complex* left, const Complex* right)
{
    // On se base sur le développement de la forme (x+iy)(x'+iy')

    Complex result;

    result.real = (left->real*right->real) - (left->imaginary*right->imaginary);
    result.imaginary = (left->real*right->imaginary) + (left->imaginary*right->real);

    left->real = result.real;
    left->imaginary = result.imaginary;

    return left;
}


Complex* Complex_divide(Complex* left, const Complex* right)
{
    // On se base sur le développment de la forme (x+iy)(x-iy')/(x'+iy')(x'-iy')

    Complex result;

    double divider = right->real*right->real + right->imaginary*right->imaginary;
    result.real = (left->real*right->real + left->imaginary*right->imaginary)/divider;
    result.imaginary = (left->imaginary*right->real - left->real*right->imaginary)/divider;

    left->real = result.real;
    left->imaginary = result.imaginary;

    return left;
}

Complex* Complex_conjugate(Complex* complex)
{
    complex->imaginary *= -1;
    return complex;
}

Complex* Complex_opposite(Complex* complex)
{
    complex->real *= -1;
    complex->imaginary *= -1;

    return complex;
}


double Complex_module(Complex* complex)
{
    // Le module du nombre complexe correspond à une application de la norme euclidienne
    return sqrt(complex->real*complex->real + complex->imaginary*complex->imaginary);
}


double Complex_arg(Complex* complex)
{
    if(complex->real < 0 && complex->imaginary == 0)
    {
        return 2*atan(complex->imaginary/(complex->real + Complex_module(complex)));
    }

    return 2*atan(complex->imaginary/(complex->real + M_PI));
}


Complex* Complex_pow(Complex* complex, int pow)
{
    if(pow == 0)
    {
        complex->real = 1.;
        complex->imaginary = 0.;
        return complex;
    }

    if(pow == 1)
    {
        return complex;
    }
    else if(pow % 2 == 0)
    {
        return Complex_pow(Complex_multiply(complex, complex), pow/2);
    }
    else
    {
        Complex copy = *complex;
        Complex_pow(Complex_multiply(&copy, &copy), (pow-1)/2);
        return Complex_multiply(complex, &copy);
    }
}
