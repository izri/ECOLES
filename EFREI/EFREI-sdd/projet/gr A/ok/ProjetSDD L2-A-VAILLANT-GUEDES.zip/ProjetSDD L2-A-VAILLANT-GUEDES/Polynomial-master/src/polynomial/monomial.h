#ifndef MONOMIAL_H
#define MONOMIAL_H

#include "../utils/list.h"
#include "../utils/complex.h"

/**
 * @brief Réprésentation d'un monôme à l'aide de son facteur
 * et de son degré.
 *
 * Cette structure peut être chainée avec Monomial_freeHandler
*/
typedef struct Monomial
{
    ListNode node;

    Complex factor;
    int exponant;
} Monomial;

/**
 * @brief Monomial_create Crée un mônome avec un facteur et un degré donné
 */
Monomial* Monomial_create(Complex factor, int exponant);

/**
 * @brief Monomial_fromString Crée un mônome depuis une chaine de charactère
 *
 * La chaine de charactère doit être du type (x, y)x^d
 */
Monomial* Monomial_fromString(char* monomial_string);

/**
 * @brief Monomial_copy Copie un mônome
 */
Monomial* Monomial_copy(Monomial* other);

/**
 * @brief Monomial_destroy Supprime un mônome
 */
void Monomial_destroy(Monomial* monomial);

/**
 * @brief Monomial_freeHandler Même utilité que Monomial_destroy mais est utilisé
 * par la @sa List générique.
 */
void Monomial_freeHandler(ListNode* monomial);

#endif // MONOMIAL_H
