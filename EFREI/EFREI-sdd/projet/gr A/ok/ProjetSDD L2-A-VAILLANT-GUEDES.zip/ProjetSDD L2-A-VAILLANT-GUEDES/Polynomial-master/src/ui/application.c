#include "application.h"
#include "../utils/bool.h"
#include "command.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

Application Application_create()
{
    Application app;
    app.polynomials = PolynomialSet_create();
    app.should_quit = False;
    memset(app.last_file, '\0', MAX_STRING_SIZE);
    sprintf(app.last_file, "temp.poly");

    return app;
}

int Application_run(Application* app)
{
    srand(time(NULL));
    Application_displayMenu(app);
    return Application_destroy(app);
}

void Application_displayMenu(Application* app)
{
    printf("##############################################\n");
    printf("#                Polynomial                  #\n");
    printf("##############################################\n\n");

    Command dummy_command;
    Command_processHelp(app, &dummy_command);

    while(!app->should_quit) {
        fflush(stdout);
        fflush(stdin);

        INIT_STRING(head, MAX_STRING_SIZE);
        sprintf(head, "[polynomial@%s]$ ", app->last_file);

        ASK_LINE(head, command_string);

        PRINT_ENDL();

        Command command = Command_create(command_string);
        Command_process(app, &command);

        PRINT_ENDL();
    }

    printf("\nAppuyez sur Entrée pour continuer...");
    fgetc(stdin);
}

int Application_destroy(Application* app)
{
    PolynomialSet_destroy(&app->polynomials);

    return 0;
}
