#ifndef COMPLEXE_H_INCLUDED
#define COMPLEXE_H_INCLUDED

#include "include.h"





complexe addition_complexe(complexe ,complexe);
complexe soustraction_complexe(complexe x1,complexe x2);
complexe multiplication_complexe(complexe x1,complexe x2);
complexe division_complexe(complexe x1,complexe x2);

complexe multiplication_complexe_reel(complexe x1,float x2);
complexe division_complexe_reel(complexe x1,float x2);

complexe valeurnegative(complexe x);
complexe ncomplexe(float reel,float imaginaire);
float reel(complexe );
float imag(complexe );
complexe complexeConjugue(complexe c);

void afficher_complexe(complexe valeur);
#endif // COMPLEXE_H_INCLUDED
