#include "utilitaire.h"

char* saisie_dynamique_char()
{
    int i=0,t_util=0;
    char* texte=NULL,tab[TAILLE_MAX];

    for(i=0;i<TAILLE_MAX;i++){tab[i]=0;}

    fgets(tab, sizeof tab, stdin);

    do{t_util++;}while(tab[t_util]>0);
    t_util--;tab[t_util]=3;

    texte=(char*)malloc(sizeof(char)*(t_util+1));

    for(i=0;i<t_util;i++)//transforme les espace est apostrophe en _
        {
            if(tab[i]==32   || tab[i]=='\'')
            {
             tab[i]='_';
            }

         texte[i]=tab[i];
        }

return(texte);
}


int puissance_10(int j)
{int i;
int resultat=1;
    for(i=0;i<j;i++)
    {
        resultat=resultat*10;
    }
  return resultat;
}

int saisie_entier()
{int nombre=0;

    int i=0,j;
    char tab[TAILLE_MAX];

    int t_util=0;

    //on initialise tous a 0
    for(i=0;i<TAILLE_MAX;i++){tab[i]=0;}

    fgets(tab, sizeof tab, stdin);

    do{t_util++;}while(tab[t_util]>='0' && tab[t_util]<='9');


    int limite=0;
    for(j=0;j<t_util;j++)
        {limite++;
        if(limite==5){return 0;}

        nombre+=(tab[j]-'0')*puissance_10(t_util-j-1);

        }

return nombre;
}



void saut_ligne(int nb_saut)
{int i;
for(i=0;i<nb_saut;i++){printf("\n");}}


int longueur_entier(int i)
{int longueur=1;
    while(i>9)
    {longueur++;
     i=i/10;
    }
  return  longueur;
}

char* convertir_entier_chaine(int entrer)
{
    char* sortie;

    int longueur=0,i;

    longueur=longueur_entier(entrer);
    longueur++;
    sortie=(char*)malloc(longueur*sizeof(char));

    for(i=0;i<longueur;i++)
        {
         sortie[longueur-i]='0'+ entrer%10;
         entrer=entrer/10;
        }

    return sortie;
}

float racine_carre(float nombre)
{
int i;
float valeur=nombre;
    for(i=0;i<16;i++)
        {if(valeur!=0)
            {valeur=((valeur*valeur)+nombre)/(2*valeur);}
        else
            {valeur=0;}
        }
return valeur;
}

float cosinus(float x)
{float somme,xcarre,valeur;
  long i,compteur;

	 x=modulo(x, 2*PI);
	 somme = 1;
	 xcarre = x*x;
	 valeur = 1;
	 i = 1;
    compteur=0;
	do
	{
    valeur=-(valeur*xcarre)/(i*(i+1));
    somme=somme+valeur;
    i+=2;
    compteur++;
	}
	while(compteur<31);

	return somme;
}

float modulo(float x, float diviseur)
{   float sommeultat;
sommeultat=x-diviseur*((long)(x/diviseur));
	return sommeultat;
}


float exponentiel(float entre)
{

// a faire //BUGGER
	float somme = 1;
	float valeur = 1;
	float i = 1.0;
	do
	{
		valeur *= entre/i;
		somme += valeur;
		i++;
	} while (fonctionabsoluereel(valeur)>31.0);
	return somme;
}

int choix_binaire()
{
    int resultat=saisie_securiser_entier(0,10000);
    if(resultat==1)
        {
            return 1;
        }
    else
        {
            return 0;
        }

}

int saisie_securiser_entier(int min ,int max)
{int resultat=min-1;


    do{

    if(resultat!=min-1 )
        {
         printf("\n La valeur %d n'est pas autoriser mettre entre %d et %d.",resultat,min,max);
         resultat=min-1;
        }
        printf("\n choix:");
        resultat=saisie_entier();

    if(resultat<min || resultat>max)
        {resultat=min-1;}


    }while(resultat==min-1);


return resultat;
}


float fonctionabsoluereel(float nombre){if(nombre<0){nombre=-nombre;}return nombre;}
int fonctionabsolueentier(int nombre){if(nombre<0){nombre=-nombre;}return nombre;}
