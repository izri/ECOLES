#ifndef INCLUDE_H_INCLUDED
#define INCLUDE_H_INCLUDED

//On definit les structures et les includes lors du premier passage , le reste du temps cette page est ignorer


    #ifndef COMPLEXE
        typedef struct complexe
        {
           float reel,imag;
        }complexe;

        #define COMPLEXE 1
    #endif

        #ifndef MONOME
            typedef struct monome
            {
            complexe valeur;
            int puissance;
            struct monome* suivant;
            struct monome* precedent;
            }monome;
            #define MONOME 1
        #endif


    #ifndef POLYNOME_DEV
        typedef struct polynome_dev
        {
          monome *tete;
          monome *queu;
        }polynome_dev;
        #define POLYNOME_DEV 1
    #endif

    #ifndef FACTEUR
       typedef struct facteur
            {
                complexe *valeur;
                struct facteur* suivant;
                struct facteur* precedent;
            }facteur;

        #define FACTEUR 1
    #endif

    #ifndef POLYNOME_FAC
       typedef struct polynome_fac
            {
                facteur *facteur;
                struct polynome_fac* suivant;
                struct polynome_fac* precedent;
            }polynome_fac;
        //typedef struct polynome_fac* polynome_fac;
        #define POLYNOME_FAC 1
    #endif


    #ifndef POLYNOME
        typedef struct polynome
        {
        polynome_dev developper;
        //polynome_fac factoriser;
        }polynome;
        #define POLYNOME 1
    #endif

//-----------------------------------------------------------------------------------
#ifndef INCLUDE

  #define INCLUDE 1

    #include <stdio.h>
    #include <stdlib.h>

    #include "utilitaire.h"
    #include "complexe.h"

    #include "gestion_polynome.h"


    #include "operation_mathematique.h"

    #include "affichage.h"

#endif //FIN des include






#endif // INCLUDE_H_INCLUDED
