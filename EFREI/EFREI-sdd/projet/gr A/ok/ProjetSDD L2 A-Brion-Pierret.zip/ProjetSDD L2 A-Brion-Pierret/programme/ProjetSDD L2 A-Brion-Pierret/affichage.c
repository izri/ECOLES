#include "affichage.h"


//le programme principal
void programme()
{//���!!!!!!!!!
int choix;
polynome_dev* poly;
polynome_dev* poly1;
polynome_dev* poly2;


    do{system("cls");




   printf("\n--------------------------------------------------------------");
   printf("\n----Traitement de polynomes de nombres complexes--------------");
   printf("\n--------------------------------------------------------------\n\n");


 choix=choix_action();


//------------------------------------------------------------------------------
// addition soustraction multiplication
//------------------------------------------------------------------------------
if(1<=choix && choix<=3)
    {


        printf("\n 1:saisie manuelle de polynome \n 2: generation automatique de polynome ");

        poly1=choix_creation_dev(choix_binaire());
        afficher_polynome_dev(poly1);

        //system("cls");

        printf("\n 1:saisie manuelle de polynome \n 2: generation automatique de polynome ");

        poly2=choix_creation_dev(choix_binaire());

    //------------------------------------------------------------------------------



    poly=operation(poly1, poly2, choix);

	system("cls");
        printf("\n premier polynome");
        afficher_polynome_dev(poly1);
        printf("\n second polynome");
        afficher_polynome_dev(poly2);
        printf("\n resultat operation");
        afficher_polynome_dev(poly);

        desalouer_polynome_dev(poly1);
        desalouer_polynome_dev(poly2);
        desalouer_polynome_dev(poly);
    }
else if(4<=choix && choix<=5)//a completer
    {
        printf("\n 1:saisie manuelle de polynome \n 2: generation automatique de polynome ");

        poly1=choix_creation_dev(choix_binaire());
        afficher_polynome_dev(poly1);
        poly=operation(poly1, NULL, choix);

	system("cls");
    printf("\n  polynome");
    afficher_polynome_dev(poly1);

    printf("\n resultat operation");
    afficher_polynome_dev(poly);

    desalouer_polynome_dev(poly1);
    desalouer_polynome_dev(poly);

    }
else if(6==choix )
	{
	 complexe point;
	 polynome_dev* resultat;
	 poly1=choix_creation_dev(choix_binaire());

	 printf("\n saisir la valeur du point");
    printf("\n Quel est la valeur  reel, ? :");

        scanf(" %f",&point.reel);

     printf("\n Quel est la valeur  imaginaire? :");
        scanf(" %f",&point.imag);

	afficher_polynome_dev(poly1);

    resultat=evaluation_ponctuelle(poly1,point);
	afficher_polynome_dev(resultat);

	}
else
    {printf("\nWARNING");}
    //system("cls");






//------------------------------------------------------------------------------



desalouer_polynome_dev(poly1);
desalouer_polynome_dev(poly2);
desalouer_polynome_dev(poly);

printf("\n\n\n Operation effectuee");

    printf("\n1:sortir ");

    }while(0==choix_binaire());
}



int choix_action()
{
    int choix;
    printf(" \nChoix operation:");
    printf(" \n   1:addition ");
    printf(" \n   2:soustraction ");
    printf(" \n   3:multiplication");
    printf(" \n   4:derivation");
    printf(" \n   5:integration\n");
	printf(" \n   6:evaluation en un point\n");

    choix=saisie_securiser_entier(1,6);

return choix;
}

polynome_dev* operation(polynome_dev* poly1,polynome_dev* poly2,int choix)
{//���
    polynome_dev* resultat;
     if(choix==1)
        {
        printf("\n ------------Addition-------------------------- \n");
         resultat=additionnerPolynome(poly1,poly2);
         afficher_polynome_dev(resultat);
        }
    else if (choix==2)
        {
        printf("\n ------------Soustraction---------------------- \n");
         resultat=soustrairePolynome(poly1,poly2);
        }
    else if (choix==3)
        {
        printf("\n ------------Multiplication-------------------- \n");
        resultat=multiplication_classic(poly1,poly2);
        }
    else if (choix==4)
        {
        printf("\n ------------deriver-------------------- \n");
        resultat=deriver(poly1);
        }
    else if (choix==5)
        {
        printf("\n ------------integrer-------------------- \n");
        resultat->tete=integrer(poly1->tete);
        }

return resultat;
}


polynome_dev * choix_creation_dev(int choix)
{//����
polynome_dev * resultat;
int longueur=0;

    if(choix==1)
        {
        resultat=creation_manuelle();
        }
    else
        {
        printf("\n  nombre de termes du polynome:?\n ");
        longueur=saisie_securiser_entier(0,100);
        resultat=creation_auto(longueur,4);
        }


    return resultat;
}

void tester_polydev(polynome_dev * poly,int a)
{
    printf("\n %d =%d",a,(int)poly);
    printf("\n %d tete=%d",a,(int)poly->tete);
    printf("\n %d queu=%d \n",a,(int)poly->queu);
}

void afficher_polynome_dev(polynome_dev* poly)
{
    if(poly==NULL ||poly->tete==NULL)
        {printf("\n Polynome vide");
         return;
         }
printf("\n ---------------------------------- ");
monome * tampon=poly->tete;
int compteur=0;
    while(tampon!=NULL)
        {

        if(tampon==poly->tete)
            {
             printf("\n ");
            }
            else
            {
            printf("\n ");
            }


            if(tampon->valeur.reel>0.0)
                    {
                     printf("+%.1f ",tampon->valeur.reel);
                    }
            else if (tampon->valeur.reel<0.0)
                    {
                    printf("%.1f ",tampon->valeur.reel);
                    }
            else    {}

             if(tampon->valeur.imag>0.0)
                    {
                     printf("+%.1f i",tampon->valeur.imag);
                    }
            else if (tampon->valeur.imag<0.0)
                    {
                    printf("%.1f  i",tampon->valeur.imag);
                    }
            else    {}

            printf(") X^%d",tampon->puissance);

          tampon=tampon->suivant;

        compteur++;
        }
printf("\n ---------------------------------- ");
}


