#ifndef OPERATION_MATHEMATIQUE_H_INCLUDED
#define OPERATION_MATHEMATIQUE_H_INCLUDED
#include "include.h"


polynome_dev* deriver(polynome_dev* poly);//d�rive un polynome //bon
 polynome_dev* integrer(polynome_dev*poly);//int�gre un polynome //bon


//multiplication de deux polynomes de maniere non obtimiser
polynome_dev* multiplication_classic(polynome_dev* polynome1,polynome_dev* polynome2);


//operation arithmetique sur les polynome
//addition
polynome_dev* additionnerPolynome(polynome_dev *premierPolynome,polynome_dev *secondPolynome);
polynome_dev* soustrairePolynome(polynome_dev *premierPolynome,polynome_dev *secondPolynome);
polynome_dev* negativ_polynome_dev (polynome_dev* poly);

int choix_puissance(monome* p1,monome* p2);

int longueur_polynome(monome* poly);

int puissancemonome(monome* poly);

polynome_dev* multiplication_Polynome_complexe(polynome_dev* poly,complexe valeur);

monome* extraireImgPolynome(monome* p);
monome* extraireReelPolynome(monome* p);


//non terminer
//void diviserPolynome(monome *dividende,monome *diviseur,monome *resultat,monome *reste);
//monome* polynomeConjugue(monome *p);
//monome* devPol(struct polFact *pf);

polynome_dev* copie_polynome_dev(polynome_dev* polynome);

complexe evaluation_ponctuelle(polynome_dev* poly,complexe point);

#endif // OPERATION_MATHEMATIQUE_H_INCLUDED
