#include "operation_mathematique.h"


//d�rive un polynome
polynome_dev* deriver(polynome_dev* poly1)
{
    polynome_dev* poly=copie_polynome_dev(poly1);
    polynome_dev* resultat=initialiser_polynome_dev();
    monome* tampon = poly->tete;

    if(poly->tete->puissance==0)
        {poly=retirer_maillon(poly,poly->tete);}

	while(tampon != NULL)
	{
	resultat->queu=passage_au_suivant(resultat->queu);
		if(resultat->tete==NULL)
            {resultat->tete=resultat->queu;}


		resultat->queu->valeur = multiplication_complexe_reel(tampon->valeur,tampon->puissance);
		resultat->queu->puissance = tampon->puissance-1;

		tampon = tampon->suivant;
	}

	return resultat;
}

//int�gre un polynome
 polynome_dev* integrer(polynome_dev* poly)
{

    polynome_dev* resultat=initialiser_polynome_dev();

    monome* tampon = poly->tete;

	while(tampon != NULL)
	{


		resultat->queu=passage_au_suivant(resultat->queu);
		if(resultat->tete==NULL)
            {resultat->tete=resultat->queu;}

		resultat->queu->valeur = division_complexe_reel(tampon->valeur,tampon->puissance);
		resultat->queu->puissance = tampon->puissance+1;
		tampon = tampon->suivant;
	}

	return resultat;
}


polynome_dev* multiplication_classic(polynome_dev* polynome1,polynome_dev* polynome2)
{
    polynome_dev* resultat=initialiser_polynome_dev();
    monome* p1=polynome1->tete;
    monome* p2=polynome2->tete;


    while(p1!=NULL)
        {p2=polynome2->tete;

            while(p2!=NULL)
            {
                if(p1==polynome1->tete && p2==polynome2->tete )
                    {
                        resultat->queu=allouer_monome();
                        resultat->tete=resultat->queu;

                    }
                else
                    {

                    resultat->queu=passage_au_suivant(resultat->queu);

                    }

               if(p1->puissance!=0 &&p2->puissance!=0)
                    {
                      resultat->queu->puissance=p1->puissance*p2->puissance;
                    }
               else if(p1->puissance!=0 )
                   {
                    resultat->queu->puissance=p1->puissance;
                   }
               else
                   {
                    resultat->queu->puissance=p2->puissance;
                   }

               resultat->queu->valeur=multiplication_complexe(p1->valeur,p2->valeur);

               p2=p2->suivant;
            }
        p1=p1->suivant;
        }

    resultat=ordonne_polynome_dev(resultat);

    return resultat;
}


polynome_dev* soustrairePolynome(polynome_dev *p1,polynome_dev *p2)
{
    p2=negativ_polynome_dev(p2);
    p1=additionnerPolynome(p1,p2);
return p1;
}

polynome_dev* negativ_polynome_dev (polynome_dev* poly)
{
    monome* tampon=poly->tete;
    while(tampon!=NULL)
    {
        tampon->valeur=valeurnegative(tampon->valeur);

      tampon=tampon->suivant;
    }


    return poly;
}




polynome_dev* copie_polynome_dev(polynome_dev* polynome)
{
    polynome_dev* resultat=initialiser_polynome_dev();
    monome * tampon=polynome->tete;

    while(tampon!=NULL)
    {

        resultat->queu=passage_au_suivant(resultat->queu);
        resultat->queu->puissance=tampon->puissance;
        resultat->queu->valeur=tampon->valeur;

        if(resultat->tete==NULL)
            {
             resultat->tete=resultat->queu;
            }


        tampon=tampon->suivant;
    }



    return resultat;
}


polynome_dev* additionnerPolynome(polynome_dev *poly1,polynome_dev *poly2)
{

     polynome_dev* resultat;


     polynome_dev* copiep1=copie_polynome_dev(poly1);
     polynome_dev* copiep2=copie_polynome_dev(poly2);

  if(copiep1->tete!=NULL && copiep2->tete!=NULL)
    {
    copiep1->queu->suivant=copiep2->tete;
    copiep2->tete->precedent=copiep1->queu;

     resultat=ordonne_polynome_dev(copiep1);
    }
    else if (copiep1->tete!=NULL)
        {return copiep1;}
    else if (copiep2->tete!=NULL)
        {return copiep2;}
    else
    {
        return 0;
    }


return resultat;
}

int longueur_polynome(monome* poly)
{int compteur=0;
while (poly->suivant!=0)
    {
    compteur++;
     poly=poly->suivant;
    }
return compteur;
}

int choix_puissance(monome* p1,monome* p2)
{int resultat=-123;

    if(p1->puissance>1000){printf("\n WARNING p1");}
    else if(p2->puissance>1000){printf("\n WARNING p2");}

    else if (p1->puissance>p2->puissance) {resultat=p2->puissance; }
    else if (p1->puissance<p2->puissance) {resultat=p1->puissance;}
    else if (p1->puissance==p2->puissance){resultat=p1->puissance; }
    else   {printf("\n WARNING");}

   return  resultat;
}

int puissancemonome(monome* poly)
{
  if(poly<0)
      {if(poly->puissance<0)
        {
            printf("\n mauvaise puissance");
            return 0;
        }
      }

   return poly->puissance;

}


polynome_dev* multiplication_Polynome_complexe(polynome_dev* poly,complexe valeur)
{
monome* tampon=poly->tete;

    while(tampon!=NULL)
        {
           tampon->valeur=multiplication_complexe(tampon->valeur,valeur);

          tampon=tampon->suivant;
        }

return poly;
}

//extrait la partie r�elle d'un polynome
monome* extraireReelPolynome(monome* p)
{
	while(p != NULL)
	{
		p->valeur.imag = 0;
		p=p->suivant;
	}
	return p;
}

//extrait la partie imaginaire d'un polynome
monome* extraireImgPolynome(monome* p)
{
	while(p != NULL)
	{
		p->valeur.imag = 0;
		p=p->suivant;
	}
	return p;
}

complexe evaluation_ponctuelle(polynome_dev* poly,complexe point)
{//a tester normalment bon
    //AX^3+BX^2+CX+D=X(X(AX+B)+C)+D

    monome* tampon=poly->queu;
    complexe valeur=ncomplexe(0,0);
    int puissance_actuelle=poly->queu;

    while(tampon!=NULL)
        {
            if(puissance_actuelle==tampon->puissance)
               {

                     if(tampon->puissance==0)
                            {valeur=tampon->valeur;}
                        else
                            {
                             valeur=multiplication_complexe(valeur,point);
                             valeur=addition_complexe(valeur,tampon->valeur);
                            }

                    tampon=tampon->precedent;
              }
            else
                { valeur=multiplication_complexe(valeur,point);}
        }

    return valeur;
}


// la suite n'est pas terminer ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// non terminer
/*
void diviserPolynome(monome *dividende,monome *diviseur,monome *resultat,monome *reste)
{// non terminer
	monome *p;
	complexe divCoeff;
	int diffDegre;
	supprimerPolynome(resultat);
	supprimerPolynome(reste);
	while(degrePolynome(diviseur) > degrePolynome(dividende))
	{
        	divCoeff = div2comp(dividende->valeur,diviseur->valeur);
        	diffDegre = dividende->puissance - diviseur->puissance;
		supprimerPolynome(p);
		p = copier(diviseur);
		expPol(p,diffDegre);
		multPolComp(p,divCoeff);
		sousPol(dividende,p);


        resultat=passage_au_suivant(resultat);

		resultat->valeur = divCoeff;
		resultat->puissance = dividende->puissance - diviseur->puissance;
	}
	resultat->suivant = NULL;
	reste = dividende;

}


//renvoie le conjugu� d'un polynome
monome* polynomeConjugue(monome *p)
{
	while(p != NULL)
	{
		p->valeur = complexeConjugue(p->valeur);
	}
	return p;
}

//d�veloppe un polynome factoris�
monome* devPol(struct polFact *pf)
{//a modifier structure
	monome *res,*intermediaire;
	complexe c;
	intermediaire = malloc(sizeof(monome));
	intermediaire->precedent = NULL;
	intermediaire->suivant = malloc(sizeof(monome));
	intermediaire->suivant->precedent = intermediaire;
	res = NULL;
	while(pf != NULL)
	{
		intermediaire->valeur = multCompReel(pf->valeur,-1);
		intermediaire->puissance = 0;
		c.reel = 1;
		c.imag = 0;
		intermediaire->suivant->valeur = c;
		intermediaire->suivant->puissance = 1;
		res = multiplication_classique(res,intermediaire);
		pf = pf->suivant;
	}
	return res;
}



//----------------------------------------------------------
//retourne le degre d'un polynome
int degrePolynome(monome* p)
{
	int i = 0;
	while(p->suivant != NULL)
	{
		if(p->puissance > i)
		{
			i = p->puissance;
		}
		p = p->suivant;
	}
	return i;
}

//�leve � la puissance un polynome(avec exponentiation rapide)
void expPol(monome* P,int puissance)
{
	struct monome* Q;
	Q = P;
	while(puissance > 1)
	{
		P = mult2pol(P,P);
		if(puissance % 2 == 1)
		{
			P = mult2pol(P,Q);
			puissance--;
		}
		puissance /= 2;
	}
}
*/
