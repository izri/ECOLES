#ifndef AFFICHAGE_H_INCLUDED
#define AFFICHAGE_H_INCLUDED
#include "include.h"



//fonction interface a faire
void programme();


void tester_polydev(polynome_dev * poly,int a);
void afficher_polynome_dev(polynome_dev* poly);


polynome_dev* operation(polynome_dev* poly1,polynome_dev* poly2,int choix);
polynome_dev * choix_creation_dev(int choix);
int choix_action();

void afficherPolFact(struct polFact p);

#endif // AFFICHAGE_H_INCLUDED
