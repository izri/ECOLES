#include "gestion_polynome.h"


polynome_dev* initialiser_polynome_dev()
{
     polynome_dev* poly=(polynome_dev*)malloc(sizeof(polynome_dev));
     poly->queu=NULL;
     poly->tete=NULL;
     return poly;
}

int desalouer_polynome_dev(polynome_dev* polynome)
{

 monome* tampon=polynome->tete;

    while(polynome->tete!=0)
        {
            polynome->tete=polynome->tete->suivant;
            free(tampon);
        }

    free(polynome);
    return 0;
}

polynome_dev* retirer_maillon(polynome_dev * poly,monome* maillon)
{
    if(poly->tete==maillon)
        {poly->tete=maillon->suivant;

            if(poly->tete!=NULL)
                {poly->tete->precedent=NULL;}
        }
    else
       {if(maillon->suivant!=NULL)
            {maillon->suivant->precedent=maillon->precedent;}
        }


//-------------------------------------------------------------------
    if(poly->queu==maillon)
        {poly->queu=maillon->precedent;

        if(poly->queu!=NULL)
            {poly->queu->suivant=NULL;}
        }
    else
        {
            if(maillon->precedent!=NULL)
                {maillon->precedent->suivant=maillon->suivant;}
        }


    free(maillon);

   return  poly;
}

polynome_dev* creation_auto(int longueur,int i)
{
    polynome_dev* poly=initialiser_polynome_dev();
     monome* tete=allouer_monome();
    monome* variable=tete;
    poly->tete=tete;
    poly->queu=tete;
    int puissance;
    float tmp;
    longueur++;
   for(puissance=0;puissance<longueur;puissance++)
   {
    tmp=1+puissance*i;
    if(tmp!=0.0)
        {if(puissance==0)
            {tete->suivant=0;
             tete->precedent=0;
             tete->valeur.reel=tmp;
             tete->valeur.imag=tmp+2;
             tete->puissance=0;
            }
        else
            {monome* tampon=(monome*)malloc(sizeof(monome));
            variable->suivant=tampon;
            tampon->suivant=0;
            tampon->precedent=variable;
            tampon->valeur.reel=tmp;
            tampon->valeur.imag=tmp+2;
            tampon->puissance=puissance;
            variable=variable->suivant;

            poly->queu=tampon;
            }
        }
   }

tete->puissance=0;//corrige un bug d'initiation de puissance , a voir pour corrige plus tot





//poly=ordonne_polynome_dev(poly);
    return poly;
}

polynome_dev* creation_manuelle()
{
    polynome_dev * poly=initialiser_polynome_dev();



    do{
    afficher_polynome_dev(poly);
       poly->tete=passage_au_suivant(poly->tete);






        if(poly->tete==NULL)
        {printf("\n warning");
        poly->tete=poly->queu;}

        printf("\n continuer ?mettre 1 =");

    }while(choix_binaire());


poly=ordonne_polynome_dev(poly);
    return poly;
}

monome* allouer_monome()
{//alloue et initialise

    monome* nouveau=(monome*)malloc(sizeof(monome));
    nouveau->precedent=NULL;
    nouveau->suivant=NULL;
    nouveau->valeur.reel=0;
    nouveau->valeur.imag=0;
    nouveau->puissance=-1;


    return nouveau;
}

monome* passage_au_suivant(monome* polynome)
{
    monome* resultat=allouer_monome();
    if(polynome==NULL)
        {
          return resultat;
        }

        resultat->precedent=polynome;
        polynome->suivant=resultat;
        resultat->suivant=NULL;


    return resultat;
}
//----------------------------------
polynome_dev* ordonne_polynome_dev(polynome_dev* poly)
{

    polynome_dev * ordonner;
    monome* tampon=poly->tete;



    int actuelle=-2,suivante=-2,max=-2;


    if(poly->tete==NULL)//polynome vide
            {return  NULL;}
    else if(poly->tete==poly->queu)//polynoe singleton
            {return poly; }

//on parcour le polynome pour connaittre la puissance la plus faible


    while(tampon!=NULL)
    {
    if(actuelle==-2)//premier passage
       {
        actuelle=tampon->puissance;
       }
    else if(suivante==-2)//second passage
        {
              if(actuelle<tampon->puissance)
                {
                suivante=tampon->puissance;
                }
            else //actuelle>tampon->puissance
                {
                  suivante=actuelle;
                  actuelle=tampon->puissance;
                }
        }
    else if(tampon->puissance<actuelle)
        { suivante=actuelle;
         actuelle=tampon->puissance; }
    else if (tampon->puissance<suivante)
        {suivante=tampon->puissance;}
//-----------------------------------------------------------
    if(tampon->puissance>max)
        {max=tampon->puissance; }

    tampon=tampon->suivant;
    }


//----------------------------------------------------------
//on ordonner la liste par puissance coissante
ordonner=tordonner( poly, actuelle , suivante, max );




  return  ordonner;
}


polynome_dev* tordonner(polynome_dev* poly,int actuelle ,int suivante,int max )
{    polynome_dev * ordonner=initialiser_polynome_dev();


    int permutation;
    monome* tampon=poly->tete;
    monome* tampon2=NULL;
    //ordre actuelle<min<suivante<...<max

    //on permute actuelleet suivant
    permutation=actuelle;
    actuelle=suivante;
    suivante=permutation;

     while(poly->queu!=NULL && poly->tete!=NULL)
    {
    ordonner->queu=passage_au_suivant(ordonner->queu);

    if(ordonner->tete==NULL)
        {
        ordonner->tete=ordonner->queu;
        }


    actuelle=suivante;
    suivante=max;
    ordonner->queu->puissance=actuelle;
    ordonner->queu->valeur=ncomplexe(0,0);

    tampon=poly->tete;

        while(tampon!=0)
            {
                if(tampon->puissance==actuelle)
                    {
                    ordonner->queu->valeur=addition_complexe(ordonner->queu->valeur,tampon->valeur);
                    tampon2=tampon;
                    tampon=tampon->suivant;


                    poly=retirer_maillon(poly,tampon2);



                    }

                else if(tampon->puissance<suivante)
                    {
                      suivante=tampon->puissance;
                      tampon=tampon->suivant;
                    }
                else
                    {

                    tampon=tampon->suivant;
                    }

            }

    }
    //puis on retir tous les monomes nul
tampon=ordonner->tete;
while(tampon!=NULL)
    {
        if(tampon->valeur.imag==0.0 && tampon->valeur.reel==0.0)
         {
             if(tampon->precedent!=NULL)
                {
                tampon2=tampon->precedent;
                    ordonner=retirer_maillon(ordonner,tampon);
                tampon=tampon2->suivant;
                }
            else
                {
                ordonner=retirer_maillon(ordonner,tampon);
                tampon=ordonner->tete;
                }
         }
         else
            {tampon=tampon->suivant;}


    }




 free(poly);

	return ordonner;
	}


polynome_dev* filer_monome(polynome_dev* poly)
{

  monome* variable;

//creation de la nouvelle case
    if(poly->tete==NULL)
        {
         variable=allouer_monome();
         poly->tete=variable;
         poly->queu=poly->tete;
        }
    else
        {
            variable->suivant=NULL;
          variable=passage_au_suivant(poly->queu);
        }

//remplissage des valeurs


      printf("\n Quel est la puissance ? :");
      variable->puissance=saisie_securiser_entier(0,1000);


    printf("\n Quel est la valeur de X reel, pour X^%d ? :",variable->puissance);

        scanf(" %f",&variable->valeur.reel);

     printf("\n Quel est la valeur de X imaginaire, pour X^%d ? :",variable->puissance);
        scanf(" %f",&variable->valeur.imag);


 return poly;
}
