#ifndef GESTION_POLYNOME_H_INCLUDED
#define GESTION_POLYNOME_H_INCLUDED

#include "include.h"

polynome_dev* initialiser_polynome_dev();
monome* allouer_monome();
monome* passage_au_suivant(monome* polynome);

polynome_dev* creation_auto(int longueur,int i);
polynome_dev* creation_manuelle();

polynome_dev* ordonne_polynome_dev(polynome_dev* poly);
polynome_dev* tordonner(polynome_dev* poly,int actuelle ,int suivante,int max );



polynome_dev* retirer_maillon(polynome_dev * poly,monome* maillon);
int desalouer_polynome_dev(polynome_dev* polynome);
polynome_dev* filer_monome(polynome_dev* poly);
#endif // GESTION_POLYNOME_H_INCLUDED
