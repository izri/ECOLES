Aucune inspiration autre que les cours de mathematique (karatsuba mais n'est pas present 
dans le programme final puisqu'on n'a pas reussi � le mettre en place).

Toutes les fonction relative au nombre complexe sont finis et fonctionnel.

Les fonctions relativent au polynome factoriser ne sont pas tres aboutie.


Les fonction de gestion des polynome developper sont finis et fonctionnel
Les op�rations mathematique sur les polynome developper sont basic mais fonctionnel(non optimiser).





