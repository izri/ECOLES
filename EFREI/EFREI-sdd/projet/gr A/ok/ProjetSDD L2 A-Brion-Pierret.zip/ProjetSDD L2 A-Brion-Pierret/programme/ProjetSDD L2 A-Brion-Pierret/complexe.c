#include "complexe.h"


complexe addition_complexe(complexe x1,complexe x2)
{
    x1.reel+=x2.reel;
    x1.imag+=x2.imag;
  return x1;
}

complexe soustraction_complexe(complexe x1,complexe x2)
{
    x1.reel-=x2.reel;
    x1.imag-=x2.imag;
  return x1;
}

complexe multiplication_complexe(complexe x1,complexe x2)
{   complexe resultat;
    resultat.reel=(x1.reel*x2.reel)-(x1.imag*x2.imag);
    resultat.imag=(x1.reel*x2.imag)+(x1.imag*x2.reel);
  return resultat;
}

complexe multiplication_complexe_reel(complexe x1,float x2)
{
    x1.reel=x1.reel*x2;
    x1.imag=x1.imag*x2;
  return x1;
}

complexe division_complexe_reel(complexe x1,float x2)
{
    if(x2!=0)
        {
        x1.reel=x1.reel/x2;
        x1.imag=x1.reel/x2;
        }
    else
        {
        x1.reel=0;
        x1.imag=0;
        }

  return x1;
}
complexe division_complexe(complexe x1,complexe x2)
{
    x1.reel=((x1.reel*x2.reel)-(x1.imag*x2.imag))/((x2.reel*x2.reel)-(x2.imag*x2.imag));
    x1.imag=((x2.reel*x1.imag)-(x1.reel*x2.imag))/((x2.reel*x2.reel)-(x2.imag*x2.imag));

  return x1;
}


complexe valeurnegative(complexe x)
{   x.reel=-x.reel;
    x.imag=-x.imag;
    return x;
}

complexe ncomplexe(float x,float y)
{complexe resultat;
resultat.reel=x;
resultat.imag=y;

 return resultat;
}

void afficher_complexe(complexe valeur)
{
    printf(" (%.1f+%.1fi)",valeur.reel,valeur.imag);

}



float reel(complexe valeur)
{return valeur.reel;}

float imag(complexe valeur)
{return valeur.imag;}

complexe complexeConjugue(complexe c)
{
	c.imag = -c.imag;
	return c;
}



