#ifndef UTILITAIRE_H_INCLUDED
#define UTILITAIRE_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define TAILLE_MAX 10000
#define PI 3.14159265359

//fonction utilitaire general

char* saisie_dynamique_char();
int puissance_10(int j);

int saisie_entier();
void saut_ligne(int nb_saut);
int longueur_entier(int i);
char* convertir_entier_chaine(int entrer);
float racine_carre(float nombre);
float cosinus(float x);
float modulo(float x, float diviseur);
float exponentiel(float entre);
int saisie_securiser_entier(int ,int );

float fonctionabsoluereel(float nombre);
int fonctionabsolueentier(int nombre);
int choix_binaire();
#endif // UTILITAIRE_H_INCLUDED



