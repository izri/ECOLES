#include "Polynome.h"

int main()
{
    int confirmation = 0;
    int choix = 0;
    Polynomial *p1 = malloc(sizeof(*p1));
    Polynomial *p2 = malloc(sizeof(*p2));
    iniDeveloppe(p1);
    iniDeveloppe(p2);
    while (confirmation == 0)
    {
        printf("Que souhaitez-vous faire?\n");
        printf("1/Additionner les deux polynomes\n");
        printf("2/Soustraire les deux polynomes\n");
        printf("3/Multiplier les deux polynomes\n");
        scanf("%d", &choix);
        if(choix == 1 || choix == 2 || choix == 3)
        {
            confirmation = 1;
        }
        else
        {
            printf("Saisie incorrecte\n");
        }
    }
    if(choix == 1)
    {
        addition(p1, p2);
    }
    if(choix == 2)
    {
        soustraction(p1, p2);
    }
    if(choix == 3)
    {
        multiplication(p1 , p2);
    }
    return 0;
}
