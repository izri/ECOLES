#ifndef POLYNOME_H_INCLUDED
#define POLYNOME_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

//Description d'un maillon de la LSC relative � la forme d�velop�e
typedef struct MaillonDev
{
    double reel;
    double im;
    int degre;
    struct MaillonDev *suiv;
}MaillonDev;

//D�fintion du type polynomial, contenant les deux formes d'un polyn�me
typedef struct Polynomial
{
    MaillonDev *premierDev;
}Polynomial;


void iniDeveloppe(Polynomial *polynome);
void affichageDev(Polynomial *polynome);
void addition(Polynomial *poly1 , Polynomial *poly2);
void soustraction(Polynomial *poly1 , Polynomial *poly2);
void multiplication(Polynomial *poly1 , Polynomial *poly2);
MaillonDev *LSCpremier(double reel, double im, int degre, Polynomial *polynome);
MaillonDev *LSCsuivant(double reel, double im, int degre, MaillonDev *adressePrec);

//Fonction permettant la cr�ation d'un polyn�me d�velopp�

void iniDeveloppe(Polynomial *polynome)
{
    int degreImput;
    double coefReel;
    double coefIm;
    MaillonDev *curr;
    int Pmaillon = 0; //bool�en d�tectant si c'est le premier maillon de la cha�ne ou pas
    polynome->premierDev = NULL;
    printf("Degre de votre polynome?\n");
    scanf("%d", &degreImput);
    for(degreImput=degreImput ; degreImput>=0 ; degreImput=degreImput-1)
    {
        printf("Entrer le coefficient reel de degre %d\n" , degreImput);
        scanf("%lf", &coefReel);
        printf("Entrer le coefficient immaginaire de degre %d\n" , degreImput);
        scanf("%lf", &coefIm);
        if(coefReel != 0)
        {
            if(Pmaillon == 1)
            {
                MaillonDev *nouvMaillon = malloc(sizeof(*nouvMaillon));
                nouvMaillon->reel = coefReel;
                nouvMaillon->im = coefIm;
                nouvMaillon->degre = degreImput;
                curr->suiv = nouvMaillon;
                curr = nouvMaillon;
            }
            if(Pmaillon == 0)
            {
                MaillonDev *premierMaillon = malloc(sizeof(*premierMaillon));
                curr = premierMaillon;
                premierMaillon->reel = coefReel;
                premierMaillon->im = coefIm;
                premierMaillon->degre = degreImput;
                polynome->premierDev = premierMaillon;
                Pmaillon = 1;
            }
        }
    }
    if (Pmaillon == 1)
    {
        curr->suiv = NULL;
    }

}

MaillonDev *LSCpremier(double reel, double im, int degre, Polynomial *polynome)
{
    MaillonDev *nouvMaillon = malloc(sizeof(*nouvMaillon));
    nouvMaillon->reel = reel;
    nouvMaillon->im = im;
    nouvMaillon->degre = degre;
    nouvMaillon->suiv = NULL;
    polynome->premierDev = nouvMaillon;
    return nouvMaillon;
}

MaillonDev *LSCsuivant(double reel, double im, int degre, MaillonDev *adressePrec)
{
    MaillonDev *nouvMaillon = malloc(sizeof(*nouvMaillon));;
    nouvMaillon->reel = reel;
    nouvMaillon->im = im;
    nouvMaillon->degre = degre;
    nouvMaillon->suiv = NULL;
    adressePrec->suiv = nouvMaillon;
    return nouvMaillon;
}

void affichageDev(Polynomial *polynome)
{
    MaillonDev *curr;
    curr = polynome->premierDev;
    if(curr == NULL)
    {
        return;
    }
    if(curr->im >0) // premier mon�me d'un polyn�me complexe
    {
        if(curr->degre > 1)
        {
            printf("(%.2lfx+%.2lfi)^%d", curr->reel, curr->im, curr->degre);
        }
        if(curr->degre == 1)
        {
            printf("(%.2lfx+%.2lfi)", curr->reel, curr->im);
        }
        if(curr->degre == 0)
        {
            printf("(%.2lf+%.2lfi)", curr->reel, curr->im);
        }
    }
    if(curr->im < 0) // premier mon�me d'un polyn�me complexe
    {
        if(curr->degre > 1)
        {
            printf("(%.2lfx%.2lfi)^%d", curr->reel, curr->im, curr->degre);
        }
        if(curr->degre == 1)
        {
            printf("(%.2lfx%.2lfi)", curr->reel, curr->im);
        }
        if(curr->degre == 0)
        {
            printf("(%.2lf%.2lfi)", curr->reel, curr->im);
        }
    }
    if(curr->im ==0) // premier mon�me d'un polyn�me non complexe
    {
        if(curr->degre > 1)
        {
            printf("%.2lfx^%d", curr->reel, curr->degre);
        }
        if(curr->degre == 1)
        {
            printf("%.2lfx", curr->reel);
        }
        if(curr->degre == 0)
        {
            printf("%.2lf", curr->reel);
        }
    }
    while(curr->suiv != NULL) //mon�mes suivants
    {
        curr = curr->suiv;
        if(curr->reel >0 || curr->im != 0) //afficher + entre chaque mon�me
        {
            printf("+");
        }
        if(curr->im >0)
        {
            if(curr->degre > 1)
            {
                printf("(%.2lfx+%.2lfi)^%d", curr->reel, curr->im, curr->degre);
            }
            if(curr->degre == 1)
            {
                printf("(%.2lfx+%.2lfi)", curr->reel, curr->im);
            }
            if(curr->degre == 0)
            {
                printf("(%.2lf+%.2lfi)", curr->reel, curr->im);
            }
        }
        if(curr->im < 0)
        {
            if(curr->degre > 1)
            {
                printf("(%.2lfx%.2lfi)^%d", curr->reel, curr->im, curr->degre);
            }
            if(curr->degre == 1)
            {
                printf("(%.2lfx%.2lfi)", curr->reel, curr->im);
            }
            if(curr->degre == 0)
            {
                printf("(%.2lf%.2lfi)", curr->reel, curr->im);
            }
        }
        if(curr->im ==0) // premier mon�me d'un polyn�me non complexe
        {
            if(curr->degre > 1)
            {
                printf("%.2lfx^%d", curr->reel, curr->degre);
            }
            if(curr->degre == 1)
            {
                printf("%.2lfx", curr->reel);
            }
            if(curr->degre == 0)
            {
                printf("%.2lf", curr->reel);
            }
        }
    }
}

void addition(Polynomial *poly1 , Polynomial *poly2)
{
    int PMaillon = 0;
    MaillonDev *curr1;
    curr1 = poly1->premierDev;
    MaillonDev *curr2;
    curr2 = poly2->premierDev;
    int reel , im , degre;
    Polynomial *debutAdd = malloc(sizeof(*debutAdd)); //pointeur de la LSC qui va contenir les monomes de l'addition
    debutAdd->premierDev = NULL;
    MaillonDev *currAdd;
    while ( (curr1 != NULL && curr2 != NULL) && (PMaillon == 0) )
    {
        //premier monome � afficher
        if(PMaillon == 0) //bool�en d�tectant si c'est le premier maillon de la cha�ne ou pas
        {
            if(curr1->degre > curr2->degre && PMaillon == 0)
            {
                reel = curr1->reel;
                im = curr1->im;
                degre = curr1->degre;
                if(reel != 0)
                {
                    currAdd = LSCpremier(reel, im , degre , debutAdd);
                    PMaillon = 1;
                }
                curr1 = curr1->suiv;
            }
            if(curr1->degre < curr2->degre && PMaillon== 0)
            {
                reel = curr2->reel;
                im = curr2->im;
                degre = curr2->degre;
                if(reel != 0)
                {
                    currAdd = LSCpremier(reel, im , degre , debutAdd);
                }
                curr2 = curr2->suiv;
            }
            if(curr1->degre == curr2->degre && PMaillon == 0)
            {
                reel = (curr1->reel) + (curr2->reel);
                im = (curr1->im) + (curr2->im);
                degre = curr1->degre;
                if(reel != 0)
                {
                    currAdd = LSCpremier(reel, im , degre , debutAdd);
                    PMaillon = 1;
                }
                curr1 = curr1->suiv;
                curr2 = curr2->suiv;
            }
        }
    }
    while(curr1 != NULL && curr2 != NULL)
    {
        if(curr1->degre > curr2->degre)
        {
            reel = curr1->reel;
            im = curr1->im;
            degre = curr1->degre;
            if(reel != 0)
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr1 = curr1->suiv;
        }
        if(curr1->degre < curr2->degre)
        {
            reel = curr2->reel;
            im = curr2->im;
            degre = curr2->degre;
            if(reel != 0)
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr2 = curr2->suiv;
        }
        if(curr1->degre == curr2->degre)
        {
            reel = (curr1->reel) + (curr2->reel);
            im = (curr1->im) + (curr2->im);
            degre = curr1->degre;
            if(reel != 0)
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr1 = curr1->suiv;
            curr2 = curr2->suiv;
        }
    }
    //Lorsqu'on a fini de parcourir une des deux chaines
    if(curr1 == NULL)
    {
        while(curr2 != NULL)
        {
            currAdd = LSCsuivant(curr2->reel, curr2->im, curr2->degre, currAdd);
            curr2 = curr2->suiv;
        }
    }
    if(curr2 == NULL)
    {
        while(curr1 != NULL)
        {
            currAdd = LSCsuivant(curr1->reel, curr1->im, curr1->degre, currAdd);
            curr1 = curr1->suiv;
        }
    }
    if(debutAdd->premierDev == NULL)
    {
        printf("Resultat:0");
    }
    else
    {
        printf("Resultat:");
        affichageDev(debutAdd);
    }
}

void soustraction(Polynomial *poly1 , Polynomial *poly2)
{
    int PMaillon = 0;
    MaillonDev *curr1;
    curr1 = poly1->premierDev;
    MaillonDev *curr2;
    curr2 = poly2->premierDev;
    int reel , im , degre;
    Polynomial *debutAdd = malloc(sizeof(*debutAdd)); //pointeur de la LSC qui va contenir les monomes de la soustraction
    debutAdd->premierDev = NULL;
    MaillonDev *currAdd;
    while ( (curr1 != NULL && curr2 != NULL) && (PMaillon == 0) )
    {
        //premier monome � afficher
        if(PMaillon == 0) //bool�en d�tectant si c'est le premier maillon de la cha�ne ou pas
        {
            if(curr1->degre > curr2->degre && PMaillon == 0)
            {
                reel = curr1->reel;
                im = curr1->im;
                degre = curr1->degre;
                if(reel != 0)
                {
                    currAdd = LSCpremier(reel, im , degre , debutAdd);
                    PMaillon = 1;
                }
                curr1 = curr1->suiv;
            }
            if(curr1->degre < curr2->degre && PMaillon== 0)
            {
                reel = (curr2->reel)*(-1);
                im = (curr2->im)*(-1);
                degre = curr2->degre;
                if(reel != 0)
                {
                    currAdd = LSCpremier(reel, im , degre , debutAdd);
                }
                curr2 = curr2->suiv;
            }
            if(curr1->degre == curr2->degre && PMaillon == 0)
            {
                reel = (curr1->reel) + (curr2->reel)*(-1);
                im = (curr1->im) + (curr2->im)*(-1);
                degre = curr1->degre;
                if(reel != 0)
                {
                    currAdd = LSCpremier(reel, im , degre , debutAdd);
                    PMaillon = 1;
                }
                curr1 = curr1->suiv;
                curr2 = curr2->suiv;
            }
        }
    }
    while(curr1 != NULL && curr2 != NULL)
    {
        if(curr1->degre > curr2->degre)
        {
            reel = curr1->reel;
            im = curr1->im;
            degre = curr1->degre;
            if(reel != 0)
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr1 = curr1->suiv;
        }
        if(curr1->degre < curr2->degre)
        {
            reel = (curr2->reel)*(-1);
            im = (curr2->im)*(-1);
            degre = curr2->degre;
            if(reel != 0)
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr2 = curr2->suiv;
        }
        if(curr1->degre == curr2->degre)
        {
            reel = (curr1->reel) + (curr2->reel)*(-1);
            im = (curr1->im) + (curr2->im)*(-1);
            degre = curr1->degre;
            if(reel != 0)
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr1 = curr1->suiv;
            curr2 = curr2->suiv;
        }
    }
    //Lorsqu'on a fini de parcourir une des deux chaines
    if(curr1 == NULL)
    {
        while(curr2 != NULL)
        {
            currAdd = LSCsuivant((curr2->reel)*(-1), (curr2->im)*(-1), (curr2->degre), currAdd);
            curr2 = curr2->suiv;
        }
    }
    if(curr2 == NULL)
    {
        while(curr1 != NULL)
        {
            currAdd = LSCsuivant(curr1->reel, curr1->im, curr1->degre, currAdd);
            curr1 = curr1->suiv;
        }
    }
    if(debutAdd->premierDev == NULL)
    {
        printf("Resultat:0");
    }
    else
    {
        printf("Resultat:");
        affichageDev(debutAdd);
    }
}

void multiplication(Polynomial *poly1 , Polynomial *poly2)
{
    int PMaillon = 0;
    MaillonDev *curr1;
    curr1 = poly1->premierDev;
    MaillonDev *curr2;
    curr2 = poly2->premierDev;
    int reel , im , degre;
    Polynomial *debutAdd = malloc(sizeof(*debutAdd)); //pointeur de la LSC qui va contenir les monomes de la multiplication
    debutAdd->premierDev = NULL;
    MaillonDev *currAdd;
    if(PMaillon == 0 && curr1 != NULL && curr2 != NULL) //bool�en d�tectant si c'est le premier maillon de la cha�ne ou pas
    {
        reel = (curr1->reel * curr2->reel) - (curr1->im * curr2->im);
        im = (curr1->reel * curr2->im) + (curr2->reel * curr1->im);
        degre = curr1->degre + curr2->degre;
        if(reel != 0)
        {
            currAdd = LSCpremier(reel, im , degre , debutAdd);
            PMaillon = 1;
        }
        curr2 = curr2->suiv;
    }
    while(curr1 != NULL)
    {
        while(curr2 != NULL)
        {
            reel = (curr1->reel * curr2->reel) - (curr1->im * curr2->im);
            im = (curr1->reel * curr2->im) + (curr2->reel * curr1->im);
            degre = curr1->degre + curr2->degre;
            if(currAdd->degre == degre)
            {
                currAdd->reel = currAdd->reel + reel;
                currAdd->im = currAdd->im + im;
            }
            else
            {
                currAdd = LSCsuivant(reel, im , degre , currAdd);
            }
            curr2=curr2->suiv;
        }
        curr2=poly2->premierDev;
        curr1=curr1->suiv;
    }
    if(debutAdd->premierDev == NULL)
    {
        printf("Resultat:0");
    }
    else
    {
        printf("Resultat:");
        affichageDev(debutAdd);
    }
}
#endif // POLYNOME_H_INCLUDED
