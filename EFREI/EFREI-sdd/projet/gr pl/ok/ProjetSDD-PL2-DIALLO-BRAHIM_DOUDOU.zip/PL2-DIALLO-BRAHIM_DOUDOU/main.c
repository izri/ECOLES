#include <stdio.h>
#include <stdlib.h>
#include"Projection.h"
#include"Projection.c"

int main()
{
    int choix, fin=1, choice=1;
    Liste*liste1; liste1=init();
    Liste*liste;
    Liste*liste3;
    liste3=init();
    Element*liste2;
    menu();
    while(fin){
        printf("QUEL EST VOTRE CHOIX : \n");
        scanf("%d",&choix);
    switch(choix)
    {
    case 1:
        {
           liste = init();
           PolyDev(liste);printf("\n");
           printf("f(X) = ");
           afficherListe(liste);printf("\n");

        }break;
    case 2:
        {
            liste1=init();
            PolyDev(liste1);printf("\n");
            printf("g(X) = ");
            afficherListe(liste1);
            printf("\n");printf("\n");
        }break;
    case 3:
        {
            liste2 = additionPoly (liste1,liste);
            printf("L'ADDITION DES DEUX POLYNOMES DONNE: \n"); printf("\n");
            afficherListe(liste2);
            printf("\n"); printf("\n");
        }break;
    case 4:
        {
            liste2 = soustractPoly(liste1,liste);
            printf("LA SOUSTRACTION DES DEUX POLYNOMES DONNE: \n"); printf("\n");
            afficherListe(liste2);
            printf("\n"); printf("\n");
        }
    case 5:
        {
            liste2 = multip_Poly(liste,liste1);
            printf("LE PRODUIT DES DEUX POLYNOMES: \n"); printf("\n");
            afficherListe(liste2);printf("\n");
            liste3=trie_Poly(liste2);
            printf("LE POLYNOME TRIE:\n");
            afficherListe(liste3);printf("\n");
        }break;
    case 6:
        {
            if (liste1!=NULL)
            {

            menu2();
            while(choice)
            {
                printf("QUEL EST VOTRE CHOIX : \n");
                scanf("%d",&choix);
                switch(choix)
                {
                case 1:{liste2 = extractRePoly(liste);printf("LES PARTIES REELLES DU POLYNOME: \n"); printf("\n");
                        afficherExtract(liste2);printf("\n");}
                case 2:{liste2 = extractRePoly(liste1);printf("LES PARTIES REELLES DU POLYNOME: \n"); printf("\n");
                        afficherExtract(liste2);printf("\n");}
                case 3: menu();break;
                }return 0;
            }
            }
            else{liste2 = extractRePoly(liste);printf("LES PARTIES REELLES DU POLYNOME: \n"); printf("\n");afficherExtract(liste2);printf("\n");}
        }
    case 7:
        {
            if (liste1->premier!=NULL)
            {

            menu3();
            while(choice)
            {
                printf("QUEL EST VOTRE CHOIX : \n");
                scanf("%d",&choix);
                switch(choix)
                {
                case 1:{liste2 = extractImPoly(liste);printf("LES PARTIES IMAGINAIRES DU POLYNOME: \n"); printf("\n");
                        afficherExtractIm(liste2);printf("\n");}
                case 2:{liste2 = extractImPoly(liste1);printf("LES PARTIES IMAGINAIRES DU POLYNOME: \n"); printf("\n");
                        afficherExtractIm(liste2);printf("\n");}
                case 3: menu();break;
                }return 0;
            }
            }
            else{liste2=extractImPoly(liste); printf("LES PARTIES IMAGINAIRES DU POLYNOME: \n"); printf("\n");afficherExtractIm(liste2);printf("\n");}
        }

    case 8:
        {
            menu2();
            while(choice)
            {
                printf("QUEL EST VOTRE CHOIX : \n"); scanf("%d",&choix);
                switch(choix)
                {
                case 1:{liste2 = modulPoly(liste);printf("LES MODULES DE VOTRE POLYNOME: \n"); printf("\n");
                        affichermodule(liste2);printf("\n");}
                case 2:{liste2 = modulPoly(liste1);printf("LES MODULES DE VOTRE POLYNOME: \n"); printf("\n");
                        affichermodule(liste2);printf("\n");}
                case 3: menu();break;
                }return 0;
            }
            }
    case 9:
        {
            menu2();
            while(choice)
            {
                printf("QUEL EST VOTRE CHOIX : \n"); scanf("%d",&choix);
                switch(choix)
                {
                case 1:{liste2 = conjugPoly(liste);printf("LES CONJUGUES DE VOTRE POLYNOME: \n"); printf("\n");
                        afficherListeConjug(liste2);printf("\n");}
                case 2:{liste2 = conjugPoly(liste1);printf("LES CONJUGUES DE VOTRE POLYNOME: \n"); printf("\n");
                        afficherListeConjug(liste2);printf("\n");}
                case 3: menu();break;
                }return 0;
            }
        }

    case 10: exit(-1);break;
    default: printf("CE CHOIX N'EXISTE PAS !\n");
    }
    }
return 0;
}

