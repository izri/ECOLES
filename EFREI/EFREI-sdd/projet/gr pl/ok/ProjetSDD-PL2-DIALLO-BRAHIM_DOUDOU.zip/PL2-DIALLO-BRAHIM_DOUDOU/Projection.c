#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include"Projection.h"
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Complexe sommeC(Complexe A, Complexe B)
{
    Complexe C;
    C.Re= A.Re + B.Re;
    C.Im= A.Im + B.Im;
    return C ;
}
Complexe produitC (Complexe A, Complexe B)
{
    Complexe C;
    C.Re= A.Re*B.Re - A.Im*B.Im; C.Im=A.Re*B.Im + A.Im*B.Re;
    return C;
}
Complexe soustractC(Complexe A, Complexe B)
{
    Complexe C;
    C.Re= A.Re - B.Re; C.Im= A.Im - B.Im;
    return C ;
}
Complexe conjugC(Complexe C)
{
    Complexe D;
    D.Re=C.Re; D.Im=-C.Im;
    return D ;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double extractRe(Complexe C)
{
    return C.Re;
}
double extractIm(Complexe C)
{
    return C.Im;
}
double module(Complexe C)
{
    return sqrt(C.Re*C.Re+C.Im*C.Im) ;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int comparaisons (Complexe A, Complexe B)
{
    if((A.Re=B.Re)&&(A.Im=B.Im)){return 1 ;}
    else return 0 ;
}
int Estcomplexe(Complexe A, Complexe B)
{
    if(A.Im!=0 && B.Im!=0){return 1;}
    else return 0;
}
int Estreel(Complexe A, Complexe B)
{
    if((A.Im=0) && (B.Im=0)){return 1;}
    else return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void menu(){

    printf("MENU\n---------\n");
    printf("1:SAISIR UN 1er POLYNOME\n");
    printf("2:SAISIR UN 2nd POLYNOME\n");
    printf("3:ADDITIONNER LES DEUX POLYNOMES\n");
    printf("4:SOUSTRAIRE LES DEUX POLYNOMES\n");
    printf("5:MULTIPLIER DEUX POLYNOMES\n");
    printf("6:POUR EXTRAIRE LES REELS DU POLYNOMES\n");
    printf("7:POUR EXTRAIRE LES IMAGINAIRES DU POLYNOES\n");
    printf("8:CALCULER LES MODULES DU POLYNOES\n");
    printf("9:POUR FAIRE LE CONJUGUE:\n");
    printf("10:SORTIE\n");
}

void menu2()
{
    printf("VEUILLEZ CHOISIR SUR QUEL POLYNOMES EFFECTUER CETTE OPERATION !\n");
    printf("1:POUR LE PREMIER POLYNOME!\n");
    printf("2:POUR LE SECOND POLYNOME!\n");
    printf("3:POUR REVENIR AU MENU PRINCIPAL!\n");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void menu3 ()
{
    printf("VEUILLEZ CHOISIR SUR QUEL POLYNOMES EFFECTUER CETTE OPERATION !\n");
    printf("1:POUR LE PREMIER POLYNOME!\n");
    printf("2:POUR LE SECOND POLYNOME!\n");
    printf("3:POUR REVENIR AU MENU PRINCIPAL!\n");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Liste*init()
{
    Liste*liste = malloc(sizeof(*liste));
    Element *element = malloc(sizeof(*element));
    if (liste == NULL || element == NULL){exit(EXIT_FAILURE);}
    element->deg= 0;
    element->complexe.Im= 0;
    element->complexe.Re= 0;
    element->suivant = NULL;
    liste->premier = element;
    return liste;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void insertion(Liste *liste,int degr, double reel, double imaginaire)
{
    /* Cr�ation du nouvel �l�ment */
    Element *nouveau = malloc(sizeof(*nouveau));
    if (liste == NULL || nouveau == NULL){exit(EXIT_FAILURE);}
    nouveau->deg = degr;
    nouveau->complexe.Re = reel;
    nouveau->complexe.Im = imaginaire;
    /* Insertion de l'�l�ment au d�but de la liste */
    nouveau->suivant = liste->premier;
    liste->premier = nouveau;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void PolyDev(Liste*liste)
{
    int i=0, n;
    double Re, Im;
    Element *element = malloc(sizeof(*element));
    if (liste == NULL || element == NULL){exit(EXIT_FAILURE);}
    printf("VEUILLEZ ENTRER LE DEGRE DU POLYNOME A CREER !\n");
    scanf("%d",&n);
    printf("SAISIR LA PARTIE REELLE DU MONOME DE DEGRE %d :\n",i);
    scanf("%lf", &Re);
    printf("SAISIR LA PARTIE IMAGINAIRE DU MONOME DE DEGRE %d :\n",i);
    scanf("%lf", &Im);
    element->deg= i;
    element->complexe.Re= Re;
    element->complexe.Im= Im;
    element->suivant = NULL;
    liste->premier = element;
    for(i=1; i<=n; i++)
    {
        printf("SAISIR LA PARTIE REELLE DU MONOME DE DEGRE %d :\n",i);
        scanf("%lf", &Re);
        printf("SAISIR LA PARTIE IMAGINAIRE DU MONOME DE DEGRE %d :\n",i);
        scanf("%lf", &Im);
        if ((Re!=0)||(Im!=0)){insertion(liste, i, Re, Im);}
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficherListe(Liste *liste)
{
    if (liste == NULL){exit(EXIT_FAILURE);}
    Element *actuel = liste->premier;

    while (actuel != NULL)
    {
        if(actuel->complexe.Im==0)
        {
            if (actuel->complexe.Re!=0)
            {
                if(actuel->deg==0){printf("%lf", actuel->complexe.Re);}
                else{printf("%lfX^%d", actuel->complexe.Re, actuel->deg);}
            }
        }
        else
        {
          if (actuel->complexe.Re!=0)
          {
              if(actuel->deg==0){printf("(%lf + %lfi)",  actuel->complexe.Re, actuel->complexe.Im, actuel->deg);}
              else{printf("(%lf + %lfi)X^%d",  actuel->complexe.Re, actuel->complexe.Im, actuel->deg);}
          }
          else
          {
            if(actuel->deg==0){printf("%lf", actuel->complexe.Im);}
            else{printf("%lfiX^%d", actuel->complexe.Im, actuel->deg);}
          }
        }
        actuel = actuel->suivant; if (actuel!= NULL) {printf(" + ");}
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element * additionPoly (Liste *liste1, Liste *liste2)
{
   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;
   Element *actuel1 = liste1->premier; Element *actuel2 = liste2->premier;
   Complexe C; int degr;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}

   while((actuel1!=NULL)&&(actuel2!=NULL))
    {
         if ((actuel1->deg > actuel2->deg))
         {
             insertion(actuel, actuel1->deg, actuel1->complexe.Re, actuel1->complexe.Im);
             actuel1 = actuel1->suivant;
         }
         else if ((actuel1->deg == actuel2->deg))
         {
             C= sommeC(actuel1->complexe, actuel2->complexe);
             insertion(actuel, actuel1->deg, C.Re, C.Im);
             actuel1 = actuel1->suivant; actuel2 = actuel2->suivant;
         }
         else
         {
             insertion(actuel, actuel2->deg, actuel2->complexe.Re, actuel2->complexe.Im);
             actuel2 = actuel2->suivant;
         }
    }
return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element * soustractPoly(Liste *liste1, Liste *liste2)
{
   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;
   Element *actuel1 = liste1->premier; Element *actuel2 = liste2->premier;
   Complexe C; int degr;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}

   while((actuel1!=NULL)&&(actuel2!=NULL))
    {
         if ((actuel1->deg > actuel2->deg))
         {
             insertion(actuel, actuel1->deg, actuel1->complexe.Re, actuel1->complexe.Im);
             actuel1 = actuel1->suivant;
         }
         else if ((actuel1->deg == actuel2->deg))
         {
             C= soustractC(actuel1->complexe, actuel2->complexe);
             insertion(actuel, actuel1->deg, C.Re, C.Im);
             actuel1 = actuel1->suivant; actuel2 = actuel2->suivant;
         }
         else
         {
             insertion(actuel, actuel2->deg, actuel2->complexe.Re, actuel2->complexe.Im);
             actuel2 = actuel2->suivant;
         }
    }
return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element * multip_Poly (Liste *liste1, Liste *liste2)
{

   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;Complexe C; int degr;
   Element *actuel1 = liste1->premier; Element *actuel2 = liste2->premier;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}
   while(actuel1!=NULL)
   {
       while(actuel2!=NULL)
       {
             degr= actuel1->deg + actuel2->deg;
             C= produitC (actuel1->complexe, actuel2->complexe);
             insertion(actuel, degr, C.Re, C.Im); actuel2 = actuel2->suivant;
       }
    actuel2 = liste2->premier;
    actuel1 = actuel1->suivant;
   }
return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element *extractRePoly(Liste *liste)
{
   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;Complexe C; int degr;
   Element *actuel1 = liste->premier;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}
   while (actuel1!=NULL)
   {
       actuel->complexe.Re=extractRe(actuel1->complexe);
       insertion(actuel, 0, actuel->complexe.Re, 0);
       actuel1=actuel1->suivant;
   }return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element *modulPoly(Liste *liste)
{
   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;Complexe C; int degr;
   Element *actuel1 = liste->premier;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}
   while (actuel1!=NULL)
   {
       actuel->complexe.Re= module(actuel1->complexe);
       insertion(actuel, 0, actuel->complexe.Re, 0);
       actuel1=actuel1->suivant;
   }return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void affichermodule(Liste*liste)
{
    if (liste == NULL){exit(EXIT_FAILURE);}
    Element *actuel = liste->premier;
    while (actuel != NULL)
    {
      if (actuel->complexe.Re!=0){printf("%lf", actuel->complexe.Re);}
      actuel = actuel->suivant; if (actuel!= NULL) {printf(" ; ");}
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element *conjugPoly(Liste*liste)
{
    Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;Complexe C; int degr;
   Element *actuel1 = liste->premier;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}
   while (actuel1!=NULL)
   {
       actuel->complexe= conjugC(actuel1->complexe);
       insertion(actuel, 0, actuel->complexe.Re, actuel->complexe.Im);
       actuel1=actuel1->suivant;
   }return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficherExtract(Liste *liste)
{
    if (liste == NULL){exit(EXIT_FAILURE);}
    Element *actuel = liste->premier;
    while (actuel != NULL)
    {
      if (actuel->complexe.Re!=0){printf("%lf", actuel->complexe.Re);}
      actuel = actuel->suivant; if (actuel!= NULL) {printf(" ; ");}
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element *extractImPoly(Liste *liste)
{
   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;Complexe C; int degr;
   Element *actuel1 = liste->premier;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}
   while (actuel1!=NULL)
   {
       actuel->complexe.Im= extractIm(actuel1->complexe);
       insertion(actuel, 0, 0,actuel->complexe.Im );
       actuel1=actuel1->suivant;
   }return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficherExtractIm(Liste *liste)
{
    if (liste == NULL){exit(EXIT_FAILURE);}
    Element *actuel = liste->premier;
    while (actuel != NULL)
    {
      if (actuel->complexe.Im!=0){printf("%lf", actuel->complexe.Im);}
      actuel = actuel->suivant; if (actuel!= NULL) {printf(" ; ");}
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void suppression(Liste *liste)
{
    if (liste == NULL){exit(EXIT_FAILURE);}
    if (liste->premier != NULL)
    {
        Element *aSupprimer = liste->premier;
        liste->premier = liste->premier->suivant; free(aSupprimer);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element * trie_Poly (Liste *liste)
{

   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;
   Element *actuel1 = liste->premier; Element *actuel2 = liste->premier;
   Complexe C;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}

   while((actuel1!=NULL)&&(actuel2!=NULL))
    {
         if ((actuel1->deg > actuel2->deg))
         {
             insertion(actuel, actuel1->deg, actuel1->complexe.Re, actuel1->complexe.Im);
             actuel1 = actuel1->suivant;
         }
         else if ((actuel1->deg == actuel2->deg))
         {
             C= sommeC(actuel1->complexe, actuel2->complexe);
             insertion(actuel, actuel1->deg, C.Re, C.Im);
             actuel1 = actuel1->suivant; actuel2 = actuel2->suivant;
         }
         else
         {
             insertion(actuel, actuel2->deg, actuel2->complexe.Re, actuel2->complexe.Im);
             actuel2 = actuel2->suivant;
         }
    }
return actuel;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficherListeConjug(Liste *liste)
{
   Element *actuel = malloc(sizeof(*actuel));
   actuel->deg=0; actuel->complexe.Im=0; actuel->complexe.Re=0;
   actuel->suivant = NULL;Complexe C; int degr;
   Element *actuel1 = liste->premier; Element *actuel2 = liste->premier;
   if (actuel1 == NULL){exit(EXIT_FAILURE);}
   while(actuel1!=NULL)
   {
       while(actuel2!=NULL)
       {
          if ((actuel1->deg == actuel2->deg))
         {
             C= sommeC(actuel1->complexe, actuel2->complexe);
             insertion(actuel, actuel1->deg, C.Re, C.Im);
             actuel1 = actuel1->suivant; actuel2 = actuel2->suivant;
         }
         else
         {
             insertion(actuel, actuel2->deg, actuel2->complexe.Re, actuel2->complexe.Im);
             actuel2 = actuel2->suivant;
         }
       }
    actuel2 = liste->premier;
    actuel1 = actuel1->suivant;
   }
return actuel;
}
