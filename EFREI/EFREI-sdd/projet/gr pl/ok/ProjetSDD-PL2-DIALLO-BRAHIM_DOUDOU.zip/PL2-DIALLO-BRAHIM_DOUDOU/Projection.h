#ifndef PROJECTION_H_INCLUDED
#define PROJECTION_H_INCLUDED
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct Complexe Complexe;
struct Complexe
{
    double Re;
    double Im;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct Element Element;
struct Element
{
    int deg;
    Complexe complexe;
    Element *suivant;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct Liste Liste;
struct Liste
{
    Element *premier;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void menu();
void menu2();
void menu3 ();
Liste *init();
void insertion(Liste *liste,int degr, double reel, double imaginaire);
void PolyDev(Liste *liste);
void afficherListe(Liste *liste);
void afficherExtract(Liste *liste);
void afficherExtractIm(Liste *liste);
void affichermodule(Liste*liste);
void afficherListeConjug(Liste *liste);
void suppression(Liste *liste);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Element * additionPoly (Liste *liste1, Liste *liste2);
Element *soustractPoly(Liste *liste1, Liste *liste2);
Element * multip_Poly (Liste *liste1, Liste *liste2);
Element * trie_Poly (Liste *liste);
Element *extractRePoly(Liste *liste);
Element *extractImPoly(Liste *liste);
Element *modulPoly(Liste *liste);
Element *conjugPoly(Liste*liste);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Complexe produitC (Complexe A, Complexe B);
Complexe produitScal(Complexe A, Complexe B);
Complexe soustractC(Complexe A, Complexe B);
Complexe conjugC(Complexe C);
double extractRe(Complexe C);
double extractIm(Complexe C);
double module(Complexe C);
int comparaisons (Complexe A, Complexe B);
int Estcomplexe(Complexe A, Complexe B);
int Estreel(Complexe A, Complexe B);
Complexe sommeC(Complexe A, Complexe B);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#endif // PROJECTION_H_INCLUDED
