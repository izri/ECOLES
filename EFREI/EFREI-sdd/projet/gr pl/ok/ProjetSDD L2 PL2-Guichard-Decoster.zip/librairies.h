/*
**  Fichier : librairies.h
**  Description : Regroupe l'appel de toutes les autres librairies
**
**  Projet : Projet_Polynomes
**  Collaborateurs  : GUICHARD & DECOSTER
**  Groupe - Promo  : PL2 - Promo 2018
*/

#ifndef LIBRAIRIES_H
#define LIBRAIRIES_H

// Librairies Systeme
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
	#include <math.h>

// Librairies projet
    #include "fonctions_listes.h" 			// Structures et fonctions liees a la creation des listes chainees
	#include "fonctions_polynome.h"		// Fonctions de traitement mathématique des polynomes et monomes

#endif // LIBRAIRIES_H
