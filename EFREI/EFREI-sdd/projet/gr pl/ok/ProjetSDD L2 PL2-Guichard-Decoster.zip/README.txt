
 Projet : Projet Polynomes
 Description : Calcul sur des polynomes avec exploitation de liste chain�e
 Collaborateurs  : GUICHARD & DECOSTER
 Groupe - Promo  : PL2 - Promo 2018

 Date de rendu : 30/11/2014
 
 Avancement :
 
  - Interface d'utilisation
  - Initialisation du premier polynome (BUG)
  