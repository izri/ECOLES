/*
**  Fichier : main.c
**  Description : Fonctions de gestion du programme
**
**  Projet : Projet_Polynomes
**  Collaborateurs  : GUICHARD & DECOSTER
**  Groupe - Promo  : PL2 - Promo 2018
*/

#include "librairies.h"

int menu();

int main()
{
    Liste_monome polynome = Initialisation();

    while(1) /// Infini mais pouvant �tre quitt� si l'on choisi 0 dans le menu principal
    {
        system("CLS");
        printf("\n\t\t\t\t=== POLYNOME ===\n");
        printf("\t\t\t- Un programme de Benjamin et Antoine -\n\n");

        printf("\tVotre polynome : ");
    //    Afficher_Polynome(polynome);

        switch(menu()) /// Retourne une valeur permetttant de choisir l'option
        {
            case 0 : return 0; break;
            default : break;
        }
    }
}

int menu()
{
    int choix;

    printf("\n\n\n Que faire ?\n\n");
    printf(" 1. Editer le polynome\n");
    printf(" 2. Information sur le polynome\n");
    printf(" 3. PGCD de deux polynomes\n\n");
    printf(" 0. Quitter\n");
    printf("\n\t Choix : ");

    fflush(stdin);
    scanf("%d", &choix);

    return choix;
}
