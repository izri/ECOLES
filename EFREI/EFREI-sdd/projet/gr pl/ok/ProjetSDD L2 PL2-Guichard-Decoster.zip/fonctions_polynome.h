/*
**  Fichier : fonctions_polynome.h
**  Description : Regroupe les fonctions li�s � l'utilisation des mon�mes
**
**  Projet : Projet_Polynomes
**  Collaborateurs  : GUICHARD & DECOSTER
**  Groupe - Promo  : PL2 - Promo 2018
*/

#ifndef FONCTIONS_POLYNOME_H
#define FONCTIONS_POLYNOME_H

// Headers
	/** Factorisation et Developpement **/
Liste_monome Factorisation(Liste_monome polynome);										// Permet d'obtenir la forme factoris� d'un polynome
Liste_monome Developpement(Liste_monome polynome);									// Permet d'obtenir la forme d�velopp� d'un polynome

	/** Op�rations Elementaires **/
Liste_monome addition(Liste_monome monome1, Liste_monome monome2);		// Permet d'additionner deux monomes entre eux
Liste_monome soustraction(Liste_monome monome1, Liste_monome monome2);	// Permet de soustraire deux monomes entre eux
Liste_monome multiplication(Liste_monome monome1, Liste_monome monome2);	// Permet de multiplier deux monomes entre eux
Liste_monome division(Liste_monome monome1, Liste_monome monome2);			// Permet de diviser deux monomes entre eux

	/** Fonctionnalit�s **/
void PGCD(Liste_monome polynome);																	// Permet de faire le PGCD entre deux polynomes

#endif // FONCTIONS_POLYNOME_H
