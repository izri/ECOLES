/*
**  Fichier : fonctions_listes.h
**  Description : Regroupe les structures et header de fonctions liés à l'utilisation des liste chainées
**
**  Projet : Projet_Polynomes
**  Collaborateurs  : GUICHARD & DECOSTER
**  Groupe - Promo  : PL2 - Promo 2018
*/

#ifndef FONCTIONS_LISTES_H
#define FONCTIONS_LISTES_H

// Structures
typedef struct complexe {
    double  imaginaire;						// Partie Imaginaire
    double  reel;								// Partie Reel
}complexe;

typedef struct monome {
    complexe  coefficient;					// Valeur du coefficient, avec une partie imaginaire et une partie reel
    char      	variable;						// Valeur de la variable, soit une lettre entre x et z ou X et Z
    int       		exposant;						// Valeur de l'exposant, soit un entier possitif dans les reels
    struct   		monome * suivant;			// Adresse du monome suivant
    struct   		monome * precedent;		// Adresse du monome precedent
}monome;
typedef monome * Liste_monome;

// Headers
Liste_monome   Initialisation();													// Initialise la liste chainee
void					Afficher_Polynome(Liste_monome polynome);  	// Permet d'afficher toute l'équation étudiée
Liste_monome	Ajouter_Monome(Liste_monome precedent);    	// Permet d'ajouter un nouveau monome au polynôme
void					Supprimer_Monome(Liste_monome polynome);	// Permet de supprimer un monome du polynôme
Liste_monome	Purge_Polynome(Liste_monome polynome);		// Permet de vider integralement la liste

#endif // FONCTIONS_LISTES_H
