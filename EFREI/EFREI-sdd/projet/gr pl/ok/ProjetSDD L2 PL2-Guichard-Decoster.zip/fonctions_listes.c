/*
**  Fichier : fonctions_listes.c
**  Description : Regroupe les fonctions li�s � l'utilisation des liste chain�es
**
**  Projet : Projet_Polynomes
**  Collaborateurs  : GUICHARD & DECOSTER
**  Groupe - Promo  : PL2 - Prome 2018
*/

#include "librairies.h"

Liste_monome Initialisation() {
    Liste_monome liste = malloc(sizeof(Liste_monome));
    Liste_monome nouveau_monome = malloc(sizeof(nouveau_monome));

    nouveau_monome->coefficient.reel = 9;
    nouveau_monome->variable = 'x';
    nouveau_monome->suivant = NULL;
    nouveau_monome->precedent = NULL;
    liste = nouveau_monome;

  //  Ajouter_Monome(liste);

    return liste;
}

void Afficher_Polynome(Liste_monome polynome)
{
    if(polynome == NULL)
    {
        printf("vide");
    }
    else
    {
        while(polynome != NULL)
        {
            printf("%lf%c", polynome->coefficient.reel, polynome->variable);
            polynome = polynome->suivant;
        }
    }
}

Liste_monome Ajouter_Monome(Liste_monome precedent)
{

    Liste_monome nouveau_monome = malloc(sizeof(nouveau_monome));

    nouveau_monome->coefficient.reel = 9;
    nouveau_monome->variable = 'x';
    nouveau_monome->suivant = NULL;
    nouveau_monome->precedent = precedent;
    precedent->suivant = nouveau_monome;

    return nouveau_monome;
}

void Supprimer_Monome(Liste_monome polynome){}

Liste_monome Purge_Polynome(Liste_monome polynome){}