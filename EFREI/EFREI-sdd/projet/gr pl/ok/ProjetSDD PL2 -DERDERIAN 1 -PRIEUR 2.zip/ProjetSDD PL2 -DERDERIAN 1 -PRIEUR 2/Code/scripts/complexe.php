<?php

function analyse_polynome_complexe()
{
	//La variable $polinome prend la valeur du polynome reçu en POST
	$polynome = $_POST["polynome"];
	// On découpe le polynome en fonction des "-" dans un premier temps.
	$tableau_polynome_temp = explode('-', $polynome);
	$i = 0;
	$k = 0;
	//Si le premier monome est négatif
	if($tableau_polynome_temp[0] == "")
	{
		$tableau_polynome_temp[1] = "-".$tableau_polynome_temp[1]; 
		$i++;
	}	
	//On parcourt le tableau temporaire tant qu'on ne l'a pas fini.
	while($tableau_polynome_temp[$i] != null)
	{
		//Si on trouve une "(" avant le monome, on le regroupe
		if (substr($tableau_polynome_temp[$i], -1) == "(")
		{
			$tableau_polynome_temp1[$k] = $tableau_polynome_temp[$i]."-".$tableau_polynome_temp[$i+1];
			$i++;
		}
		else
		{
			$tableau_polynome_temp1[$k] = "-".$tableau_polynome_temp[$i];
		}
		$i++;
		$k++;
	}

	//#### Décomposition avec le signe + ###
	$i = 0;
	$j = 0;
	while($tableau_polynome_temp1[$i] != null)
	{
		$nb_plus = substr_count($tableau_polynome_temp1[$i], '+');
		if ($nb_plus != 0)
		{
			$tableau_polynome_temp_plus = explode('+', $tableau_polynome_temp1[$i]);
			for ($a=0; $a <= $nb_plus; $a++)
			{
				$tableau_polynome[$j] = $tableau_polynome_temp_plus[$a];
				$j++;
			}
		}
		else
		{
			$tableau_polynome[$j] = $tableau_polynome_temp1[$i];
			$j++;
		}
		$i++;
	}
	return $tableau_polynome;
}

?>