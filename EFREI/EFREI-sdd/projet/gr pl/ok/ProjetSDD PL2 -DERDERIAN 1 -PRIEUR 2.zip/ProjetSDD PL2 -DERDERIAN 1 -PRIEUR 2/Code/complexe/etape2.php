<?php
include("fonctions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Polynôme</title>
    <link href="./style/css/bootstrap.min.css" rel="stylesheet">
    <link href="./style/css/style.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="./img/favicon.png"/>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <h1 class="p-centre titre"><a href="index.php">Calcul de polynômes</a></h1>
    <div class="p-centre">
      <a href="index.php" class="btn btn-primary btn-lg" role="button">Accueil</a>
      <a href="objectifs.php" class="btn btn-default btn-lg" role="button">Objectifs</a>
    </div>
    <br/><br/>
    <div class="container">
    	<H4><strong>Etape 3 : Choisissez ce que vous souhaitez effectuer avec votre polynome.</strong></h4>
    	<hr/>
        <div class="row">
          <div class="col-md-4">
            <p>Votre polynôme est le suivant : <?php echo $_POST['polynome'];?></p>
            <?php
            echo $_POST["nb_monome"];
            echo "<br>".$_POST["polynome"];
            $polynome = null;
            for ($i=0; $i < $_POST["nb_monome"]; $i++)
            {
              $tableau_monome = determiner_monome($i);
              for ($j=0; $j <= 7; $j++)
              { 
                $tableau_polynome[$i][$j] = $tableau_monome[$j];
              }
              echo "<hr/>";
              $nb = $i+1;
              echo "<strong>Décomposition du monôme n°".$nb." : </strong><br/>";
              echo "Votre monôme : <strong>".$tableau_polynome[$i][0]."</strong><br/>";
              if ($tableau_polynome[$i][1] == "-")
              {
                echo "Monôme <strong>négatif</strong>.<br/>";
              }
              else
              {
                echo "Monôme <strong>positif</strong>.<br/>";
              }
              echo "Le scalaire du monôme : <strong>".$tableau_polynome[$i][2]."</strong><br/>";
              if ($tableau_polynome[$i][3] == 1)
              {
                echo "Il y a une inconnue dans le monôme : <strong>".$tableau_polynome[$i][4]."</strong><br/>";
              }
              else
              {
                echo "Aucune inconnue dans le monôme.<br/>";
              }
              if ($tableau_polynome[$i][5] == 1)
              {
                echo "La puissance est : <strong>".$tableau_polynome[$i][6]."</strong><br/>";
              }
              else
              {
                echo "Il n'y a pas de puissance.<br/>";
              }
              echo "<br/>";
            }
            ?>
          </div>
          <!-- Faire un affichage du polynome complet ici en prenant en compte les signes et balises <sup></sup>, plus joli-->
          <div class="col-md-8">
            <h4 class="p-centre"><strong>Que souhaitez-vous faire à présent ?</strong></h4>
            <br/>
            <div class="row text-center">
              <div class="col-md-4">
                <button type="button" class="btn btn-default btn-lg">Addition de polynôme</button>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-default btn-lg">Multiplication de polynôme</button>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-default btn-lg">Division de polynôme</button>
              </div>
            </div>
            <br/>
            <div class="row text-center">
              <div class="col-md-4">
                <button type="button" class="btn btn-default btn-lg">Conjugaison du polynôme</button>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-default btn-lg">Extraction des parties</button>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-default btn-lg">Evaluation en un point</button>
              </div>
            </div>
          </div>
         </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="./style/js/bootstrap.min.js"></script>
  </body>
</html>