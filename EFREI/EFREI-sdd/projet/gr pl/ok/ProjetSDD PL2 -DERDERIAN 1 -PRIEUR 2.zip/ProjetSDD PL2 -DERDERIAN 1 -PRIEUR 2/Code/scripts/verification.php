<?php
// On vérifie qu'on a bien reçu le polynome, et on défini la variable $type en fonction du type
if ((isset($_POST["polynome"])) AND (isset($_POST["type_polynome"])) AND ($_POST["type_polynome"] == "Polynôme simple")) $type = 1;
elseif ((isset($_POST["polynome"])) AND (isset($_POST["type_polynome"])) AND ($_POST["type_polynome"] == "Polynôme complexe")) $type = 2;
else header("Location:http://polynome.ovh/");
?>
<p>Si vous souhaitez écrire un polynôme avec des puissances aux monômes, <strong>utilisez la notation « ^() » pour les puissances.</strong> N'utilisez pas ² ou d'autres caractères.<br/>
Exemple : Il faut écrire « <strong>x^(2)+3x</strong> » pour avoir comme résultat : <code>x²+3x</code></p>
<hr/>
<H4><strong>Etape 1 : Entrez le polynôme que vous souhaitez utiliser</strong></h4>
<div class="form1">
  <form role="form" method="post" action="index.php">
    <div class="input-group">
      <div class="row">
        <div class="col-md-5 has-success">
          <input class="form-control" id="disabledInput inputSuccess1" type="text" placeholder="<?php echo $_POST['polynome'];?>" size="70" disabled>
        </div>
        <div class="col-md-4">
          <fieldset disabled>
            <select class="form-control">
            <?php
            if ($type == 1) echo "<option>Polynôme simple</option>";
            if ($type == 2) echo "<option>Polynôme complexe</option>";
            ?>
            </select>
          </fieldset>
        </div>
      	<div class="col-md-3"><fieldset disabled><button type="submit" class="btn btn-default">Confirmer</button></fieldset></div>
      </div>
    </div>
  </form>
</div>
<br/><hr/>
<div class="p-centre"><h3>Votre polynôme est le suivant : <kbd><?php echo $_POST["polynome"];?></kbd>, est-ce correct ?</h3>
<?php
// On vérifie qu'on a bien reçu le polynome, et on redirige l'utilisateur en fonction du type du polynome
if ((isset($_POST["polynome"])) AND (isset($_POST["type_polynome"])) AND ($_POST["type_polynome"] == "Polynôme simple"))
{
?>
	<form role="form" method="post" action="./simple/etape1.php">
    <input type="hidden" name="polynome" value="<?php echo $_POST['polynome'];?>" hidden>
    <!--<input type="hidden" name="nb_monome" value="<?php echo $nb_monome;?>">-->
    <br/>
    <input class="btn btn-default btn-lg" type="submit" value="Oui">
    <a href="../index.php" class="btn btn-default btn-lg" role="button">Non</a>
    <?php 
    //echo "<br>bbb".$nb_monome."aaaaaaa";
    ?>
  </form>
<?php
}
elseif ((isset($_POST["polynome"])) AND (isset($_POST["type_polynome"])) AND ($_POST["type_polynome"] == "Polynôme complexe"))
{
?>
	<form role="form" method="post" action="./complexe/etape1.php">
    <input type="hidden" name="polynome" value="<?php echo $_POST['polynome'];?>" hidden>
    <!-- <input type="hidden" name="nb_monome" value="<?php echo $nb_monome;?>">-->
    <br/>
    <input class="btn btn-default btn-lg" type="submit" value="Oui">
    <a href="../index.php" class="btn btn-default btn-lg" role="button">Non</a>
        <?php
        //echo $nb_monome;
        ?>

  </form>
<?php
}
?>