<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Polynôme</title>
    <link href="./style/css/bootstrap.min.css" rel="stylesheet">
    <link href="./style/css/style.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <h1 class="p-centre titre"><a href="index.php">Calcul de polynômes</a></h1>
    <div class="p-centre">
      <a href="index.php" class="btn btn-default btn-lg" role="button">Accueil</a>
      <a href="objectifs.php" class="btn btn-primary btn-lg" role="button">Objectifs</a>
    </div>
    <br/><br/>
    <div class="container">
      <p>L'énoncé du sujet de ce projet de programmation est disponible <a href="sujet.pdf" target="_blank">sur ce lien</a>.</p>
      <br/>
      <div class="row">
        <div class="col-md-6">
          <h4>Fonctionnalités impératives</h4>
          <ul>
            <li>Saisie de monôme / polynôme.</li>
            <li>Affichage des polynômes.</li>
            <li>Addition de polynôme.</li>
            <li>Multiplication de polynôme.</li>
            <li>Division de polynôme.</li>
            <li>Conjugaison de polynôme.</li>
            <li>Extraction de la partie réelle et imaginaire.</li>
            <li>Evaluation en un point avec la méthode de Ruffini-Horner.</li>
          </ul>
        </div>
        <div class="col-md-6">
          <h4>Fonctionnalités avancées</h4>
          <ul>
            <li>Dérivation de polynôme.</li>
            <li>Recherche de primitive de polynôme.</li>
            <li>Factorisaton de polynôme.</li>
            <li>Composition et décomposition.</li>
            <li>Recherche du PGCD.</li>
          </ul>
        </div>
      </div>
      <hr/>
	  <div class="p-centre"><p>Réalisé par <strong>Martin Prieur de la Comble</strong> et <strong>Abel Derderian</strong>, en projet informatique de PL2 (2014-2015).</p></div>
	  <hr/>
      <div class="p-centre"><img src="./img/efrei.png" alt="Efrei" title="Efrei"/></div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="./style/js/bootstrap.min.js"></script>
  </body>
</html>l