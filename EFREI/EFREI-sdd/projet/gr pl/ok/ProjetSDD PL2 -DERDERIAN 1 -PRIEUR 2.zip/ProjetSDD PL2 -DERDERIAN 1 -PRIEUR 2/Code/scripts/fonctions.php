<?php

//Fonction afin de déterminer le type du formulaire que l'on reçoit
function determiner_monome($monome)
{
	//Est-ce qu'il y a une puissance ?
	if ((substr_count($monome, "^(")) == "1")
	{
		//On sépare coefficient et degré et on créé le tableau
		$tableau_monome_temp = explode('^(', $monome);
		//On enlève la dernière ")", du degré
		$tableau_monome_temp[1] = str_replace(")", "", $tableau_monome_temp[1]);
		//On cherche à savoir si le degré est négative, sinon il est positif.
		$tableau_monome_temp[2] = ((substr_count($tableau_monome_temp[0], '-')) == "1") ? $signe="-" : $signe="+";
		//On précise que l'exposant existe (1 : Oui / 0 : Non)
		$tableau_monome_temp[3] = "1";
		//On cherche à savoir si le coefficient est négative, sinon il est positif.
		$tableau_monome_temp[4] = ((substr_count($tableau_monome_temp[1], '-')) == "1") ? $signe="-" : $signe="+";
		//On cherche à déterminer quel est le type de variable du monome.
		if (preg_match('/[a-zA-Z]/', $monome, $matches) == 1)
		{
			$tableau_monome_temp[5] = 1;
			$tableau_monome_temp[6] = $matches[0];
		}
		else
		{
			$tableau_monome_temp[5] = 0;
			$tableau_monome_temp[6] = null;
		}
		//On détermine le scalaire du monome en supprimant l'inconnue et le signe s'il est présent.
		$tableau_monome_temp[7] = str_replace($tableau_monome_temp[6], "", $tableau_monome_temp[0]);
		if ($tableau_monome_temp[2] == "-")
		{
			$tableau_monome_temp[7] = str_replace("-", "", $tableau_monome_temp[7]);
		}
		//On renvoit les valeurs.
		$tableau_monome[0] = $monome; // Le monome
		$tableau_monome[1] = $tableau_monome_temp[2]; // Signe du coefficient
		$tableau_monome[2] = $tableau_monome_temp[7]; // Scalaire du coeffiecient
		$tableau_monome[3] = $tableau_monome_temp[5]; // Est-ce qu'il y a une inconnue ? 1 : Oui / 0 : Non
		$tableau_monome[4] = $tableau_monome_temp[6]; // Quelle est l'inconnue ?
		$tableau_monome[5] = $tableau_monome_temp[3]; // Est-ce qu'il y a une puissance ? 1 : oui / 0 : Non
		$tableau_monome[6] = $tableau_monome_temp[1]; // Valeur de la puissance
		$tableau_monome[7] = $tableau_monome_temp[4]; // Signe de la puisance
		return $tableau_monome;
	}
	else
	{
		// Le monome
		$tableau_monome[0] = $monome;
		//On cherche à savoir si le coefficient est négative, sinon il est positif.
		$tableau_monome[1] = ((substr_count($tableau_monome[0], '-')) == "1") ? $signe="-" : $signe="+";
		//On cherche à déterminer quel est le type de variable du monome.
		if (preg_match('/[a-zA-Z]/', $monome, $matches) == 1)
		{
			$tableau_monome[3] = 1;
			$tableau_monome[4] = $matches[0];
		}
		else
		{
			$tableau_monome[3] = 0;
			$tableau_monome[4] = 0;
		}
		//On détermine le scalaire du monome en supprimant l'inconnue et le signe s'il est présent.
		$tableau_monome[2] = str_replace($tableau_monome[4], "", $tableau_monome[0]);
		if ($tableau_monome[1] == "-")
		{
			$tableau_monome[2] = str_replace("-", "", $tableau_monome[2]);
		}
		$tableau_monome[5] = 0;
		$tableau_monome[6] = 0;
		$tableau_monome[7] = 0;
		return $tableau_monome;
	}
}


//Il faut lui envoyer $_POST["polynome"]
function decouper_polynome()
{
	//La variable $polinome prend la valeur du polynome reçu en POST
	$polynome = $_POST["polynome"];
	// On découpe le polynome en fonction des "-" dans un premier temps.
	$tableau_polynome_temp = explode('-', $polynome);
	$i = 0;
	$k = 0;
	//Si le premier monome est négatif
	if($tableau_polynome_temp[0] == "")
	{
		$tableau_polynome_temp[1] = "-".$tableau_polynome_temp[1]; 
		$i++;
	}
	//On parcourt le tableau temporaire tant qu'on ne l'a pas fini.
	while($tableau_polynome_temp[$i] != null)
	{
		//Si on trouve une "(" avant le monome, on le regroupe
		if (substr($tableau_polynome_temp[$i], -1) == "(")
		{
			$tableau_polynome_temp1[$k] = $tableau_polynome_temp[$i]."-".$tableau_polynome_temp[$i+1];
			$i++;
		}
		else
		{
			$tableau_polynome_temp1[$k] = "-".$tableau_polynome_temp[$i];
		}
		$i++;
		$k++;
	}
	//Décomposition avec le signe +
	$i = 0;
	$j = 0;
	while($tableau_polynome_temp1[$i] != null)
	{
		$nb_plus = substr_count($tableau_polynome_temp1[$i], '+');
		if ($nb_plus != 0)
		{
			$tableau_polynome_temp_plus = explode('+', $tableau_polynome_temp1[$i]);
			for ($a=0; $a <= $nb_plus; $a++)
			{
				$tableau_polynome[$j] = $tableau_polynome_temp_plus[$a];
				$j++;
			}
		}
		else
		{
			$tableau_polynome[$j] = $tableau_polynome_temp1[$i];
			$j++;
		}
		$i++;
	}
	return $tableau_polynome;
}