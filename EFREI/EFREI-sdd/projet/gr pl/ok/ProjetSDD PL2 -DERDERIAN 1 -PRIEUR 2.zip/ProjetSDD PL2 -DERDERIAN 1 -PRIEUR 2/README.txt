Projet polyn�me PL2 :
Ce que le code contient :
- Programme en PHP
- Saisie des polyn�mes simples
- Saisie des polyn�mes complexes
- Analyse du polyn�me et d�coupe en somme de mon�mes
- D�coupage du mon�mes en diff�rentes constantes